package com.myfinn.my_finn

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity est nécessaire pour l'empreinte digitale (local_auth)
class MainActivity : FlutterFragmentActivity()
