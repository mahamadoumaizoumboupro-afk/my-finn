plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.myfinn.my_finn"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.myfinn.my_finn"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    // Clé fixe : chaque nouvelle version peut s'installer par-dessus l'ancienne sans perdre les données.
    // Le fichier de clé n'est pas dans le dépôt : GitHub Actions le déchiffre (myfinn-release.jks.enc) avec le secret MYFINN_PASSWORD.
    val myfinnKey = file("myfinn-release.jks")
    signingConfigs {
        create("myfinn") {
            storeFile = myfinnKey
            storePassword = "myfinn2026"
            keyAlias = "myfinn"
            keyPassword = "myfinn2026"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName(if (myfinnKey.exists()) "myfinn" else "debug")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}
