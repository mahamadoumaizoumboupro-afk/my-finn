import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'report.dart' show kShort;
import 'tx_form.dart';

IconData rechargeIcon(String? kind) => switch (kind) {
  'wifi' => Icons.router_rounded,
  'internet' => Icons.signal_cellular_alt_rounded,
  'appel' => Icons.call_rounded,
  _ => Icons.help_outline_rounded,
};

Color opColor(String? op) => switch (op) {
  'Airtel' => const Color(0xFFEF4444),
  'Moov' => const Color(0xFF3B82F6),
  'Zamani' => const Color(0xFFA855F7),
  'Niger Télécom' => const Color(0xFF10B981),
  _ => const Color(0xFF94A3B8),
};

const _kindColors = {
  'wifi': Color(0xFF5B7CFA),
  'internet': Color(0xFF22D3EE),
  'appel': Color(0xFFF59E0B),
};

/// « Mes recharges » : Box Wi-Fi, internet, appel… mois par mois.
class RechargesScreen extends StatefulWidget {
  final String? month;
  const RechargesScreen({super.key, this.month});
  @override
  State<RechargesScreen> createState() => _RechargesScreenState();
}

class _RechargesScreenState extends State<RechargesScreen> {
  late String month = widget.month ?? currentMonth();

  @override
  Widget build(BuildContext context) => Watch((context) {
    final r = store.recharges(month);
    final prev = store.recharges(shiftMonth(month, -1)).total;
    final name = monthLabel(month).split(' ').first.toLowerCase();
    // Évolution : du premier mois avec une recharge jusqu'à ce mois-ci (12 max).
    final first = store.txs
        .where(store.isRecharge)
        .map((t) => t.period)
        .fold<String?>(null, (a, b) => a == null || b.compareTo(a) < 0 ? b : a);
    final last = currentMonth().compareTo(month) > 0 ? currentMonth() : month;
    final months = <String>[];
    if (first != null) {
      for (
        var m = last;
        m.compareTo(first) >= 0 && months.length < 12;
        m = shiftMonth(m, -1)
      ) {
        months.insert(0, m);
      }
    }
    final totals = {for (final m in months) m: store.recharges(m).total};
    final maxT = totals.values.fold(1, (a, b) => b > a ? b : a);
    final noted = {for (final m in months) m: store.summary(m).expense > 0};
    final diff = r.total - prev;
    return SubPage(
      title: 'Mes recharges',
      children: [
        MonthSwitcher(
          month: month,
          onChanged: (m) => setState(() => month = m),
        ),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                monthLabel(month),
                style: ts(12, w: w7, c: C.muted),
              ),
              Text(money(r.total), style: ts(30, w: w8, ls: -0.8)),
              Text(
                '${r.count} recharge${r.count > 1 ? 's' : ''}'
                '${prev == 0 || diff == 0 ? '' : ' · ${num0(diff.abs())} de ${diff < 0 ? 'moins' : 'plus'} qu\'en ${shortMonth(shiftMonth(month, -1))}'}',
                style: ts(12, c: C.muted),
              ),
            ],
          ),
        ),
        if (months.isNotEmpty)
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Mois par mois', style: ts(15, w: w8)),
                Text('Touche un mois pour le voir', style: ts(12, c: C.muted)),
                const SizedBox(height: 10),
                SizedBox(
                  height: 120,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      for (final m in months)
                        Expanded(
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => setState(() => month = m),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 3,
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  FittedBox(
                                    child: Text(
                                      !noted[m]!
                                          ? '—'
                                          : store.hidden
                                          ? '•'
                                          : kShort(totals[m]!),
                                      style: ts(
                                        10,
                                        w: w7,
                                        c: m == month ? C.text : C.muted,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Flexible(
                                    child: FractionallySizedBox(
                                      heightFactor: (totals[m]! / maxT).clamp(
                                        0.02,
                                        1.0,
                                      ),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: m == month
                                              ? C.primary
                                              : C.primary.withValues(
                                                  alpha: 0.35,
                                                ),
                                          borderRadius: BorderRadius.circular(
                                            5,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    shortMonth(m),
                                    style: ts(
                                      10,
                                      w: m == month ? w8 : w6,
                                      c: m == month ? C.text : C.muted,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                if (noted.values.any((v) => !v)) ...[
                  const SizedBox(height: 8),
                  Text(
                    '— : dépenses pas notées ce mois-là.',
                    style: ts(11, c: C.muted),
                  ),
                ],
              ],
            ),
          ),
        if (r.count == 0)
          EmptyState('Aucune recharge notée en $name.')
        else ...[
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Par genre', style: ts(15, w: w8)),
                const SizedBox(height: 8),
                for (final k in [...rechargeKinds.map((e) => e.$1), ''])
                  if (r.byKind[k] case final v?)
                    _barRow(
                      rechargeIcon(k.isEmpty ? null : k),
                      k.isEmpty
                          ? 'Genre pas précisé'
                          : rechargeKinds.firstWhere((e) => e.$1 == k).$2,
                      v,
                      r.total,
                      _kindColors[k] ?? C.muted,
                    ),
              ],
            ),
          ),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Par opérateur', style: ts(15, w: w8)),
                const SizedBox(height: 8),
                for (final o in [...rechargeOps, ''])
                  if (r.byOp[o] case final v?)
                    _line(
                      o.isEmpty ? 'Pas précisé' : o,
                      v,
                      dotColor: opColor(o.isEmpty ? null : o),
                    ),
              ],
            ),
          ),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Pour qui', style: ts(15, w: w8)),
                const SizedBox(height: 8),
                for (final e
                    in (r.byWho.entries.toList()
                      ..sort((a, b) => b.value.compareTo(a.value))))
                  _line(e.key, e.value),
              ],
            ),
          ),
          SectionTitle('Les recharges de $name'),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(
              children: [
                for (var i = 0; i < r.items.length; i++)
                  TxTile(
                    r.items[i],
                    last: i == r.items.length - 1,
                    onTap: () => push(context, TxFormScreen(id: r.items[i].id)),
                  ),
              ],
            ),
          ),
          Text(
            'Pour préciser le genre ou l\'opérateur d\'une ancienne recharge, touche-la.',
            style: ts(12, c: C.muted),
          ),
        ],
      ],
    );
  });

  Widget _barRow(IconData icon, String label, int v, int total, Color c) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          children: [
            Row(
              children: [
                Icon(icon, size: 17, color: c),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(label, style: ts(14, w: w7)),
                ),
                Text(num0(v), style: ts(14, w: w8)),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: LinearProgressIndicator(
                value: total > 0 ? v / total : 0,
                minHeight: 9,
                backgroundColor: C.border,
                color: c,
              ),
            ),
          ],
        ),
      );

  Widget _line(String label, int v, {Color? dotColor}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      children: [
        if (dotColor != null) ...[
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
        ],
        Expanded(
          child: Text(
            label,
            style: ts(14, w: w7),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Text(num0(v), style: ts(14, w: w8)),
      ],
    ),
  );
}

/// Petite case du Bilan qui mène à « Mes recharges ».
class RechargeLink extends StatelessWidget {
  final String month;
  const RechargeLink(this.month, {super.key});
  @override
  Widget build(BuildContext context) {
    final r = store.recharges(month);
    if (r.count == 0) return const SizedBox.shrink();
    return AppCard(
      onTap: () => push(context, RechargesScreen(month: month)),
      child: Row(
        children: [
          IconBubble(
            Icons.signal_cellular_alt_rounded,
            const Color(0xFF22D3EE),
            size: 40,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Mes recharges', style: ts(15, w: w7)),
                Text(
                  'Box Wi-Fi, internet, appel · touche pour voir le détail',
                  style: ts(12, c: C.muted),
                  maxLines: 2,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(num0(r.total), style: ts(15, w: w8)),
          Icon(Icons.chevron_right_rounded, color: C.muted),
        ],
      ),
    );
  }
}
