import 'package:flutter/material.dart';
import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'accounts.dart';
import 'debts.dart';
import 'settings.dart';
import 'tx_form.dart';
import '../update.dart';

String greeting() {
  final h = DateTime.now().hour;
  return h < 12 ? 'Bonjour' : h < 18 ? 'Bon après-midi' : 'Bonsoir';
}

class HomeScreen extends StatelessWidget {
  final void Function(int) goTab;
  const HomeScreen({super.key, required this.goTab});

  @override
  Widget build(BuildContext context) => Watch((context) {
        final month = currentMonth();
        final sm = store.summary(month);
        final accounts = store.activeAccounts;
        final available = store.available();
        final expenseCats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
        final top = expenseCats.take(6).toList();
        final rest = expenseCats.skip(6).fold<int>(0, (x, c) => x + c.total);
        final net = sm.income - sm.expense;
        final due = store.dueDebts();
        final overBudget = expenseCats.where((c) => c.cat.budget > 0 && c.total >= c.cat.budget * 0.8).toList();
        final recent = store.transactions(limit: 5);

        // Évolution du disponible jour par jour sur le mois en cours
        final days = int.parse(today().substring(8, 10));
        final series = [
          store.available(until: '${shiftMonth(month, -1)}-31'),
          for (var d = 1; d <= days; d++) store.available(until: '$month-${d.toString().padLeft(2, '0')}'),
        ];
        final prevAvail = series.first;
        final change = prevAvail == 0 ? null : (available - prevAvail) / prevAvail.abs() * 100;
        final prev = store.summary(shiftMonth(month, -1));
        final saving = sm.income - sm.expense - sm.fees;
        final prevSaving = prev.income - prev.expense - prev.fees;
        final tip = _insight(sm, prev);

        return PageScaffold(
          title: store.settings['name']?.isNotEmpty == true ? store.settings['name']! : 'Mahamadou',
          subtitle: '${greeting()},',
          trailing: Row(children: [
            RoundIconButton(store.hidden ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                onTap: () => store.setSetting('hide_amounts', store.hidden ? '0' : '1')),
            const SizedBox(width: 8),
            RoundIconButton(Icons.settings_outlined, onTap: () => push(context, const SettingsScreen())),
          ]),
          children: [
            // Carte principale bleu marine : solde + courbe
            Container(
              margin: const EdgeInsets.only(bottom: 18),
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
              decoration: BoxDecoration(
                gradient: heroGradient, borderRadius: BorderRadius.circular(26),
                boxShadow: [BoxShadow(color: const Color(0xFF0F2747).withValues(alpha: 0.30), blurRadius: 24, offset: const Offset(0, 12))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Row(children: [
                      Flexible(child: Text('Solde disponible', style: ts(14, w: w6, c: Colors.white70), maxLines: 1, overflow: TextOverflow.ellipsis)),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () => store.setSetting('hide_amounts', store.hidden ? '0' : '1'),
                        child: Icon(store.hidden ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 17, color: Colors.white70),
                      ),
                    ]),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(99)),
                    child: Text(monthLabel(month).split(' ').first, style: ts(12, w: w7, c: Colors.white)),
                  ),
                ]),
                const SizedBox(height: 6),
                FittedBox(child: Text(money(available), style: ts(34, w: w8, c: Colors.white, ls: -1))),
                if (change != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(children: [
                      Icon(change >= 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded, size: 17,
                          color: change >= 0 ? const Color(0xFF4ADE9F) : const Color(0xFFFF8A8E)),
                      const SizedBox(width: 6),
                      Flexible(child: Text('${change >= 0 ? '+' : ''}${change.toStringAsFixed(1).replaceAll('.', ',')} % depuis le début du mois',
                          style: ts(12, w: w7, c: change >= 0 ? const Color(0xFF4ADE9F) : const Color(0xFFFF8A8E)), overflow: TextOverflow.ellipsis)),
                    ]),
                  ),
                const SizedBox(height: 8),
                Sparkline(series, color: const Color(0xFF7FB2FF), height: 70),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(child: Text('On me doit ${money(store.owedToMe())}', style: ts(12, w: w6, c: Colors.white70))),
                  Text('Je dois ${money(store.iOwe())}', style: ts(12, w: w6, c: Colors.white70)),
                ]),
              ]),
            ),
            // Actions rapides
            Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: Row(children: [
                _Quick('Dépense', Icons.north_east_rounded, C.expense, () => push(context, const TxFormScreen(type: TxType.expense))),
                _Quick('Entrée', Icons.south_west_rounded, C.income, () => push(context, const TxFormScreen(type: TxType.income))),
                _Quick('Transfert', Icons.swap_horiz_rounded, C.transfer, () => push(context, const TxFormScreen(type: TxType.transfer))),
                _Quick('Prêt', Icons.handshake_rounded, C.warn, () => push(context, const DebtFormScreen(direction: DebtDirection.lent))),
              ]),
            ),
            // Aperçu du mois
            SectionTitle('Aperçu du mois', trailing: LinkText('Bilan', onTap: () => goTab(3))),
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Row(children: [
                Expanded(child: _Overview('Entrées', Icons.south_west_rounded, C.income, sm.income, prev.income)),
                const SizedBox(width: 10),
                Expanded(child: _Overview('Dépenses', Icons.north_east_rounded, C.expense, sm.expense + sm.fees, prev.expense + prev.fees,
                    lowerIsBetter: true)),
                const SizedBox(width: 10),
                Expanded(child: _Overview('Épargne', Icons.savings_rounded, C.transfer, saving, prevSaving)),
              ]),
            ),
            // Conseil du mois
            if (tip != null)
              AppCard(
                color: C.primarySoft,
                child: Row(children: [
                  IconBubble(Icons.lightbulb_rounded, C.accent, size: 40),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Conseil du mois', style: ts(12, w: w8, c: C.primary)),
                    const SizedBox(height: 2),
                    Text(tip, style: ts(14, w: w7)),
                  ])),
                ]),
              ),
            ValueListenableBuilder<UpdateInfo?>(
              valueListenable: updateAvailable,
              builder: (context, up, _) => up == null ? const SizedBox.shrink() : Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: GestureDetector(
                  onTap: () => openUpdate(up),
                  child: GradientBox(
                    gradient: primaryGradient,
                    radius: 20,
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      const Icon(Icons.system_update_rounded, color: Colors.white, size: 26),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Nouvelle version disponible', style: ts(15, w: w8, c: Colors.white)),
                        Text('Version ${up.label} · appuie pour la télécharger, puis installe-la. Tes données sont gardées.',
                            style: ts(12, w: w6, c: Colors.white70)),
                      ])),
                    ]),
                  ),
                ),
              ),
            ),
            if (due.isNotEmpty || overBudget.isNotEmpty)
              AppCard(
                color: C.warnSoft,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [Icon(Icons.notifications_active_rounded, color: C.warn, size: 19), const SizedBox(width: 8),
                    Text('À surveiller', style: ts(15, w: w8))]),
                  const SizedBox(height: 6),
                  for (final d in due)
                    GestureDetector(
                      onTap: () => push(context, DebtDetailScreen(id: d.id)),
                      child: Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Text(
                          '${d.direction == DebtDirection.lent ? '${d.person} doit te rembourser' : 'Tu dois rembourser ${d.person}'} '
                          '${money(store.remaining(d))} · échéance ${shortDate(d.dueDate!)}', style: ts(13, w: w6))),
                    ),
                  for (final c in overBudget)
                    Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Text(
                        '${c.cat.name} : ${money(c.total)} sur un budget de ${money(c.cat.budget)}${c.total > c.cat.budget ? ' (dépassé)' : ''}',
                        style: ts(13, w: w6))),
                ]),
              ),
            SectionTitle('Mes comptes', trailing: LinkText('Voir tout', onTap: () => push(context, const AccountsScreen()))),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Column(children: [
                for (var i = 0; i < accounts.length; i++)
                  InkWell(
                    onTap: () => push(context, AccountDetailScreen(id: accounts[i].id)),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: C.border))),
                      child: Row(children: [
                        IconBubble(accountIcon(accounts[i].type), Color(accounts[i].color), size: 40),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(accounts[i].name, style: ts(15, w: w7)),
                          Text(accounts[i].includeInTotal ? accountTypeLabel(accounts[i].type) : 'Hors disponible', style: ts(12, c: C.muted)),
                        ])),
                        Text(money(store.balance(accounts[i])), style: ts(15, w: w8)),
                        Icon(Icons.chevron_right_rounded, color: C.faint),
                      ]),
                    ),
                  ),
                InkWell(
                  onTap: () => push(context, const AccountFormScreen()),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(children: [
                      Icon(Icons.add_circle_outline_rounded, color: C.primary),
                      const SizedBox(width: 10),
                      Text('Ajouter un compte', style: ts(14, w: w7, c: C.primary)),
                    ]),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 18),
            SectionTitle(monthLabel(month), trailing: LinkText('Bilan', onTap: () => goTab(3))),
            AppCard(
              child: expenseCats.isEmpty
                  ? const EmptyState('Pas encore de dépenses ce mois.', icon: Icons.donut_large_rounded)
                  : Row(children: [
                      Donut(
                        size: 132, stroke: 18,
                        data: [for (final c in top) (c.total, Color(c.cat.color)), if (rest > 0) (rest, C.faint)],
                        center: Column(mainAxisSize: MainAxisSize.min, children: [
                          Text('Reste', style: ts(11, w: w7, c: C.muted)),
                          Text(store.hidden ? '•••' : '${net >= 0 ? '+' : ''}${(net / 1000).round()}k',
                              style: ts(14, w: w8, c: net < 0 ? C.expense : C.income)),
                        ]),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(children: [
                          for (final c in top) _legend(Color(c.cat.color), c.cat.name, c.total, sm.expense),
                          if (rest > 0) _legend(C.faint, 'Autres', rest, sm.expense),
                        ]),
                      ),
                    ]),
            ),
            if (store.owedToMe() + store.iOwe() > 0)
              AppCard(
                onTap: () => goTab(2),
                child: Row(children: [
                  IconBubble(Icons.people_rounded, C.warn),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Prêts & dettes', style: ts(15, w: w8)),
                    Text('On me doit ${money(store.owedToMe())} · Je dois ${money(store.iOwe())}', style: ts(12, c: C.muted)),
                  ])),
                  Icon(Icons.chevron_right_rounded, color: C.muted),
                ]),
              ),
            SectionTitle('Dernières opérations', trailing: LinkText('Tout voir', onTap: () => goTab(1))),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: recent.isEmpty
                  ? const EmptyState('Aucune opération. Appuie sur + pour commencer.')
                  : Column(children: [
                      for (var i = 0; i < recent.length; i++)
                        TxTile(recent[i], last: i == recent.length - 1, onTap: () => push(context, TxFormScreen(id: recent[i].id))),
                    ]),
            ),
          ],
        );
      });

  Widget _legend(Color c, String name, int v, int total) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Row(children: [
          dot(c, 8), const SizedBox(width: 8),
          Expanded(child: Text(name, style: ts(12, w: w6), maxLines: 1, overflow: TextOverflow.ellipsis)),
          Text('${total > 0 ? (v / total * 100).round() : 0}%', style: ts(12, w: w8)),
        ]),
      );
}

/// Conseil simple tiré des chiffres du mois.
String? _insight(MonthSummary sm, MonthSummary prev) {
  final cats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
  if (cats.isEmpty) return null;
  final prevBy = {for (final c in prev.byCategory) c.cat.id: c.total};
  // La catégorie qui a le plus changé par rapport au mois dernier
  CatTotal? best;
  var bestDelta = 0;
  for (final c in cats) {
    final p = prevBy[c.cat.id] ?? 0;
    if (p == 0) continue;
    final d = c.total - p;
    if (d.abs() > bestDelta.abs()) {
      best = c;
      bestDelta = d;
    }
  }
  if (best != null) {
    final p = prevBy[best.cat.id]!;
    final pc = (bestDelta.abs() / p * 100).round();
    return bestDelta < 0
        ? 'Bravo : ${best.cat.name} en baisse de $pc % par rapport au mois dernier (${money(bestDelta.abs())} de moins).'
        : '${best.cat.name} en hausse de $pc % par rapport au mois dernier (${money(bestDelta)} de plus).';
  }
  final top = cats.first;
  final total = sm.expense == 0 ? 1 : sm.expense;
  return '${top.cat.name} représente ${(top.total / total * 100).round()} % de tes dépenses ce mois.';
}

/// Petite carte de l'aperçu : montant + évolution par rapport au mois dernier.
class _Overview extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final int value, prev;
  final bool lowerIsBetter;
  const _Overview(this.label, this.icon, this.color, this.value, this.prev, {this.lowerIsBetter = false});
  @override
  Widget build(BuildContext context) {
    final pc = prev == 0 ? null : (value - prev) / prev.abs() * 100;
    final good = pc == null ? true : (lowerIsBetter ? pc <= 0 : pc >= 0);
    return Glass(
      padding: const EdgeInsets.all(12),
      radius: 18,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 24, height: 24, decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: Icon(icon, size: 14, color: Colors.white)),
          const SizedBox(width: 6),
          Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: ts(11, w: w7, c: C.muted)))),
        ]),
        const SizedBox(height: 8),
        FittedBox(child: Text(store.hidden ? '•••••' : num0(value), style: ts(16, w: w8))),
        const SizedBox(height: 2),
        Text(pc == null ? '—' : '${pc >= 0 ? '+' : ''}${pc.toStringAsFixed(1).replaceAll('.', ',')} %',
            style: ts(11, w: w8, c: pc == null ? C.muted : (good ? C.income : C.expense))),
      ]),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final int value;
  final Color color;
  const _HeroStat(this.icon, this.label, this.value, this.color);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 22, height: 22, decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.25), shape: BoxShape.circle),
                child: Icon(icon, size: 13, color: Colors.white)),
            const SizedBox(width: 6),
            Flexible(child: Text(label, style: ts(11, w: w7, c: Colors.white70), overflow: TextOverflow.ellipsis)),
          ]),
          const SizedBox(height: 6),
          FittedBox(child: Text(money(value), style: ts(15, w: w8, c: Colors.white))),
        ]),
      );
}

class _Quick extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _Quick(this.label, this.icon, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
        child: GestureDetector(
          onTap: onTap,
          child: Column(children: [
            Container(
              width: 58, height: 58,
              decoration: BoxDecoration(
                color: color, shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: 0.35)),
                boxShadow: [BoxShadow(color: color.withValues(alpha: 0.38), blurRadius: 14, offset: const Offset(0, 6))],
              ),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(height: 6),
            Text(label, style: ts(12, w: w7)),
          ]),
        ),
      );
}
