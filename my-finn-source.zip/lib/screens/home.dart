import 'package:flutter/material.dart';
import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'accounts.dart';
import 'debts.dart';
import 'settings.dart';
import 'tx_form.dart';

String greeting() {
  final h = DateTime.now().hour;
  return h < 12 ? 'Bonjour' : h < 18 ? 'Bon après-midi' : 'Bonsoir';
}

class HomeScreen extends StatelessWidget {
  final void Function(int) goTab;
  const HomeScreen({super.key, required this.goTab});

  @override
  Widget build(BuildContext context) => Watch((context) {
        final month = currentMonth();
        final sm = store.summary(month);
        final accounts = store.activeAccounts;
        final available = store.available();
        final expenseCats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
        final top = expenseCats.take(6).toList();
        final rest = expenseCats.skip(6).fold<int>(0, (x, c) => x + c.total);
        final net = sm.income - sm.expense;
        final due = store.dueDebts();
        final overBudget = expenseCats.where((c) => c.cat.budget > 0 && c.total >= c.cat.budget * 0.8).toList();
        final recent = store.transactions(limit: 5);

        return PageScaffold(
          title: 'MY FINN',
          subtitle: greeting(),
          trailing: Row(children: [
            RoundIconButton(store.hidden ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                onTap: () => store.setSetting('hide_amounts', store.hidden ? '0' : '1')),
            const SizedBox(width: 8),
            RoundIconButton(Icons.settings_outlined, onTap: () => push(context, const SettingsScreen())),
          ]),
          children: [
            GradientBox(
              gradient: heroGradient,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Disponible · comptes + cash', style: ts(14, w: w6, c: Colors.white70)),
                const SizedBox(height: 4),
                FittedBox(child: Text(money(available), style: ts(34, w: w8, c: Colors.white, ls: -1))),
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(child: _HeroStat(Icons.south_rounded, 'Entrées du mois', sm.income)),
                  const SizedBox(width: 10),
                  Expanded(child: _HeroStat(Icons.north_rounded, 'Dépenses du mois', sm.expense)),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: Text('On me doit ${money(store.owedToMe())}', style: ts(12, w: w6, c: Colors.white70))),
                  Text('Je dois ${money(store.iOwe())}', style: ts(12, w: w6, c: Colors.white70)),
                ]),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Row(children: [
                _Quick('Dépense', Icons.north_rounded, C.expense, () => push(context, const TxFormScreen(type: TxType.expense))),
                _Quick('Entrée', Icons.south_rounded, C.income, () => push(context, const TxFormScreen(type: TxType.income))),
                _Quick('Transfert', Icons.swap_horiz_rounded, C.transfer, () => push(context, const TxFormScreen(type: TxType.transfer))),
                _Quick('Prêt', Icons.handshake_rounded, C.warn, () => push(context, const DebtFormScreen(direction: DebtDirection.lent))),
              ]),
            ),
            if (due.isNotEmpty || overBudget.isNotEmpty)
              AppCard(
                color: C.warnSoft,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [Icon(Icons.notifications_active_rounded, color: C.warn, size: 19), const SizedBox(width: 8),
                    Text('À surveiller', style: ts(15, w: w8))]),
                  const SizedBox(height: 6),
                  for (final d in due)
                    GestureDetector(
                      onTap: () => push(context, DebtDetailScreen(id: d.id)),
                      child: Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Text(
                          '${d.direction == DebtDirection.lent ? '${d.person} doit te rembourser' : 'Tu dois rembourser ${d.person}'} '
                          '${money(store.remaining(d))} · échéance ${shortDate(d.dueDate!)}', style: ts(13, w: w6))),
                    ),
                  for (final c in overBudget)
                    Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Text(
                        '${c.cat.name} : ${money(c.total)} sur un budget de ${money(c.cat.budget)}${c.total > c.cat.budget ? ' (dépassé)' : ''}',
                        style: ts(13, w: w6))),
                ]),
              ),
            SectionTitle('Mes comptes', trailing: LinkText('Gérer', onTap: () => push(context, const AccountsScreen()))),
            SizedBox(
              height: 136,
              child: ListView(
                scrollDirection: Axis.horizontal,
                clipBehavior: Clip.none,
                children: [
                  for (final a in accounts)
                    GestureDetector(
                      onTap: () => push(context, AccountDetailScreen(id: a.id)),
                      child: Container(
                        width: 150, margin: const EdgeInsets.only(right: 12), padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(22), boxShadow: softShadow),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          IconBubble(accountIcon(a.type), Color(a.color), size: 36),
                          const Spacer(),
                          Text(a.name, style: ts(12, w: w7, c: C.muted), maxLines: 1, overflow: TextOverflow.ellipsis),
                          FittedBox(child: Text(money(store.balance(a)), style: ts(16, w: w8))),
                          if (!a.includeInTotal) Text('hors disponible', style: ts(10, c: C.muted)),
                        ]),
                      ),
                    ),
                  GestureDetector(
                    onTap: () => push(context, const AccountFormScreen()),
                    child: Container(
                      width: 100,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), border: Border.all(color: C.border, width: 2)),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.add_rounded, color: C.muted, size: 26),
                        Text('Ajouter', style: ts(12, w: w7, c: C.muted)),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SectionTitle(monthLabel(month), trailing: LinkText('Bilan', onTap: () => goTab(3))),
            AppCard(
              child: expenseCats.isEmpty
                  ? const EmptyState('Pas encore de dépenses ce mois.', icon: Icons.donut_large_rounded)
                  : Row(children: [
                      Donut(
                        size: 132, stroke: 18,
                        data: [for (final c in top) (c.total, Color(c.cat.color)), if (rest > 0) (rest, C.faint)],
                        center: Column(mainAxisSize: MainAxisSize.min, children: [
                          Text('Reste', style: ts(11, w: w7, c: C.muted)),
                          Text(store.hidden ? '•••' : '${net >= 0 ? '+' : ''}${(net / 1000).round()}k',
                              style: ts(14, w: w8, c: net < 0 ? C.expense : C.income)),
                        ]),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(children: [
                          for (final c in top) _legend(Color(c.cat.color), c.cat.name, c.total, sm.expense),
                          if (rest > 0) _legend(C.faint, 'Autres', rest, sm.expense),
                        ]),
                      ),
                    ]),
            ),
            if (store.owedToMe() + store.iOwe() > 0)
              AppCard(
                onTap: () => goTab(2),
                child: Row(children: [
                  IconBubble(Icons.people_rounded, C.warn),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Prêts & dettes', style: ts(15, w: w8)),
                    Text('On me doit ${money(store.owedToMe())} · Je dois ${money(store.iOwe())}', style: ts(12, c: C.muted)),
                  ])),
                  Icon(Icons.chevron_right_rounded, color: C.muted),
                ]),
              ),
            SectionTitle('Dernières opérations', trailing: LinkText('Tout voir', onTap: () => goTab(1))),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: recent.isEmpty
                  ? const EmptyState('Aucune opération. Appuie sur + pour commencer.')
                  : Column(children: [
                      for (var i = 0; i < recent.length; i++)
                        TxTile(recent[i], last: i == recent.length - 1, onTap: () => push(context, TxFormScreen(id: recent[i].id))),
                    ]),
            ),
          ],
        );
      });

  Widget _legend(Color c, String name, int v, int total) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Row(children: [
          dot(c, 8), const SizedBox(width: 8),
          Expanded(child: Text(name, style: ts(12, w: w6), maxLines: 1, overflow: TextOverflow.ellipsis)),
          Text('${total > 0 ? (v / total * 100).round() : 0}%', style: ts(12, w: w8)),
        ]),
      );
}

class _HeroStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final int value;
  const _HeroStat(this.icon, this.label, this.value);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 22, height: 22, decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.25), shape: BoxShape.circle),
                child: Icon(icon, size: 13, color: Colors.white)),
            const SizedBox(width: 6),
            Flexible(child: Text(label, style: ts(11, w: w7, c: Colors.white70), overflow: TextOverflow.ellipsis)),
          ]),
          const SizedBox(height: 6),
          FittedBox(child: Text(money(value), style: ts(15, w: w8, c: Colors.white))),
        ]),
      );
}

class _Quick extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _Quick(this.label, this.icon, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
        child: GestureDetector(
          onTap: onTap,
          child: Column(children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(20), boxShadow: softShadow),
              child: Center(child: IconBubble(icon, color, size: 36)),
            ),
            const SizedBox(height: 6),
            Text(label, style: ts(12, w: w7)),
          ]),
        ),
      );
}
