import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

import 'package:flutter/foundation.dart' show kIsWeb;

import 'accounts.dart';
import 'avoirs.dart';
import 'budget.dart';
import 'debts.dart';
import 'settings.dart';
import 'tx_form.dart';
import '../update.dart';

String greeting() {
  final h = DateTime.now().hour;
  return h < 12
      ? 'Bonjour'
      : h < 18
      ? 'Bon après-midi'
      : 'Bonsoir';
}

class HomeScreen extends StatefulWidget {
  final void Function(int) goTab;
  const HomeScreen({super.key, required this.goTab});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) => Watch((context) {
    final goTab = widget.goTab;
    final month = currentMonth();
    final sm = store.summary(month);
    final prev = store.summary(shiftMonth(month, -1));
    final accounts = store.activeAccounts
        .where((a) => a.includeInTotal)
        .toList();
    final avoirs = store.avoirs();
    final available = store.available();
    final expenseCats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
    final due = store.dueDebts();
    final overBudget = expenseCats
        .where((c) => c.cat.budget > 0 && c.total >= c.cat.budget * 0.8)
        .toList();
    final recent = store.transactions(limit: 5);
    final spent = sm.expense + sm.fees;
    final saved = sm.income - spent;
    final tip = _insight(sm, prev);
    final name = store.settings['name']?.isNotEmpty == true
        ? store.settings['name']!
        : 'Mahamadou';
    return PageScaffold(
      children: [
        // En-tête : salutation + photo
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${greeting()},',
                      style: ts(14, w: w6, c: C.muted),
                    ),
                    Text(
                      name,
                      style: ts(22, w: w8),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Stack(
                children: [
                  _SquareButton(
                    Icons.notifications_none_rounded,
                    () => push(
                      context,
                      due.isNotEmpty
                          ? const DebtsScreen()
                          : BudgetScreen(month: month),
                    ),
                  ),
                  if (due.isNotEmpty || overBudget.isNotEmpty)
                    Positioned(right: 11, top: 11, child: dot(C.expense, 8)),
                ],
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () => push(context, const SettingsScreen()),
                child: ProfilePhoto(name: name, size: 46),
              ),
            ],
          ),
        ),
        // Haut de page : l'argent disponible et où il se trouve (compte par compte)
        _MoneyHero(available: available, accounts: accounts),
        // Actions rapides
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 14),
          child: Row(
            children: [
              _Action(
                'Dépense',
                Icons.north_east_rounded,
                C.expense,
                () => push(context, const TxFormScreen(type: TxType.expense)),
              ),
              _Action(
                'Entrée',
                Icons.south_west_rounded,
                C.income,
                () => push(context, const TxFormScreen(type: TxType.income)),
              ),
              _Action(
                'Transfert',
                Icons.swap_horiz_rounded,
                C.primary,
                () => push(context, const TxFormScreen(type: TxType.transfer)),
              ),
              _Action(
                'Prêt',
                Icons.handshake_rounded,
                violet,
                () => push(
                  context,
                  const DebtFormScreen(direction: DebtDirection.lent),
                ),
              ),
            ],
          ),
        ),
        if (!kIsWeb && !store.historyImported)
          _Banner(
            Icons.download_rounded,
            'Ton suivi complet est prêt',
            'Septembre 2025 → 3 novembre 2026. Appuie pour l\'importer.',
            () => askImportHistory(context),
          ),
        ValueListenableBuilder<UpdateInfo?>(
          valueListenable: updateAvailable,
          builder: (context, up, _) => up == null
              ? const SizedBox.shrink()
              : _Banner(
                  Icons.system_update_rounded,
                  'Nouvelle version disponible',
                  'Version ${up.label} · appuie pour la télécharger, puis installe-la. Tes données sont gardées.',
                  () => openUpdate(up),
                ),
        ),
        if (due.isNotEmpty || overBudget.isNotEmpty)
          AppCard(
            color: C.warnSoft,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.notifications_active_rounded,
                      color: C.warn,
                      size: 19,
                    ),
                    const SizedBox(width: 8),
                    Text('À surveiller', style: ts(15, w: w8)),
                  ],
                ),
                const SizedBox(height: 6),
                for (final d in due)
                  GestureDetector(
                    onTap: () => push(context, DebtDetailScreen(id: d.id)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Text(
                        '${d.direction == DebtDirection.lent ? '${d.person} doit te rembourser' : 'Tu dois rembourser ${d.person}'} '
                        '${money(store.remaining(d))} · échéance ${shortDate(d.dueDate!)}',
                        style: ts(13, w: w6),
                      ),
                    ),
                  ),
                for (final c in overBudget)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Text(
                      '${c.cat.name} : ${money(c.total)} sur un budget de ${money(c.cat.budget)}${c.total > c.cat.budget ? ' (dépassé)' : ''}',
                      style: ts(13, w: w6),
                    ),
                  ),
              ],
            ),
          ),
        // Le mois en bref : grille 2 colonnes
        SectionTitle(
          '${monthLabel(month).split(' ').first} en bref',
          trailing: LinkText('Bilan', onTap: () => goTab(3)),
        ),
        Row(
          children: [
            Expanded(
              child: _Tile(
                Icons.south_west_rounded,
                C.income,
                'Entrées',
                money(sm.income),
                _vs(sm.income, prev.income, false),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _Tile(
                Icons.north_east_rounded,
                C.expense,
                'Dépenses',
                money(spent),
                _vs(spent, prev.expense + prev.fees, true),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _Tile(
                Icons.savings_rounded,
                C.primary,
                'Épargné',
                sm.income > 0 ? money(saved) : '—',
                (
                  sm.income > 0
                      ? '${(saved / sm.income * 100).round()} % de tes entrées'
                      : 'pas encore d\'entrée',
                  C.muted,
                ),
                progress: sm.income > 0
                    ? (saved / sm.income).clamp(0.0, 1.0)
                    : null,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _Tile(
                Icons.diamond_rounded,
                violet,
                'Mes avoirs',
                money(avoirs.total),
                ('tout compris', C.muted),
                onTap: () => push(context, const AvoirsScreen()),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (tip != null)
          AppCard(
            color: store.dark ? null : C.primarySoft,
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                IconBubble(Icons.lightbulb_rounded, gold, size: 38),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Conseil du mois',
                        style: ts(12, w: w8, c: gold),
                      ),
                      const SizedBox(height: 2),
                      Text(tip, style: ts(13, w: w6, h: 1.4)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        // Mes comptes, avec leurs logos
        SectionTitle(
          'Mes comptes',
          trailing: LinkText(
            'Voir tout',
            onTap: () => push(context, const AccountsScreen()),
          ),
        ),
        _AccountGrid(accounts),
        const SizedBox(height: 8),
        SectionTitle(
          'Dernières opérations',
          trailing: LinkText('Tout voir', onTap: () => goTab(1)),
        ),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: recent.isEmpty
              ? const EmptyState(
                  'Aucune opération. Appuie sur + pour commencer.',
                )
              : Column(
                  children: [
                    for (var i = 0; i < recent.length; i++)
                      TxTile(
                        recent[i],
                        last: i == recent.length - 1,
                        onTap: () =>
                            push(context, TxFormScreen(id: recent[i].id)),
                      ),
                  ],
                ),
        ),
      ],
    );
  });

  /// Évolution par rapport au mois dernier, en vert si c'est bien.
  (String, Color) _vs(int v, int prev, bool lowerIsBetter) {
    if (prev == 0) return ('mois dernier : 0', C.muted);
    final pc = (v - prev) / prev.abs() * 100;
    final good = lowerIsBetter ? pc <= 0 : pc >= 0;
    return (
      '${pc >= 0 ? '+' : '−'}${pc.abs().toStringAsFixed(1).replaceAll('.', ',')} % vs mois dernier',
      good ? C.income : C.expense,
    );
  }
}

/// Haut de l'accueil : argent disponible, puis une barre de couleurs qui montre
/// combien il y a sur chaque compte, avec le montant de chaque compte en dessous.
class _MoneyHero extends StatelessWidget {
  final int available;
  final List<Account> accounts;
  const _MoneyHero({required this.available, required this.accounts});

  static const _colors = [
    Color(0xFF5B8CFF),
    Color(0xFF3DE6A8),
    Color(0xFFFFC861),
    Color(0xFFA98BFF),
    Color(0xFF4FD8F0),
    Color(0xFFFF8FB1),
    Color(0xFFFF9F5A),
  ];

  @override
  Widget build(BuildContext context) {
    final dark = store.dark;
    final fg = dark ? C.text : Colors.white;
    final soft = dark ? C.muted : Colors.white70;
    final parts = [
      for (final a in accounts) (a, store.balance(a)),
    ].where((x) => x.$2 > 0).toList()..sort((a, b) => b.$2.compareTo(a.$2));
    Color colorOf(int i) => _colors[i % _colors.length];
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
      decoration: BoxDecoration(
        gradient: heroGradient,
        borderRadius: BorderRadius.circular(dark ? 28 : cardRadius),
        border: dark ? Border.all(color: C.border) : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Flexible(
                      child: Text(
                        'Argent disponible',
                        style: ts(13, w: w7, c: soft),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => store.setSetting(
                        'hide_amounts',
                        store.hidden ? '0' : '1',
                      ),
                      child: Icon(
                        store.hidden
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        size: 16,
                        color: soft,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 11,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: dark ? 0.07 : 0.12),
                  borderRadius: BorderRadius.circular(11),
                  border: dark ? Border.all(color: C.border) : null,
                ),
                child: Text(
                  'aujourd\'hui',
                  style: ts(12, w: w8, c: fg),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: store.hidden ? '•••••' : num0(available),
                    style: ts(40, w: w8, c: fg, ls: -1.4),
                  ),
                  TextSpan(
                    text: '  $currency',
                    style: ts(15, w: w8, c: soft),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'C\'est l\'argent que tu peux utiliser tout de suite, tous comptes réunis.',
            style: ts(12.5, w: w6, c: soft, h: 1.4),
          ),
          if (parts.isNotEmpty) ...[
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: SizedBox(
                height: 12,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < parts.length; i++) ...[
                      if (i > 0) const SizedBox(width: 3),
                      Expanded(
                        // Une part minimale pour que les petits comptes restent visibles.
                        flex: math.max(
                          (parts[i].$2 * 1000 / math.max(available, 1)).round(),
                          8,
                        ),
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: colorOf(i),
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            LayoutBuilder(
              builder: (context, c) {
                final w = (c.maxWidth - 14) / 2;
                return Wrap(
                  spacing: 14,
                  runSpacing: 8,
                  children: [
                    for (var i = 0; i < parts.length; i++)
                      SizedBox(
                        width: w,
                        child: Row(
                          children: [
                            Container(
                              width: 9,
                              height: 9,
                              decoration: BoxDecoration(
                                color: colorOf(i),
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Text(
                                parts[i].$1.name.replaceFirst(
                                  RegExp(r'^Compte\s+', caseSensitive: false),
                                  '',
                                ),
                                style: ts(12, w: w7, c: soft),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              store.hidden ? '•••' : num0(parts[i].$2),
                              style: ts(12.5, w: w8, c: fg),
                            ),
                          ],
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}

/// Petit bouton carré (cloche) en verre.
class _SquareButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _SquareButton(this.icon, this.onTap);
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: SizedBox(
      width: 46,
      height: 46,
      child: Glass(
        radius: 16,
        padding: EdgeInsets.zero,
        child: Center(child: Icon(icon, size: 21, color: C.text)),
      ),
    ),
  );
}

/// Bouton d'action rapide (Dépense, Entrée…) : carré en verre, icône colorée avec un halo.
class _Action extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _Action(this.label, this.icon, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          SizedBox(
            width: 62,
            height: 62,
            child: Glass(
              radius: 22,
              padding: EdgeInsets.zero,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          color.withValues(alpha: store.dark ? 0.32 : 0.18),
                          color.withValues(alpha: 0),
                        ],
                      ),
                    ),
                  ),
                  Icon(icon, color: color, size: 26),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: ts(12, w: w7),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    ),
  );
}

/// Carte de la grille : icône, libellé, valeur, petite ligne en dessous.
class _Tile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label, value;
  final (String, Color) sub;
  final VoidCallback? onTap;
  final double? progress;
  const _Tile(
    this.icon,
    this.color,
    this.label,
    this.value,
    this.sub, {
    this.onTap,
    this.progress,
  });
  @override
  Widget build(BuildContext context) => AppCard(
    onTap: onTap,
    margin: EdgeInsets.zero,
    padding: const EdgeInsets.all(14),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: color.withValues(alpha: store.dark ? 0.18 : 0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withValues(alpha: 0.3)),
          ),
          child: Icon(icon, size: 18, color: color),
        ),
        const SizedBox(height: 12),
        Text(
          label,
          style: ts(12, w: w7, c: C.muted),
        ),
        const SizedBox(height: 2),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(value, style: ts(20, w: w8, ls: -0.4)),
        ),
        if (progress != null) ...[
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: SizedBox(
              height: 6,
              child: Stack(
                children: [
                  Container(color: const Color(0x2E7F7F7F)),
                  FractionallySizedBox(
                    widthFactor: progress!,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [C.primary, C.income]),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
        const SizedBox(height: 4),
        Text(
          sub.$1,
          style: ts(11, w: w7, c: sub.$2),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    ),
  );
}

/// Mes comptes : petites cartes en verre, 3 par ligne, plus « Ajouter un compte ».
class _AccountGrid extends StatelessWidget {
  final List<Account> accounts;
  const _AccountGrid(this.accounts);
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      const gap = 10.0;
      final w = (c.maxWidth - gap * 2) / 3;
      Widget tile(Widget child, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: SizedBox(
          width: w,
          height: 128,
          child: Glass(
            radius: store.dark ? 20 : cardRadius,
            padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
            child: child,
          ),
        ),
      );
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: [
          for (final a in accounts)
            tile(
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AccountBadge(a, size: 38),
                  const SizedBox(height: 10),
                  Text(
                    a.name,
                    style: ts(13, w: w8),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    accountTypeLabel(a.type),
                    style: ts(10.5, w: w6, c: C.muted),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const Spacer(),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: store.hidden ? '•••' : num0(store.balance(a)),
                            style: ts(15, w: w8, ls: -0.4),
                          ),
                          TextSpan(
                            text: ' F',
                            style: ts(11, w: w7, c: C.muted),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              () => push(context, AccountDetailScreen(id: a.id)),
            ),
          tile(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconBubble(Icons.add_rounded, C.primary, size: 38),
                const SizedBox(height: 10),
                Text('Ajouter', style: ts(13, w: w8)),
                Text(
                  'un compte',
                  style: ts(10.5, w: w6, c: C.muted),
                ),
              ],
            ),
            () => push(context, const AccountFormScreen()),
          ),
        ],
      );
    },
  );
}

/// Bandeau bleu (import, mise à jour).
class _Banner extends StatelessWidget {
  final IconData icon;
  final String title, text;
  final VoidCallback onTap;
  const _Banner(this.icon, this.title, this.text, this.onTap);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: GestureDetector(
      onTap: onTap,
      child: GradientBox(
        gradient: primaryGradient,
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 26),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: ts(15, w: w8, c: Colors.white),
                  ),
                  Text(
                    text,
                    style: ts(12, w: w6, c: Colors.white70),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

/// Conseil simple tiré des chiffres du mois.
String? _insight(MonthSummary sm, MonthSummary prev) {
  final cats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
  if (cats.isEmpty) return null;
  final prevBy = {for (final c in prev.byCategory) c.cat.id: c.total};
  // La catégorie qui a le plus changé par rapport au mois dernier
  CatTotal? best;
  var bestDelta = 0;
  for (final c in cats) {
    final p = prevBy[c.cat.id] ?? 0;
    if (p == 0) continue;
    final d = c.total - p;
    if (d.abs() > bestDelta.abs()) {
      best = c;
      bestDelta = d;
    }
  }
  if (best != null) {
    final p = prevBy[best.cat.id]!;
    final pc = (bestDelta.abs() / p * 100).round();
    return bestDelta < 0
        ? 'Bravo : ${best.cat.name} en baisse de $pc % par rapport au mois dernier (${money(bestDelta.abs())} de moins).'
        : '${best.cat.name} en hausse de $pc % par rapport au mois dernier (${money(bestDelta)} de plus).';
  }
  final top = cats.first;
  final total = sm.expense == 0 ? 1 : sm.expense;
  return '${top.cat.name} représente ${(top.total / total * 100).round()} % de tes dépenses ce mois.';
}

/// Propose d'importer le suivi complet (remplace les données actuelles).
Future<void> askImportHistory(BuildContext context) async {
  if (!await confirmDialog(
    context,
    'Importer mon suivi complet',
    'Toutes tes opérations de septembre, octobre et novembre 2026, tes prêts, tes dettes, tes placements '
        'et l\'historique de tes revenus depuis septembre 2025.\n\n'
        'Ce que tu avais déjà dans l\'app (l\'ancien septembre) sera remplacé.',
    ok: 'Importer',
  )) {
    return;
  }
  await store.importHistory();
  if (context.mounted)
    toast(context, 'Import terminé ✅ Tes soldes sont à jour au 3 novembre.');
}
