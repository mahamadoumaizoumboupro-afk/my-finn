import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

import 'package:flutter/foundation.dart' show kIsWeb;

import 'accounts.dart';
import 'avoirs.dart';
import 'budget.dart';
import 'debts.dart';
import 'settings.dart';
import 'tx_form.dart';
import '../update.dart';

String greeting() {
  final h = DateTime.now().hour;
  return h < 12
      ? 'Bonjour'
      : h < 18
      ? 'Bon après-midi'
      : 'Bonsoir';
}

/// Périodes de la courbe du solde.
const _periods = ['1S', '1M', '3M', '1A', 'Tout'];

class HomeScreen extends StatefulWidget {
  final void Function(int) goTab;
  const HomeScreen({super.key, required this.goTab});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String period = '1M';

  /// Solde disponible à différentes dates de la période choisie.
  List<int> _series() {
    final end = DateTime.parse(today());
    final dates = <DateTime>[];
    switch (period) {
      case '1S':
        for (var i = 7; i >= 0; i--) {
          dates.add(end.subtract(Duration(days: i)));
        }
      case '1M':
        for (var i = 30; i >= 0; i--) {
          dates.add(end.subtract(Duration(days: i)));
        }
      case '3M':
        for (var i = 90; i >= 0; i -= 3) {
          dates.add(end.subtract(Duration(days: i)));
        }
      case '1A':
        for (var i = 12; i >= 1; i--) {
          dates.add(DateTime(end.year, end.month - i + 1, 0));
        }
        dates.add(end);
      default:
        final first = store.txs.isEmpty
            ? end
            : DateTime.parse(
                store.txs
                    .map((t) => t.date)
                    .reduce((a, b) => a.compareTo(b) < 0 ? a : b),
              );
        var m = DateTime(first.year, first.month, 0);
        while (m.isBefore(end)) {
          dates.add(m);
          m = DateTime(m.year, m.month + 2, 0);
        }
        dates.add(end);
    }
    return [for (final d in dates) store.available(until: toISO(d))];
  }

  @override
  Widget build(BuildContext context) => Watch((context) {
    final goTab = widget.goTab;
    final month = currentMonth();
    final sm = store.summary(month);
    final prev = store.summary(shiftMonth(month, -1));
    final accounts = store.activeAccounts
        .where((a) => a.includeInTotal)
        .toList();
    final avoirs = store.avoirs();
    final available = store.available();
    final expenseCats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
    final due = store.dueDebts();
    final overBudget = expenseCats
        .where((c) => c.cat.budget > 0 && c.total >= c.cat.budget * 0.8)
        .toList();
    final recent = store.transactions(limit: 5);
    final series = _series();
    final delta = available - series.first;
    final pc = series.first == 0 ? null : delta / series.first.abs() * 100;
    final spent = sm.expense + sm.fees;
    final saved = sm.income - spent;
    final tip = _insight(sm, prev);
    final up = delta >= 0;
    final name = store.settings['name']?.isNotEmpty == true
        ? store.settings['name']!
        : 'Mahamadou';
    final periodLabel = switch (period) {
      '1S' => '7 jours',
      '1M' => '1 mois',
      '3M' => '3 mois',
      '1A' => '1 an',
      _ => 'le début',
    };

    return PageScaffold(
      children: [
        // En-tête : salutation + photo
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${greeting()},',
                      style: ts(14, w: w6, c: C.muted),
                    ),
                    Text(
                      name,
                      style: ts(22, w: w8),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Stack(
                children: [
                  RoundIconButton(
                    Icons.notifications_none_rounded,
                    onTap: () => push(
                      context,
                      due.isNotEmpty
                          ? const DebtsScreen()
                          : BudgetScreen(month: month),
                    ),
                  ),
                  if (due.isNotEmpty || overBudget.isNotEmpty)
                    Positioned(right: 10, top: 10, child: dot(C.expense, 8)),
                ],
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => push(context, const SettingsScreen()),
                child: ProfilePhoto(name: name, size: 48),
              ),
            ],
          ),
        ),
        // Carte principale bleu ardoise : solde + courbe + période
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          decoration: BoxDecoration(
            gradient: heroGradient,
            borderRadius: BorderRadius.circular(cardRadius),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    'Solde disponible',
                    style: ts(13, w: w7, c: Colors.white70),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => store.setSetting(
                      'hide_amounts',
                      store.hidden ? '0' : '1',
                    ),
                    child: Icon(
                      store.hidden
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                      size: 16,
                      color: Colors.white70,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      monthLabel(month).split(' ').first,
                      style: ts(12, w: w7, c: Colors.white),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: store.hidden ? '•••••' : num0(available),
                        style: ts(36, w: w8, c: Colors.white),
                      ),
                      TextSpan(
                        text: '  $currency',
                        style: ts(14, w: w7, c: Colors.white70),
                      ),
                    ],
                  ),
                ),
              ),
              if (pc != null && !store.hidden)
                Row(
                  children: [
                    Icon(
                      up
                          ? Icons.trending_up_rounded
                          : Icons.trending_down_rounded,
                      size: 16,
                      color: up
                          ? const Color(0xFF6EE7B7)
                          : const Color(0xFFFF9EA1),
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        '${up ? '+' : '−'}${num0(delta.abs())} · ${up ? '+' : '−'}${pc.abs().toStringAsFixed(1).replaceAll('.', ',')} % sur $periodLabel',
                        style: ts(
                          12,
                          w: w7,
                          c: up
                              ? const Color(0xFF6EE7B7)
                              : const Color(0xFFFF9EA1),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 8),
              Sparkline(series, color: curveBlue, height: 84),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    for (final p in _periods)
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => period = p),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            height: 36,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: period == p
                                  ? electricBlue
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              p,
                              style: ts(
                                12,
                                w: w8,
                                c: period == p ? Colors.white : Colors.white60,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // Actions rapides
        Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(
            children: [
              _Action(
                'Dépense',
                Icons.north_east_rounded,
                C.expense,
                () => push(context, const TxFormScreen(type: TxType.expense)),
              ),
              const SizedBox(width: 8),
              _Action(
                'Entrée',
                Icons.south_west_rounded,
                C.income,
                () => push(context, const TxFormScreen(type: TxType.income)),
              ),
              const SizedBox(width: 8),
              _Action(
                'Transfert',
                Icons.swap_horiz_rounded,
                C.transfer,
                () => push(context, const TxFormScreen(type: TxType.transfer)),
              ),
              const SizedBox(width: 8),
              _Action(
                'Prêt',
                Icons.handshake_rounded,
                C.transfer,
                () => push(
                  context,
                  const DebtFormScreen(direction: DebtDirection.lent),
                ),
              ),
            ],
          ),
        ),
        if (!kIsWeb && !store.historyImported)
          _Banner(
            Icons.download_rounded,
            'Ton suivi complet est prêt',
            'Septembre 2025 → 3 novembre 2026. Appuie pour l\'importer.',
            () => askImportHistory(context),
          ),
        ValueListenableBuilder<UpdateInfo?>(
          valueListenable: updateAvailable,
          builder: (context, up, _) => up == null
              ? const SizedBox.shrink()
              : _Banner(
                  Icons.system_update_rounded,
                  'Nouvelle version disponible',
                  'Version ${up.label} · appuie pour la télécharger, puis installe-la. Tes données sont gardées.',
                  () => openUpdate(up),
                ),
        ),
        if (due.isNotEmpty || overBudget.isNotEmpty)
          AppCard(
            color: C.warnSoft,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.notifications_active_rounded,
                      color: C.warn,
                      size: 19,
                    ),
                    const SizedBox(width: 8),
                    Text('À surveiller', style: ts(15, w: w8)),
                  ],
                ),
                const SizedBox(height: 6),
                for (final d in due)
                  GestureDetector(
                    onTap: () => push(context, DebtDetailScreen(id: d.id)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Text(
                        '${d.direction == DebtDirection.lent ? '${d.person} doit te rembourser' : 'Tu dois rembourser ${d.person}'} '
                        '${money(store.remaining(d))} · échéance ${shortDate(d.dueDate!)}',
                        style: ts(13, w: w6),
                      ),
                    ),
                  ),
                for (final c in overBudget)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Text(
                      '${c.cat.name} : ${money(c.total)} sur un budget de ${money(c.cat.budget)}${c.total > c.cat.budget ? ' (dépassé)' : ''}',
                      style: ts(13, w: w6),
                    ),
                  ),
              ],
            ),
          ),
        // Le mois en bref : grille 2 colonnes
        SectionTitle(
          '${monthLabel(month).split(' ').first} en bref',
          trailing: LinkText('Bilan', onTap: () => goTab(3)),
        ),
        Row(
          children: [
            Expanded(
              child: _Tile(
                Icons.south_west_rounded,
                C.income,
                'Entrées',
                money(sm.income),
                _vs(sm.income, prev.income, false),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _Tile(
                Icons.north_east_rounded,
                C.expense,
                'Dépenses',
                money(spent),
                _vs(spent, prev.expense + prev.fees, true),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _Tile(
                Icons.savings_rounded,
                C.primary,
                'Épargné',
                sm.income > 0 ? '${(saved / sm.income * 100).round()} %' : '—',
                (
                  sm.income > 0
                      ? '${money(saved)} gardés'
                      : 'pas encore d\'entrée',
                  C.muted,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _Tile(
                Icons.diamond_rounded,
                C.primary,
                'Mes avoirs',
                money(avoirs.total),
                ('tout compris', C.muted),
                onTap: () => push(context, const AvoirsScreen()),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        if (tip != null)
          AppCard(
            color: C.primarySoft,
            child: Row(
              children: [
                IconBubble(Icons.lightbulb_rounded, C.primary, size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Conseil du mois',
                        style: ts(12, w: w8, c: C.primary),
                      ),
                      const SizedBox(height: 2),
                      Text(tip, style: ts(14, w: w7)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        // Mes comptes, avec leurs logos
        SectionTitle(
          'Mes comptes',
          trailing: LinkText(
            'Voir tout',
            onTap: () => push(context, const AccountsScreen()),
          ),
        ),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              for (final a in accounts)
                InkWell(
                  onTap: () => push(context, AccountDetailScreen(id: a.id)),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: C.border)),
                    ),
                    child: Row(
                      children: [
                        AccountBadge(a),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(a.name, style: ts(15, w: w7)),
                              Text(
                                accountTypeLabel(a.type),
                                style: ts(12, c: C.muted),
                              ),
                            ],
                          ),
                        ),
                        Text(money(store.balance(a)), style: ts(15, w: w8)),
                      ],
                    ),
                  ),
                ),
              InkWell(
                onTap: () => push(context, const AccountFormScreen()),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Row(
                    children: [
                      Icon(Icons.add_circle_outline_rounded, color: C.primary),
                      const SizedBox(width: 10),
                      Text(
                        'Ajouter un compte',
                        style: ts(14, w: w7, c: C.primary),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SectionTitle(
          'Dernières opérations',
          trailing: LinkText('Tout voir', onTap: () => goTab(1)),
        ),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: recent.isEmpty
              ? const EmptyState(
                  'Aucune opération. Appuie sur + pour commencer.',
                )
              : Column(
                  children: [
                    for (var i = 0; i < recent.length; i++)
                      TxTile(
                        recent[i],
                        last: i == recent.length - 1,
                        onTap: () =>
                            push(context, TxFormScreen(id: recent[i].id)),
                      ),
                  ],
                ),
        ),
      ],
    );
  });

  /// Évolution par rapport au mois dernier, en vert si c'est bien.
  (String, Color) _vs(int v, int prev, bool lowerIsBetter) {
    if (prev == 0) return ('mois dernier : 0', C.muted);
    final pc = (v - prev) / prev.abs() * 100;
    final good = lowerIsBetter ? pc <= 0 : pc >= 0;
    return (
      '${pc >= 0 ? '+' : '−'}${pc.abs().toStringAsFixed(1).replaceAll('.', ',')} % vs mois dernier',
      good ? C.income : C.expense,
    );
  }
}

/// Bouton d'action rapide (Dépense, Entrée…).
class _Action extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _Action(this.label, this.icon, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
    child: AppCard(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          IconBubble(icon, color, size: 38),
          const SizedBox(height: 6),
          Text(
            label,
            style: ts(12, w: w7),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    ),
  );
}

/// Carte de la grille : icône, libellé, valeur, petite ligne en dessous.
class _Tile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label, value;
  final (String, Color) sub;
  final VoidCallback? onTap;
  const _Tile(
    this.icon,
    this.color,
    this.label,
    this.value,
    this.sub, {
    this.onTap,
  });
  @override
  Widget build(BuildContext context) => AppCard(
    onTap: onTap,
    margin: EdgeInsets.zero,
    padding: const EdgeInsets.all(12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        IconBubble(icon, color, size: 36),
        const SizedBox(height: 8),
        Text(
          label,
          style: ts(12, w: w6, c: C.muted),
        ),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(value, style: ts(18, w: w8)),
        ),
        Text(
          sub.$1,
          style: ts(11, w: w7, c: sub.$2),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    ),
  );
}

/// Bandeau bleu (import, mise à jour).
class _Banner extends StatelessWidget {
  final IconData icon;
  final String title, text;
  final VoidCallback onTap;
  const _Banner(this.icon, this.title, this.text, this.onTap);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: GestureDetector(
      onTap: onTap,
      child: GradientBox(
        gradient: primaryGradient,
        radius: cardRadius,
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 26),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: ts(15, w: w8, c: Colors.white),
                  ),
                  Text(
                    text,
                    style: ts(12, w: w6, c: Colors.white70),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

/// Conseil simple tiré des chiffres du mois.
String? _insight(MonthSummary sm, MonthSummary prev) {
  final cats = sm.byCategory.where((c) => !c.cat.isIncome).toList();
  if (cats.isEmpty) return null;
  final prevBy = {for (final c in prev.byCategory) c.cat.id: c.total};
  // La catégorie qui a le plus changé par rapport au mois dernier
  CatTotal? best;
  var bestDelta = 0;
  for (final c in cats) {
    final p = prevBy[c.cat.id] ?? 0;
    if (p == 0) continue;
    final d = c.total - p;
    if (d.abs() > bestDelta.abs()) {
      best = c;
      bestDelta = d;
    }
  }
  if (best != null) {
    final p = prevBy[best.cat.id]!;
    final pc = (bestDelta.abs() / p * 100).round();
    return bestDelta < 0
        ? 'Bravo : ${best.cat.name} en baisse de $pc % par rapport au mois dernier (${money(bestDelta.abs())} de moins).'
        : '${best.cat.name} en hausse de $pc % par rapport au mois dernier (${money(bestDelta)} de plus).';
  }
  final top = cats.first;
  final total = sm.expense == 0 ? 1 : sm.expense;
  return '${top.cat.name} représente ${(top.total / total * 100).round()} % de tes dépenses ce mois.';
}

/// Propose d'importer le suivi complet (remplace les données actuelles).
Future<void> askImportHistory(BuildContext context) async {
  if (!await confirmDialog(
    context,
    'Importer mon suivi complet',
    'Toutes tes opérations de septembre, octobre et novembre 2026, tes prêts, tes dettes, tes placements '
        'et l\'historique de tes revenus depuis septembre 2025.\n\n'
        'Ce que tu avais déjà dans l\'app (l\'ancien septembre) sera remplacé.',
    ok: 'Importer',
  )) {
    return;
  }
  await store.importHistory();
  if (context.mounted)
    toast(context, 'Import terminé ✅ Tes soldes sont à jour au 3 novembre.');
}
