import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});
  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  String month = currentMonth();
  TxType? type;
  final search = TextEditingController();

  @override
  Widget build(BuildContext context) => Watch((context) {
    final list = store.transactions(
      month: month,
      type: type,
      search: search.text,
    );
    final days = <String, List<Tx>>{};
    for (final t in list) {
      days.putIfAbsent(t.date, () => []).add(t);
    }
    final inc = list
        .where((t) => t.type == TxType.income)
        .fold<int>(0, (x, t) => x + t.amount);
    final exp = list
        .where((t) => t.type == TxType.expense)
        .fold<int>(0, (x, t) => x + t.amount);
    return PageScaffold(
      title: 'Opérations',
      children: [
        MonthSwitcher(
          month: month,
          onChanged: (m) => setState(() => month = m),
        ),
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: glassFill,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: glassBorder, width: 1.2),
          ),
          child: TextField(
            controller: search,
            onChanged: (_) => setState(() {}),
            style: ts(15),
            decoration: InputDecoration(
              hintText: 'Rechercher un libellé, une personne…',
              hintStyle: ts(15, c: C.faint),
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search_rounded, color: C.muted),
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
        Segmented<TxType?>(
          value: type,
          onChanged: (v) => setState(() => type = v),
          options: [
            (null, 'Tout', null),
            (TxType.expense, 'Dépenses', C.expense),
            (TxType.income, 'Entrées', C.income),
            (TxType.transfer, 'Transferts', C.transfer),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: _Total(
                'Entrées',
                '+${money(inc)}',
                C.income,
                C.incomeSoft,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _Total(
                'Dépenses',
                '−${money(exp)}',
                C.expense,
                C.expenseSoft,
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(
            '${list.length} opérations',
            style: ts(12, w: w6, c: C.muted),
          ),
        ),
        if (list.isEmpty) const EmptyState('Aucune opération pour ce mois.'),
        for (final e in days.entries) ...[
          Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 6),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    dayLabel(e.key),
                    style: ts(13, w: w8, c: C.muted),
                  ),
                ),
                if (e.value.any((t) => t.type == TxType.expense))
                  Text(
                    '−${money(e.value.where((t) => t.type == TxType.expense).fold<int>(0, (x, t) => x + t.amount))}',
                    style: ts(12, w: w7, c: C.muted),
                  ),
              ],
            ),
          ),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(
              children: [
                for (var i = 0; i < e.value.length; i++)
                  TxTile(
                    e.value[i],
                    last: i == e.value.length - 1,
                    onTap: () => push(context, TxFormScreen(id: e.value[i].id)),
                  ),
              ],
            ),
          ),
        ],
      ],
    );
  });
}

class _Total extends StatelessWidget {
  final String label, value;
  final Color color, bg;
  const _Total(this.label, this.value, this.color, this.bg);
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      gradient: fillGradient(color),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white.withValues(alpha: 0.35)),
      boxShadow: [
        BoxShadow(
          color: color.withValues(alpha: 0.35),
          blurRadius: 16,
          offset: const Offset(0, 7),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: ts(12, w: w7, c: Colors.white.withValues(alpha: 0.9)),
        ),
        FittedBox(
          child: Text(
            value,
            style: ts(16, w: w8, c: Colors.white),
          ),
        ),
      ],
    ),
  );
}
