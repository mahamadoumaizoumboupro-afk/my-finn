import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});
  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  String month = currentMonth();
  TxType? type;
  bool searching = false;
  final search = TextEditingController();

  @override
  Widget build(BuildContext context) => Watch((context) {
    final list = store.transactions(
      month: month,
      type: type,
      search: search.text,
    );
    final days = <String, List<Tx>>{};
    for (final t in list) {
      days.putIfAbsent(t.date, () => []).add(t);
    }
    // totaux du mois comme dans le Bilan (« Pour quel mois ? » compris)
    final all = store.transactions(month: month, byPeriod: true);
    final inc = all
        .where((t) => t.type == TxType.income)
        .fold<int>(0, (x, t) => x + t.amount);
    final exp = all
        .where((t) => t.type == TxType.expense)
        .fold<int>(0, (x, t) => x + t.amount);
    final mShort = monthLabel(month).substring(0, 3).toLowerCase();
    return PageScaffold(
      title: 'Opérations',
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          MonthChip(month: month, onChanged: (m) => setState(() => month = m)),
          const SizedBox(width: 8),
          RoundIconButton(
            searching ? Icons.close_rounded : Icons.search_rounded,
            onTap: () => setState(() {
              searching = !searching;
              if (!searching) search.clear();
            }),
          ),
        ],
      ),
      children: [
        if (searching)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: C.border),
            ),
            child: TextField(
              controller: search,
              autofocus: true,
              onChanged: (_) => setState(() {}),
              style: ts(15),
              decoration: InputDecoration(
                hintText: 'Rechercher un libellé, une personne…',
                hintStyle: ts(15, c: C.faint),
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search_rounded, color: C.muted),
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
        Segmented<TxType?>(
          value: type,
          onChanged: (v) => setState(() => type = v),
          options: [
            (null, 'Tout', null),
            (TxType.income, 'Entrées', null),
            (TxType.expense, 'Dépenses', null),
            (TxType.transfer, 'Transferts', null),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: _Total('Entrées · $mShort.', '+${num0(inc)}', C.income),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _Total('Dépenses · $mShort.', '−${num0(exp)}', C.expense),
            ),
          ],
        ),
        if (list.isEmpty) const EmptyState('Aucune opération pour ce mois.'),
        for (final e in days.entries) ...[
          Padding(
            padding: const EdgeInsets.only(top: 4, bottom: 8),
            child: Text(
              dayLabel(e.key).toUpperCase(),
              style: ts(11, w: w7, c: C.muted, ls: 0.6),
            ),
          ),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(
              children: [
                for (var i = 0; i < e.value.length; i++)
                  TxTile(
                    e.value[i],
                    last: i == e.value.length - 1,
                    onTap: () => push(context, TxFormScreen(id: e.value[i].id)),
                  ),
              ],
            ),
          ),
        ],
      ],
    );
  });
}

class _Total extends StatelessWidget {
  final String label, value;
  final Color color;
  const _Total(this.label, this.value, this.color);
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 16),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: C.card,
      borderRadius: BorderRadius.circular(cardRadius),
      border: Border.all(color: C.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: ts(12, w: w6, c: C.muted),
        ),
        const SizedBox(height: 2),
        FittedBox(
          child: Text(
            value,
            style: ts(16, w: w8, c: color),
          ),
        ),
      ],
    ),
  );
}
