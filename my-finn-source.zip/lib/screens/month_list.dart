import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

/// Toutes les entrées (ou toutes les dépenses) comptées dans le Bilan d'un mois.
class MonthTxScreen extends StatelessWidget {
  final String month;
  final TxType type;
  const MonthTxScreen({super.key, required this.month, required this.type});

  @override
  Widget build(BuildContext context) {
    final inc = type == TxType.income;
    final color = inc ? C.income : C.expense;
    final list = store.bilanTxs(month, type);
    final fees = inc ? 0 : store.summary(month).fees;
    final total = list.fold(0, (x, t) => x + t.amount) + fees;
    final days = <String, List<Tx>>{};
    for (final t in list) {
      days.putIfAbsent(t.date, () => []).add(t);
    }
    final name = monthLabel(month).split(' ').first.toLowerCase();
    return SubPage(
      title: '${inc ? 'Entrées' : 'Dépenses'} · $name',
      children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(cardRadius),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Total du mois',
                style: ts(12, w: w7, c: color),
              ),
              FittedBox(
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: '${inc ? '+' : '−'}${num0(total)} ',
                        style: ts(30, w: w8, c: color, ls: -1),
                      ),
                      TextSpan(
                        text: 'FCFA',
                        style: ts(14, w: w8, c: color),
                      ),
                    ],
                  ),
                ),
              ),
              Text(
                list.length == 1
                    ? '1 ${inc ? 'entrée' : 'dépense'}'
                    : '${list.length} ${inc ? 'entrées' : 'dépenses'}',
                style: ts(12, w: w6, c: C.muted),
              ),
            ],
          ),
        ),
        if (list.isEmpty)
          EmptyState(
            inc ? 'Aucune entrée ce mois.' : 'Aucune dépense ce mois.',
          ),
        for (final e in days.entries) ...[
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 8),
            child: Text(
              dayLabel(e.key).toUpperCase(),
              style: ts(11, w: w7, c: C.muted, ls: 0.6),
            ),
          ),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(
              children: [
                for (var i = 0; i < e.value.length; i++)
                  TxTile(
                    e.value[i],
                    last: i == e.value.length - 1,
                    onTap: () => push(context, TxFormScreen(id: e.value[i].id)),
                  ),
              ],
            ),
          ),
        ],
        if (fees > 0)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Frais de transfert du mois',
                    style: ts(13, w: w6, c: C.muted),
                  ),
                ),
                Text('−${num0(fees)}', style: ts(14, w: w8)),
              ],
            ),
          ),
      ],
    );
  }
}
