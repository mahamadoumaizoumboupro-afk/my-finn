import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

/// Toutes les entrées (ou toutes les dépenses) comptées dans le Bilan d'un mois.
class MonthTxScreen extends StatelessWidget {
  final String month;
  final TxType type;
  const MonthTxScreen({super.key, required this.month, required this.type});

  @override
  Widget build(BuildContext context) {
    final inc = type == TxType.income;
    final color = inc ? C.income : C.expense;
    final list = store.bilanTxs(month, type);
    final fees = inc ? 0 : store.summary(month).fees;
    final total = list.fold(0, (x, t) => x + t.amount) + fees;
    final days = <String, List<Tx>>{};
    for (final t in list) {
      days.putIfAbsent(t.trace ? 'trace' : t.date, () => []).add(t);
    }
    final name = monthLabel(month).split(' ').first.toLowerCase();
    return SubPage(
      title: '${inc ? 'Entrées' : 'Dépenses'} · $name',
      children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(cardRadius),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Total du mois',
                style: ts(12, w: w7, c: color),
              ),
              FittedBox(
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: '${inc ? '+' : '−'}${num0(total)} ',
                        style: ts(30, w: w8, c: color, ls: -1),
                      ),
                      TextSpan(
                        text: 'FCFA',
                        style: ts(14, w: w8, c: color),
                      ),
                    ],
                  ),
                ),
              ),
              Text(
                list.length == 1
                    ? '1 ${inc ? 'entrée' : 'dépense'}'
                    : '${list.length} ${inc ? 'entrées' : 'dépenses'}',
                style: ts(12, w: w6, c: C.muted),
              ),
            ],
          ),
        ),
        if (list.isEmpty)
          EmptyState(
            inc ? 'Aucune entrée ce mois.' : 'Aucune dépense ce mois.',
          ),
        for (final e in days.entries) ...[
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 8),
            child: Text(
              e.key == 'trace'
                  ? 'NOTÉES APRÈS COUP · SANS JOUR PRÉCIS'
                  : dayLabel(e.key).toUpperCase(),
              style: ts(11, w: w7, c: C.muted, ls: 0.6),
            ),
          ),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(
              children: [
                for (var i = 0; i < e.value.length; i++)
                  TxTile(
                    e.value[i],
                    last: i == e.value.length - 1,
                    onTap: () => push(context, TxFormScreen(id: e.value[i].id)),
                  ),
              ],
            ),
          ),
        ],
        if (fees > 0)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Frais de transfert du mois',
                    style: ts(13, w: w6, c: C.muted),
                  ),
                ),
                Text('−${num0(fees)}', style: ts(14, w: w8)),
              ],
            ),
          ),
      ],
    );
  }
}

/// Entrées d'un mois d'avant l'app (historique importé), avec leurs détails :
/// nom de la mission, du client, de la personne…
class HistList extends StatelessWidget {
  final List<HistIncome> items;
  const HistList(this.items, {super.key});
  @override
  Widget build(BuildContext context) {
    final sorted = [...items]..sort((a, b) => b.amount.compareTo(a.amount));
    final tax = items.fold(0, (x, h) => x + h.tax);
    return Column(
      children: [
        for (var i = 0; i < sorted.length; i++)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              border: i == sorted.length - 1 && tax == 0
                  ? null
                  : Border(bottom: BorderSide(color: C.border)),
            ),
            child: Row(
              children: [
                IconBubble(_iconOf(sorted[i].source), C.income, size: 38),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              sorted[i].label.isEmpty
                                  ? sorted[i].source
                                  : sorted[i].label,
                              style: ts(14, w: w7),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (sorted[i].est) estTag(),
                        ],
                      ),
                      if (sorted[i].label.isNotEmpty &&
                          sorted[i].label != sorted[i].source)
                        Text(
                          sorted[i].source,
                          style: ts(12, c: C.muted),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '+${num0(sorted[i].amount)}',
                  style: ts(14, w: w8, c: C.income),
                ),
              ],
            ),
          ),
        if (tax > 0)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Taxes déjà retirées',
                    style: ts(12, w: w6, c: C.muted),
                  ),
                ),
                Text(
                  '−${num0(tax)}',
                  style: ts(13, w: w8, c: C.expense),
                ),
              ],
            ),
          ),
      ],
    );
  }

  static IconData _iconOf(String source) {
    final s = source.toLowerCase();
    if (s.contains('salaire')) return Icons.work_rounded;
    if (s.contains('mission')) return Icons.flight_takeoff_rounded;
    if (s.contains('gombo')) return Icons.handyman_rounded;
    if (s.contains('carburant')) return Icons.local_gas_station_rounded;
    if (s.contains('cadeau')) return Icons.card_giftcard_rounded;
    if (s.contains('gratif')) return Icons.volunteer_activism_rounded;
    return Icons.south_west_rounded;
  }
}

/// « Voir tout » des entrées d'un mois d'avant l'app.
class HistMonthScreen extends StatelessWidget {
  final String month;
  const HistMonthScreen({super.key, required this.month});
  @override
  Widget build(BuildContext context) {
    final items = store.history.where((h) => h.month == month).toList();
    final net = items.fold(0, (x, h) => x + h.amount - h.tax);
    final name = monthLabel(month).toLowerCase();
    return SubPage(
      title: 'Entrées · $name',
      children: [
        AppCard(
          color: store.dark ? null : C.incomeSoft,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Total du mois (net)',
                style: ts(12, w: w7, c: C.income),
              ),
              Text(
                '+${num0(net)} $currency',
                style: ts(28, w: w8, c: C.income),
              ),
              Text(
                '${items.length} entrée${items.length > 1 ? 's' : ''} · d\'après ton historique',
                style: ts(12, w: w6, c: C.muted),
              ),
            ],
          ),
        ),
        AppCard(child: HistList(items)),
        Text(
          'Avant septembre 2026, seules tes entrées sont dans l\'app (pas encore tes dépenses).',
          style: ts(12, c: C.muted),
        ),
      ],
    );
  }
}
