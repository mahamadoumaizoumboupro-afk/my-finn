import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../storage/storage.dart' show savePhoto;

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'accounts.dart';
import 'avoirs.dart';
import 'home.dart' show askImportHistory;
import 'revenus.dart';
import 'report.dart' show shareText;
import '../update.dart';
import '../cloud.dart';
import 'cloud.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool income = false;
  final cur = TextEditingController(text: currency);

  Future<void> _pickPhoto() async {
    try {
      final f = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 600,
        imageQuality: 85,
      );
      if (f == null) return;
      final path = await savePhoto(await f.readAsBytes());
      if (path != null) store.setSetting('photo_path', path);
      if (mounted) toast(context, 'Photo enregistrée');
    } catch (e) {
      if (mounted) toast(context, 'Impossible d\'ouvrir la galerie.');
    }
  }

  @override
  Widget build(BuildContext context) => Watch((context) {
    final cats = store.cats(income: income);
    return SubPage(
      title: 'Réglages',
      children: [
        if (!kIsWeb)
          AppCard(
            onTap: _pickPhoto,
            child: Row(
              children: [
                ProfilePhoto(
                  name: store.settings['name']?.isNotEmpty == true
                      ? store.settings['name']!
                      : 'Mahamadou',
                  size: 56,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Ma photo', style: ts(15, w: w8)),
                      Text(
                        'Appuie pour la choisir dans ta galerie. Elle reste sur ce téléphone.',
                        style: ts(12, c: C.muted),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.photo_library_rounded, color: C.primary),
              ],
            ),
          ),
        const SectionTitle('Apparence et confidentialité'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              _switch(
                Icons.dark_mode_rounded,
                C.primary,
                'Mode sombre',
                null,
                store.dark,
                (v) => store.setSetting('theme', v ? 'dark' : 'light'),
              ),
              _switch(
                Icons.visibility_off_rounded,
                C.accent,
                'Masquer les montants',
                'Pratique en public',
                store.hidden,
                (v) => store.setSetting('hide_amounts', v ? '1' : '0'),
              ),
              _switch(
                Icons.lock_rounded,
                C.expense,
                'Code PIN au démarrage',
                "Avec l'empreinte digitale si ton téléphone l'a",
                store.pinHash != null,
                (v) async {
                  if (v) {
                    push(context, const PinSetupScreen());
                  } else if (await confirmDialog(
                    context,
                    'Retirer le code',
                    "L'app ne demandera plus de code à l'ouverture.",
                    ok: 'Retirer',
                    danger: true,
                  )) {
                    store.setSetting('pin_hash', '');
                  }
                },
                last: true,
              ),
            ],
          ),
        ),
        const SectionTitle('Opérations récurrentes'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: store.recurring.isEmpty
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    'Aucune. Quand tu ajoutes un salaire, une tontine ou un abonnement, active « Répéter chaque mois ».',
                    style: ts(13, c: C.muted),
                  ),
                )
              : Column(
                  children: [
                    for (final r in store.recurring)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          children: [
                            IconBubble(
                              iconFor(
                                store.category(r.categoryId)?.icon ?? 'repeat',
                              ),
                              Color(
                                store.category(r.categoryId)?.color ??
                                    C.primary.toARGB32(),
                              ),
                              size: 36,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    r.label.isNotEmpty
                                        ? r.label
                                        : store.category(r.categoryId)?.name ??
                                              '',
                                    style: ts(14, w: w7),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    '${r.type == TxType.income ? '+' : '−'}${money(r.amount)} · le ${r.day} du mois · ${store.account(r.accountId)?.name}',
                                    style: ts(12, c: C.muted),
                                  ),
                                ],
                              ),
                            ),
                            Switch(
                              value: r.active,
                              onChanged: (v) {
                                r.active = v;
                                store.changed();
                              },
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.delete_outline_rounded,
                                color: C.muted,
                                size: 21,
                              ),
                              tooltip: 'Supprimer',
                              onPressed: () {
                                deleteWithUndo(
                                  context,
                                  'Opération récurrente supprimée',
                                  () {
                                    store.recurring.remove(r);
                                    store.changed();
                                  },
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
        SectionTitle(
          'Catégories',
          trailing: LinkText(
            '+ Ajouter',
            onTap: () => push(context, CategoryFormScreen(income: income)),
          ),
        ),
        Segmented<bool>(
          value: income,
          onChanged: (v) => setState(() => income = v),
          options: [
            (false, 'Dépenses', C.expense),
            (true, 'Entrées', C.income),
          ],
        ),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              for (var i = 0; i < cats.length; i++)
                InkWell(
                  onTap: () =>
                      push(context, CategoryFormScreen(id: cats[i].id)),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    decoration: BoxDecoration(
                      border: i == cats.length - 1
                          ? null
                          : Border(bottom: BorderSide(color: C.border)),
                    ),
                    child: Row(
                      children: [
                        IconBubble(
                          iconFor(cats[i].icon),
                          Color(cats[i].color),
                          size: 34,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(cats[i].name, style: ts(14, w: w7)),
                              if (cats[i].budget > 0)
                                Text(
                                  'Budget mensuel : ${money(cats[i].budget)}',
                                  style: ts(12, c: C.muted),
                                ),
                            ],
                          ),
                        ),
                        Icon(Icons.chevron_right_rounded, color: C.faint),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SectionTitle('Devise'),
        AppCard(
          child: Column(
            children: [
              AppField(controller: cur, hint: 'FCFA'),
              AppButton(
                'Enregistrer la devise',
                kind: BtnKind.secondary,
                onTap: () {
                  store.setSetting(
                    'currency',
                    cur.text.trim().isEmpty ? 'FCFA' : cur.text.trim(),
                  );
                  toast(context, 'Devise enregistrée');
                },
              ),
            ],
          ),
        ),
        const SectionTitle('Mes données'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              if (cloudAvailable)
                ListenableBuilder(
                  listenable: cloud,
                  builder: (context, _) => _link(
                    Icons.cloud_done_rounded,
                    C.income,
                    cloud.signedIn
                        ? 'Sauvegarde en ligne : active (${cloud.email})'
                        : 'Activer la sauvegarde en ligne',
                    () => push(context, const CloudScreen()),
                  ),
                ),
              _link(
                Icons.cloud_upload_rounded,
                C.primary,
                'Sauvegarder / restaurer',
                () => push(context, const BackupScreen()),
              ),
              _link(
                Icons.account_balance_wallet_rounded,
                C.accent,
                'Gérer mes comptes',
                () => push(context, const AccountsScreen()),
              ),
              _link(
                Icons.diamond_rounded,
                C.accent,
                'Mes avoirs',
                () => openAvoirs(context),
              ),
              _link(
                Icons.payments_rounded,
                C.income,
                'Historique de mes revenus',
                () => push(context, const IncomeHistoryScreen()),
                last: true,
              ),
            ],
          ),
        ),
        const SectionTitle('Application'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              _link(
                Icons.system_update_rounded,
                C.primary,
                'Rechercher une mise à jour (version $versionLabel)',
                () async {
                  toast(context, 'Recherche en cours…');
                  final found = await checkForUpdate();
                  if (!context.mounted) return;
                  if (found) {
                    toast(
                      context,
                      'Nouvelle version ${updateAvailable.value!.label} : téléchargement…',
                    );
                    openUpdate();
                  } else {
                    toast(
                      context,
                      buildNumber == 0 ? 'Version de développement' : 'Tu as déjà la dernière version (ou pas d\'internet).',
                    );
                  }
                },
                last: true,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 10),
          child: Text(
            'Zone sensible',
            style: ts(15, w: w8, c: C.expense),
          ),
        ),
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(cardRadius),
            border: Border.all(
              color: C.expense.withValues(alpha: 0.35),
              width: 1.5,
            ),
          ),
          child: Column(
            children: [
              _link(
                Icons.download_rounded,
                C.transfer,
                store.historyImported
                    ? 'Réimporter mon suivi complet (au 03/11/2026)'
                    : 'Importer mon suivi complet (au 03/11/2026)',
                () => askImportHistory(context),
                sub: 'Remplace toutes tes données',
              ),
              _link(
                Icons.delete_forever_rounded,
                C.expense,
                'Tout effacer',
                () async {
                  if (await typedConfirmDialog(
                    context,
                    'Tout effacer ?',
                    'Toutes tes opérations, prêts et dettes seront supprimés, '
                        'et les soldes de départ remis à 0, ici et dans ta '
                        'sauvegarde en ligne. On ne pourra pas revenir en arrière.',
                    word: 'EFFACER',
                    ok: 'Tout effacer',
                  )) {
                    store.resetAll();
                  }
                },
                sub: 'Demande de taper EFFACER',
                danger: true,
                last: true,
              ),
            ],
          ),
        ),
        Center(
          child: Text(
            'Tes données restent sur ton téléphone, même sans internet.',
            style: ts(12, c: C.muted),
          ),
        ),
      ],
    );
  });

  Widget _switch(
    IconData icon,
    Color color,
    String label,
    String? sub,
    bool value,
    ValueChanged<bool> onChanged, {
    bool last = false,
  }) => Container(
    padding: const EdgeInsets.symmetric(vertical: 8),
    decoration: BoxDecoration(
      border: last ? null : Border(bottom: BorderSide(color: C.border)),
    ),
    child: Row(
      children: [
        IconBubble(icon, color, size: 36),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: ts(14, w: w7)),
              if (sub != null) Text(sub, style: ts(12, c: C.muted)),
            ],
          ),
        ),
        Switch(value: value, onChanged: onChanged),
      ],
    ),
  );

  Widget _link(
    IconData icon,
    Color color,
    String label,
    VoidCallback onTap, {
    bool last = false,
    String? sub,
    bool danger = false,
  }) => InkWell(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 11),
      decoration: BoxDecoration(
        border: last ? null : Border(bottom: BorderSide(color: C.border)),
      ),
      child: Row(
        children: [
          IconBubble(icon, color, size: 36),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: ts(14, w: w7, c: danger ? C.expense : null),
                ),
                if (sub != null) Text(sub, style: ts(12, c: C.muted)),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: C.faint),
        ],
      ),
    ),
  );
}

class CategoryFormScreen extends StatefulWidget {
  final int? id;
  final bool income;
  const CategoryFormScreen({super.key, this.id, this.income = false});
  @override
  State<CategoryFormScreen> createState() => _CategoryFormScreenState();
}

class _CategoryFormScreenState extends State<CategoryFormScreen> {
  final name = TextEditingController(), budget = TextEditingController();
  late bool income = widget.income;
  String icon = 'tag';
  int color = paletteChoices.first;

  @override
  void initState() {
    super.initState();
    final c = store.category(widget.id);
    if (c != null) {
      name.text = c.name;
      income = c.isIncome;
      icon = c.icon;
      color = c.color;
      budget.text = c.budget > 0 ? num0(c.budget) : '';
    }
  }

  @override
  Widget build(BuildContext context) => SubPage(
    title: widget.id == null ? 'Nouvelle catégorie' : 'Modifier la catégorie',
    children: [
      Segmented<bool>(
        value: income,
        onChanged: (v) => setState(() => income = v),
        options: [(false, 'Dépense', C.expense), (true, 'Entrée', C.income)],
      ),
      AppField(label: 'Nom', controller: name, hint: 'Ex : Divertissement'),
      if (!income)
        AppField(
          label: 'Budget mensuel (optionnel)',
          controller: budget,
          keyboard: TextInputType.number,
          hint: '0',
        ),
      const FieldLabel('Icône'),
      Wrap(
        spacing: 4,
        runSpacing: 4,
        children: [
          for (final e in iconMap.entries)
            GestureDetector(
              onTap: () => setState(() => icon = e.key),
              child: Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: icon == e.key
                      ? Color(color).withValues(alpha: 0.2)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  e.value,
                  size: 24,
                  color: icon == e.key ? Color(color) : C.muted,
                ),
              ),
            ),
        ],
      ),
      const SizedBox(height: 12),
      const FieldLabel('Couleur'),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final c in paletteChoices)
            GestureDetector(
              onTap: () => setState(() => color = c),
              child: Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: Color(c),
                  shape: BoxShape.circle,
                  border: color == c
                      ? Border.all(color: C.text, width: 3)
                      : null,
                ),
              ),
            ),
        ],
      ),
      const SizedBox(height: 20),
      AppButton(
        'Enregistrer',
        icon: Icons.check_rounded,
        onTap: () {
          if (name.text.trim().isEmpty)
            return toast(context, 'Donne un nom à la catégorie.');
          final c =
              store.category(widget.id) ??
              Cat(id: 0, name: '', isIncome: income);
          c
            ..name = name.text.trim()
            ..isIncome = income
            ..icon = icon
            ..color = color
            ..budget = income ? 0 : (parseAmount(budget.text) ?? 0);
          store.saveCategory(c);
          savedToast(context, 'Catégorie enregistrée ✅');
          Navigator.pop(context);
        },
      ),
      if (widget.id != null) ...[
        const SizedBox(height: 10),
        AppButton(
          'Masquer cette catégorie',
          icon: Icons.visibility_off_outlined,
          kind: BtnKind.danger,
          onTap: () {
            store.category(widget.id)!.archived = true;
            store.changed();
            Navigator.pop(context);
          },
        ),
      ],
    ],
  );
}

class PinSetupScreen extends StatefulWidget {
  const PinSetupScreen({super.key});
  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  String? first;
  String value = '';
  bool error = false;

  void change(String v) {
    setState(() {
      value = v;
      error = false;
    });
    if (v.length < 4) return;
    Future.delayed(const Duration(milliseconds: 150), () {
      if (!mounted) return;
      if (first == null) {
        setState(() {
          first = v;
          value = '';
        });
      } else if (v == first) {
        store.setSetting('pin_hash', hashPin(v));
        toast(context, 'Code activé : il sera demandé à chaque ouverture.');
        Navigator.pop(context);
      } else {
        setState(() {
          error = true;
          first = null;
          value = '';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: C.bg,
    appBar: AppBar(backgroundColor: C.bg, title: const Text('Code PIN')),
    body: Center(
      child: SingleChildScrollView(
        child: Column(
          children: [
            Text(
              first == null
                  ? 'Choisis un code à 4 chiffres'
                  : 'Confirme le code',
              style: ts(21, w: w8),
            ),
            const SizedBox(height: 6),
            Text(
              error
                  ? 'Les deux codes ne correspondent pas. Recommence.'
                  : "Il protège l'accès à tes finances.",
              style: ts(14, w: w6, c: error ? C.expense : C.muted),
            ),
            const SizedBox(height: 30),
            PinPad(value: value, onChanged: change),
          ],
        ),
      ),
    ),
  );
}

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});
  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  final text = TextEditingController();
  @override
  Widget build(BuildContext context) => SubPage(
    title: 'Sauvegarde',
    children: [
      AppCard(
        child: Column(
          children: [
            Row(
              children: [
                IconBubble(Icons.cloud_upload_rounded, C.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Faire une sauvegarde', style: ts(16, w: w8)),
                      Text(
                        'Envoie-la toi sur WhatsApp, par e-mail ou dans Google Drive.',
                        style: ts(12, c: C.muted),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            AppButton(
              'Sauvegarder maintenant',
              icon: Icons.ios_share_rounded,
              onTap: () =>
                  shareText(context, store.exportJson(), 'Sauvegarde MY FINN'),
            ),
          ],
        ),
      ),
      const SectionTitle('Restaurer'),
      AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sur un nouveau téléphone : copie le texte de ta sauvegarde et colle-le ici.',
              style: ts(13, c: C.muted),
            ),
            const SizedBox(height: 10),
            AppField(
              controller: text,
              maxLines: 5,
              hint: '{"app":"MY FINN", …}',
              style: ts(12),
            ),
            Row(
              children: [
                Expanded(
                  child: AppButton(
                    'Coller',
                    icon: Icons.content_paste_rounded,
                    kind: BtnKind.ghost,
                    onTap: () async {
                      final d = await Clipboard.getData('text/plain');
                      if (d?.text != null) setState(() => text.text = d!.text!);
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: AppButton(
                    'Restaurer',
                    icon: Icons.cloud_download_rounded,
                    kind: BtnKind.secondary,
                    onTap: () async {
                      if (text.text.trim().isEmpty)
                        return toast(
                          context,
                          "Colle d'abord le texte de ta sauvegarde.",
                        );
                      if (!await confirmDialog(
                        context,
                        'Restaurer la sauvegarde',
                        'Toutes les données actuelles seront remplacées.',
                        ok: 'Remplacer',
                        danger: true,
                      ))
                        return;
                      try {
                        store.restoreBackup(text.text.trim());
                        if (context.mounted) {
                          toast(context, 'Données restaurées');
                          Navigator.pop(context);
                        }
                      } catch (e) {
                        if (context.mounted)
                          toast(
                            context,
                            'Restauration impossible : ce texte n\'est pas une sauvegarde valide.',
                          );
                      }
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ],
  );
}
