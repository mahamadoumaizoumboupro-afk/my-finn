import 'package:flutter/material.dart';

import '../cloud.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

String _ago(DateTime d) {
  final m = DateTime.now().difference(d).inMinutes;
  if (m < 1) return 'à l\'instant';
  if (m < 60) return 'il y a $m min';
  final h = m ~/ 60;
  if (h < 24) return 'il y a $h h';
  return 'le ${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';
}

/// Écran « Sauvegarde en ligne » : créer un compte / se connecter, puis état de la synchronisation.
class CloudScreen extends StatefulWidget {
  const CloudScreen({super.key});
  @override
  State<CloudScreen> createState() => _CloudScreenState();
}

class _CloudScreenState extends State<CloudScreen> {
  final mail = TextEditingController();
  final pass = TextEditingController();
  bool busy = false;
  String? error;

  @override
  void dispose() {
    mail.dispose();
    pass.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() job) async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await job();
    } on CloudError catch (e) {
      error = e.message;
    } catch (e) {
      error = 'Erreur : $e';
    }
    if (mounted) setState(() => busy = false);
  }

  /// Après connexion : on récupère les données en ligne, ou on envoie celles du téléphone.
  Future<void> _afterLogin() async {
    final remote = await cloud.hasRemoteData();
    if (!mounted) return;
    if (remote && store.isEmpty) {
      await cloud.restore();
      if (mounted) toast(context, 'Tes données en ligne ont été récupérées ✅');
    } else if (remote) {
      final takeRemote = await confirmDialog(context, 'Données trouvées en ligne',
          'Ton compte contient déjà des données. Veux-tu les récupérer sur ce téléphone ? '
          '(Les données actuelles du téléphone seront remplacées.)\n\n'
          'Choisis « Annuler » pour garder celles du téléphone et les envoyer en ligne.',
          ok: 'Récupérer');
      if (takeRemote) {
        await cloud.restore();
        if (mounted) toast(context, 'Données récupérées ✅');
      } else {
        await cloud.syncNow();
      }
    } else {
      await cloud.syncNow();
      if (mounted) toast(context, 'Sauvegarde en ligne activée ✅');
    }
  }

  bool _valid() {
    if (!mail.text.contains('@')) {
      setState(() => error = 'Écris ton adresse e-mail.');
      return false;
    }
    if (pass.text.length < 6) {
      setState(() => error = 'Le mot de passe doit faire au moins 6 caractères.');
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: cloud,
        builder: (context, _) => SubPage(
          title: 'Sauvegarde en ligne',
          children: cloud.signedIn ? _connected() : _login(),
        ),
      );

  List<Widget> _login() => [
        AppCard(
          color: C.primarySoft,
          child: Row(children: [
            Icon(Icons.cloud_done_rounded, color: C.primary, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                  'Tes données seront copiées en ligne automatiquement. Si tu perds ou changes de téléphone, '
                  'tu les retrouves en te connectant avec le même e-mail.',
                  style: ts(13, w: w6)),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        AppField(label: 'Ton e-mail', controller: mail, keyboard: TextInputType.emailAddress, hint: 'exemple@gmail.com'),
        AppField(label: 'Mot de passe (6 caractères minimum)', controller: pass, obscure: true),
        if (error != null)
          Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: ts(13, w: w7, c: C.expense))),
        if (busy)
          const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
        else ...[
          AppButton('Créer mon compte', icon: Icons.person_add_rounded, onTap: () {
            if (_valid()) {
              _run(() async {
                await cloud.signUp(mail.text, pass.text);
                await _afterLogin();
              });
            }
          }),
          const SizedBox(height: 10),
          AppButton('J\'ai déjà un compte : me connecter', kind: BtnKind.ghost, icon: Icons.login_rounded, onTap: () {
            if (_valid()) {
              _run(() async {
                await cloud.signIn(mail.text, pass.text);
                await _afterLogin();
              });
            }
          }),
          const SizedBox(height: 6),
          Center(
            child: LinkText('Mot de passe oublié ?', onTap: () {
              if (!mail.text.contains('@')) {
                setState(() => error = 'Écris d\'abord ton e-mail, puis appuie à nouveau.');
                return;
              }
              _run(() async {
                await cloud.resetPassword(mail.text);
                if (mounted) toast(context, 'Un e-mail pour changer ton mot de passe a été envoyé.');
              });
            }),
          ),
        ],
      ];

  List<Widget> _connected() => [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              IconBubble(cloud.lastError == null ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
                  cloud.lastError == null ? C.income : C.warn),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(cloud.lastError == null ? 'Sauvegarde en ligne active' : 'Sauvegarde en attente', style: ts(15, w: w8)),
                  Text(cloud.email ?? '', style: ts(13, c: C.muted)),
                ]),
              ),
            ]),
            const SizedBox(height: 12),
            Text(
                cloud.syncing
                    ? 'Envoi en cours…'
                    : cloud.lastSync == null
                        ? 'Pas encore envoyé.'
                        : 'Dernier envoi : ${_ago(cloud.lastSync!)}',
                style: ts(13, w: w6)),
            if (cloud.lastError != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('${cloud.lastError} Ce sera renvoyé automatiquement plus tard.', style: ts(12, c: C.warn, w: w6)),
              ),
          ]),
        ),
        const SizedBox(height: 8),
        Text('Chaque opération que tu ajoutes est envoyée en ligne quelques secondes après, dès qu\'il y a internet.',
            style: ts(12, c: C.muted)),
        const SizedBox(height: 16),
        if (error != null)
          Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: ts(13, w: w7, c: C.expense))),
        if (busy)
          const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
        else ...[
          AppButton('Envoyer maintenant', icon: Icons.cloud_upload_rounded, onTap: () => _run(() async {
                await cloud.syncNow();
                if (mounted && cloud.lastError == null) toast(context, 'Tout est sauvegardé en ligne ✅');
              })),
          const SizedBox(height: 10),
          AppButton('Récupérer mes données en ligne', kind: BtnKind.ghost, icon: Icons.cloud_download_rounded, onTap: () async {
            if (!await confirmDialog(context, 'Récupérer mes données',
                'Les données de ce téléphone seront remplacées par celles enregistrées en ligne.', ok: 'Récupérer')) {
              return;
            }
            _run(() async {
              await cloud.restore();
              if (mounted) toast(context, 'Données récupérées ✅');
            });
          }),
          const SizedBox(height: 10),
          AppButton('Me déconnecter', kind: BtnKind.secondary, icon: Icons.logout_rounded, onTap: () async {
            if (await confirmDialog(context, 'Me déconnecter',
                'La sauvegarde en ligne s\'arrête sur ce téléphone. Tes données restent sur le téléphone et en ligne.',
                ok: 'Me déconnecter')) {
              await cloud.signOut();
            }
          }),
        ],
      ];
}
