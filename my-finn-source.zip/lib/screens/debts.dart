import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

class DebtsScreen extends StatefulWidget {
  const DebtsScreen({super.key});
  @override
  State<DebtsScreen> createState() => _DebtsScreenState();
}

class _DebtsScreenState extends State<DebtsScreen> {
  DebtDirection dir = DebtDirection.lent;
  bool showClosed = false;

  @override
  Widget build(BuildContext context) => Watch((context) {
    final list = store.debtList(dir, showClosed: showClosed);
    final open = list.where((d) => !store.closed(d)).toList();
    final total = open.fold<int>(0, (x, d) => x + store.remaining(d));
    final lent = dir == DebtDirection.lent;
    final color = lent ? C.income : C.expense;
    return PageScaffold(
      title: 'Prêts & dettes',
      trailing: RoundIconButton(
        Icons.add_rounded,
        color: Colors.white,
        bg: C.primary,
        onTap: () => push(context, DebtFormScreen(direction: dir)),
      ),
      children: [
        Segmented<DebtDirection>(
          value: dir,
          onChanged: (v) => setState(() => dir = v),
          options: [
            (DebtDirection.lent, 'On me doit', C.income),
            (DebtDirection.borrowed, 'Je dois', C.expense),
          ],
        ),
        GradientBox(
          gradient: lent ? incomeGradient : expenseGradient,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                lent ? 'Total à récupérer' : 'Total à rembourser',
                style: ts(14, w: w6, c: Colors.white70),
              ),
              FittedBox(
                child: Text(
                  money(total),
                  style: ts(30, w: w8, c: Colors.white, ls: -0.8),
                ),
              ),
              Text(
                '${open.length} en cours',
                style: ts(12, w: w6, c: Colors.white70),
              ),
            ],
          ),
        ),
        Wrap(
          children: [
            AppChip(
              'En cours',
              selected: !showClosed,
              onTap: () => setState(() => showClosed = false),
            ),
            AppChip(
              "Tout l'historique",
              selected: showClosed,
              onTap: () => setState(() => showClosed = true),
            ),
          ],
        ),
        if (list.isEmpty)
          EmptyState(
            lent
                ? "Personne ne te doit d'argent."
                : 'Tu ne dois rien à personne.',
            icon: Icons.people_outline_rounded,
          ),
        for (final d in list) _DebtCard(d, color),
      ],
    );
  });
}

class _DebtCard extends StatelessWidget {
  final Debt d;
  final Color color;
  const _DebtCard(this.d, this.color);
  @override
  Widget build(BuildContext context) {
    final closed = store.closed(d);
    final paid = store.paid(d);
    final late =
        !closed && d.dueDate != null && d.dueDate!.compareTo(today()) < 0;
    final acc = store.account(d.accountId)?.name;
    return Opacity(
      opacity: closed ? 0.55 : 1,
      child: AppCard(
        onTap: () => push(context, DebtDetailScreen(id: d.id)),
        child: Column(
          children: [
            Row(
              children: [
                Avatar(d.person),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        d.person,
                        style: ts(15, w: w8),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        '${shortDate(d.date)}${acc != null ? ' · $acc' : ''}${d.label != null ? ' · ${d.label}' : ''}',
                        style: ts(12, c: C.muted),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      closed ? 'Soldé ✓' : money(store.remaining(d)),
                      style: ts(15, w: w8, c: closed ? C.muted : color),
                    ),
                    Text('sur ${money(d.amount)}', style: ts(11, c: C.muted)),
                  ],
                ),
              ],
            ),
            if (!closed && (paid > 0 || d.dueDate != null)) ...[
              const SizedBox(height: 12),
              ProgressBar(value: paid, max: d.amount, color: color, height: 6),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${(paid / d.amount * 100).round()}% remboursé',
                      style: ts(11, w: w6, c: C.muted),
                    ),
                  ),
                  if (d.dueDate != null)
                    Text(
                      '${late ? 'En retard · ' : 'Échéance '}${shortDate(d.dueDate!)}',
                      style: ts(11, w: w8, c: late ? C.expense : C.warn),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class DebtFormScreen extends StatefulWidget {
  final int? id;
  final DebtDirection direction;
  const DebtFormScreen({
    super.key,
    this.id,
    this.direction = DebtDirection.lent,
  });
  @override
  State<DebtFormScreen> createState() => _DebtFormScreenState();
}

class _DebtFormScreenState extends State<DebtFormScreen> {
  late DebtDirection dir = widget.direction;
  final person = TextEditingController(),
      amount = TextEditingController(),
      label = TextEditingController();
  final date = TextEditingController(text: today()),
      due = TextEditingController();
  int? accountId;

  @override
  void initState() {
    super.initState();
    final d = widget.id == null ? null : store.debt(widget.id!);
    if (d != null) {
      dir = d.direction;
      person.text = d.person;
      amount.text = num0(d.amount);
      date.text = d.date;
      due.text = d.dueDate ?? '';
      accountId = d.accountId;
      label.text = d.label ?? '';
    } else {
      accountId = store.activeAccounts
          .where((a) => a.type == 'cash')
          .firstOrNull
          ?.id;
    }
  }

  void save() {
    final v = parseAmount(amount.text);
    if (person.text.trim().isEmpty)
      return toast(context, 'Indique le nom de la personne.');
    if (v == null || v <= 0) return toast(context, 'Saisis un montant valide.');
    if (!isValidISO(date.text)) return toast(context, 'Choisis une date.');
    if (due.text.isNotEmpty && !isValidISO(due.text))
      return toast(context, 'Échéance : format AAAA-MM-JJ');
    final d = widget.id == null
        ? Debt(id: 0, direction: dir, person: '', amount: 0, date: '')
        : store.debt(widget.id!)!;
    d
      ..direction = dir
      ..person = person.text.trim()
      ..amount = v
      ..date = date.text
      ..dueDate = due.text.isEmpty ? null : due.text
      ..accountId = accountId
      ..label = label.text.trim().isEmpty ? null : label.text.trim();
    store.saveDebt(d);
    savedToast(
      context,
      widget.id == null ? 'Prêt enregistré ✅' : 'Modification enregistrée ✅',
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final people = store
        .people()
        .where(
          (p) =>
              person.text.isEmpty ||
              p.toLowerCase().contains(person.text.toLowerCase()),
        )
        .take(8);
    return SubPage(
      title: widget.id == null ? 'Nouveau prêt / emprunt' : 'Modifier',
      children: [
        Segmented<DebtDirection>(
          value: dir,
          onChanged: (v) => setState(() => dir = v),
          options: [
            (DebtDirection.lent, 'Je prête', C.income),
            (DebtDirection.borrowed, "J'emprunte", C.expense),
          ],
        ),
        AppField(
          label: dir == DebtDirection.lent ? 'À qui ?' : 'Auprès de qui ?',
          controller: person,
          hint: 'Nom',
          onChanged: (_) => setState(() {}),
        ),
        if (people.isNotEmpty)
          Wrap(
            children: [
              for (final p in people)
                AppChip(
                  p,
                  color: C.muted,
                  onTap: () => setState(() => person.text = p),
                ),
            ],
          ),
        AppField(
          label: 'Montant ($currency)',
          controller: amount,
          keyboard: TextInputType.number,
          hint: '0',
          style: ts(24, w: w8),
        ),
        AppField(
          label: 'Motif (optionnel)',
          controller: label,
          hint: 'Ex : achat box wifi',
        ),
        FieldLabel(
          dir == DebtDirection.lent
              ? 'Argent sorti de quel compte ?'
              : 'Argent reçu sur quel compte ?',
        ),
        ChipScroll(
          children: [
            AppChip(
              'Aucun (ancienne créance)',
              color: C.muted,
              selected: accountId == null,
              onTap: () => setState(() => accountId = null),
            ),
            for (final a in store.activeAccounts)
              AppChip(
                a.name,
                color: Color(a.color),
                selected: accountId == a.id,
                onTap: () => setState(() => accountId = a.id),
              ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text(
            'Avec un compte, son solde est ajusté automatiquement. « Aucun » sert à noter une créance ou une dette déjà existante.',
            style: ts(12, c: C.muted),
          ),
        ),
        DateField(label: 'Date', controller: date),
        DateField(
          label: 'Échéance (optionnel)',
          controller: due,
          optional: true,
          quick: false,
        ),
        AppButton('Enregistrer', icon: Icons.check_rounded, onTap: save),
      ],
    );
  }
}

class DebtDetailScreen extends StatefulWidget {
  final int id;
  const DebtDetailScreen({super.key, required this.id});
  @override
  State<DebtDetailScreen> createState() => _DebtDetailScreenState();
}

class _DebtDetailScreenState extends State<DebtDetailScreen> {
  final amount = TextEditingController(),
      date = TextEditingController(text: today());
  int? accountId;
  bool accountSet = false;

  @override
  Widget build(BuildContext context) => Watch(_build);

  Widget _build(BuildContext context) {
    final d = store.debt(widget.id);
    if (d == null) return const SubPage(title: '', children: []);
    final lent = d.direction == DebtDirection.lent;
    final color = lent ? C.income : C.expense;
    final closed = store.closed(d);
    if (!accountSet) {
      accountId =
          d.accountId ??
          store.activeAccounts.where((a) => a.type == 'cash').firstOrNull?.id;
      accountSet = true;
    }
    void pay(bool full) {
      final v = full ? store.remaining(d) : parseAmount(amount.text);
      if (v == null || v <= 0)
        return toast(context, 'Saisis un montant valide.');
      if (!isValidISO(date.text)) return toast(context, 'Choisis une date.');
      store.addPayment(
        Payment(
          id: 0,
          debtId: d.id,
          amount: v,
          date: date.text,
          accountId: accountId,
        ),
      );
      amount.clear();
      toast(context, 'Remboursement enregistré');
    }

    final pays = store.paymentsOf(d.id);
    return SubPage(
      title: d.person,
      actions: [
        RoundIconButton(
          Icons.edit_outlined,
          onTap: () => push(context, DebtFormScreen(id: d.id)),
        ),
      ],
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Avatar(d.person, size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      lent
                          ? '${d.person} me doit encore'
                          : 'Je dois encore à ${d.person}',
                      style: ts(14, w: w6, c: C.muted),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                closed ? 'Soldé ✓' : money(store.remaining(d)),
                style: ts(30, w: w8, c: closed ? C.muted : color, ls: -0.8),
              ),
              Text(
                'Montant initial ${money(d.amount)} le ${shortDate(d.date)}${d.accountId != null ? ' (${store.account(d.accountId)?.name})' : ''}',
                style: ts(12, c: C.muted),
              ),
              if (d.label != null) Text(d.label!, style: ts(12, c: C.muted)),
              if (d.dueDate != null)
                Text(
                  'Échéance : ${shortDate(d.dueDate!)}',
                  style: ts(12, w: w7, c: C.warn),
                ),
              const SizedBox(height: 12),
              ProgressBar(value: store.paid(d), max: d.amount, color: color),
            ],
          ),
        ),
        if (!closed) ...[
          SectionTitle(
            lent
                ? 'Enregistrer un remboursement reçu'
                : 'Enregistrer un remboursement payé',
          ),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppField(
                  label: 'Montant',
                  controller: amount,
                  keyboard: TextInputType.number,
                  hint: num0(store.remaining(d)),
                ),
                FieldLabel(lent ? 'Reçu sur' : 'Payé depuis'),
                ChipScroll(
                  children: [
                    AppChip(
                      'Aucun compte',
                      color: C.muted,
                      selected: accountId == null,
                      onTap: () => setState(() => accountId = null),
                    ),
                    for (final a in store.activeAccounts)
                      AppChip(
                        a.name,
                        color: Color(a.color),
                        selected: accountId == a.id,
                        onTap: () => setState(() => accountId = a.id),
                      ),
                  ],
                ),
                DateField(label: 'Date', controller: date),
                Row(
                  children: [
                    Expanded(
                      child: AppButton(
                        'Ajouter',
                        icon: Icons.add_rounded,
                        onTap: () => setState(() => pay(false)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: AppButton(
                        'Tout soldé',
                        icon: Icons.done_all_rounded,
                        kind: BtnKind.secondary,
                        onTap: () => setState(() => pay(true)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
        const SectionTitle('Historique des remboursements'),
        AppCard(
          child: pays.isEmpty
              ? Text(
                  "Aucun remboursement pour l'instant.",
                  style: ts(14, c: C.muted),
                )
              : Column(
                  children: [
                    for (final p in pays)
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${shortDate(p.date)}${p.accountId != null ? ' · ${store.account(p.accountId)?.name}' : ''}',
                              style: ts(14, w: w7),
                            ),
                          ),
                          Text(
                            money(p.amount),
                            style: ts(14, w: w8, c: color),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.delete_outline_rounded,
                              size: 21,
                              color: C.muted,
                            ),
                            tooltip: 'Supprimer',
                            onPressed: () {
                              deleteWithUndo(
                                context,
                                'Remboursement supprimé',
                                () => store.deletePayment(p.id),
                              );
                              setState(() {});
                            },
                          ),
                        ],
                      ),
                  ],
                ),
        ),
        AppButton(
          'Supprimer',
          icon: Icons.delete_outline_rounded,
          kind: BtnKind.danger,
          onTap: () {
            deleteWithUndo(
              context,
              'Prêt supprimé',
              () => store.deleteDebt(d.id),
            );
            Navigator.pop(context);
          },
        ),
      ],
    );
  }
}
