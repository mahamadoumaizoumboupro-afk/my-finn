import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'avoirs.dart';
import 'budget.dart';
import 'month_list.dart';
import 'revenus.dart';
import 'tx_form.dart';

const benefColors = {
  'moi': Color(0xFF5B4CF5),
  'maison': Color(0xFF14C8B4),
  'personne:pour': Color(0xFF3B82F6),
  'personne:donation': Color(0xFFF04461),
  'personne:cadeau': Color(0xFFF59E0B),
};

/// Partage un texte (WhatsApp, e-mail…) ; sur le web, le copie.
Future<void> shareText(BuildContext context, String text, String title) async {
  if (!kIsWeb) {
    try {
      await SharePlus.instance.share(ShareParams(text: text, subject: title));
      return;
    } catch (_) {}
  }
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted)
    toast(context, '$title copié. Tu peux le coller où tu veux.');
}

const _blues = [
  Color(0xFF0D33D9),
  Color(0xFF1650F0),
  Color(0xFF3B82F6),
  Color(0xFF9DBDF4),
  Color(0xFFC9D8F7),
];

String kShort(int v) => v >= 1000000
    ? '${(v / 1000000).toStringAsFixed(1).replaceAll('.', ',')}M'
    : '${(v / 1000).round()}k';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  String month = currentMonth();
  int mode = 0; // 0 mois, 1 année, 2 période, 3 toutes les années
  String year = currentMonth().substring(0, 4);
  String from = shiftMonth(currentMonth(), -3), to = currentMonth();

  Widget _modeSwitch() => Segmented<int>(
    value: mode,
    onChanged: (v) => setState(() => mode = v),
    options: const [
      (0, 'Mois', null),
      (1, 'Année', null),
      (2, 'Période', null),
      (3, 'Tout', null),
    ],
  );

  @override
  Widget build(BuildContext context) => Watch((context) {
    if (mode != 0) {
      return PageScaffold(
        title: 'Bilan',
        children: [_modeSwitch(), ..._yearView(context)],
      );
    }
    final sm = store.summary(month);
    final expenses = sm.byCategory.where((c) => !c.cat.isIncome).toList();
    final incomes = sm.byCategory.where((c) => c.cat.isIncome).toList();
    // Mois d'avant l'app : les entrées viennent de l'historique importé (avec leurs détails).
    final hist = sm.income == 0
        ? store.history.where((h) => h.month == month).toList()
        : <HistIncome>[];
    final histNet = hist.fold(0, (x, h) => x + h.amount - h.tax);
    final months = [for (var i = 5; i >= 0; i--) shiftMonth(month, -i)];
    final trend = [for (final m in months) (m, store.summary(m))];
    final maxTrend = trend.fold<int>(
      1,
      (x, t) => [x, t.$2.income, t.$2.expense].reduce((a, b) => a > b ? a : b),
    );
    final avail = store.available();
    final ecarts = store.ecarts(month);
    final ecartTotal = ecarts.fold(0, (x, e) => x + e.$2);
    final ecartTxs = store
        .transactions(month: month)
        .where((t) => t.adjust)
        .toList();
    final into = store.countedInto(month);
    final elsewhere = store.countedElsewhere(month);
    String signed(int v) => '${v < 0 ? '−' : '+'}${num0(v.abs())}';

    return PageScaffold(
      title: 'Bilan',
      trailing: RoundIconButton(
        Icons.arrow_outward_rounded,
        onTap: () => shareText(
          context,
          store.monthReport(month),
          'Rapport ${monthLabel(month)}',
        ),
      ),
      children: [
        _modeSwitch(),
        MonthSwitcher(
          month: month,
          onChanged: (m) => setState(() => month = m),
        ),
        Row(
          children: [
            Expanded(
              child: _flat(
                'Entrées',
                hist.isNotEmpty ? histNet : sm.income,
                C.income,
                () => push(
                  context,
                  hist.isNotEmpty
                      ? HistMonthScreen(month: month)
                      : MonthTxScreen(month: month, type: TxType.income),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _flat(
                'Dépenses',
                sm.expense + sm.fees,
                C.expense,
                () => push(
                  context,
                  MonthTxScreen(month: month, type: TxType.expense),
                ),
              ),
            ),
          ],
        ),
        if (into.isNotEmpty || elsewhere.isNotEmpty) ...[
          const SectionTitle('Comptés pour un autre mois'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final t in into)
                  _shiftedRow(
                    t,
                    t.date.compareTo(month) > 0
                        ? '${t.type == TxType.income ? 'Reçu' : 'Payé'} plus tard · le ${dayShort(t.date)}'
                        : '${t.type == TxType.income ? 'Reçu' : 'Payé'} en avance · le ${dayShort(t.date)}',
                  ),
                if (into.isNotEmpty)
                  _infoBox(
                    into.length == 1
                        ? "1 opération arrivée un autre mois compte ici, pour ${monthLabel(month).split(' ').first.toLowerCase()}."
                        : "${into.length} opérations arrivées un autre mois comptent ici, pour ${monthLabel(month).split(' ').first.toLowerCase()}.",
                  ),
                for (final t in elsewhere)
                  _shiftedRow(
                    t,
                    'Le ${dayShort(t.date)} · compte pour ${monthLabel(t.forMonth!).split(' ').first.toLowerCase()}',
                    muted: true,
                  ),
              ],
            ),
          ),
        ],
        if (ecarts.isNotEmpty) ...[
          const SectionTitle('Écarts du mois'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Écart total (argent non noté)',
                        style: ts(12, w: w7, c: C.muted),
                      ),
                    ),
                    Text(
                      signed(ecartTotal),
                      style: ts(
                        20,
                        w: w8,
                        c: ecartTotal < 0 ? C.expense : C.income,
                      ),
                    ),
                  ],
                ),
                for (final e in ecarts)
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(top: BorderSide(color: C.border)),
                    ),
                    margin: const EdgeInsets.only(top: 6),
                    child: Row(
                      children: [
                        AccountBadge(e.$1, size: 40),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(e.$1.name, style: ts(15, w: w7)),
                              Text(
                                e.$3 > 1
                                    ? '${e.$3} réajustements'
                                    : '1 réajustement',
                                style: ts(12, c: C.muted),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          signed(e.$2),
                          style: ts(
                            15,
                            w: w8,
                            c: e.$2 < 0 ? C.expense : C.income,
                          ),
                        ),
                      ],
                    ),
                  ),
                Text(
                  'Ces écarts comptent dans les entrées et dépenses du mois.',
                  style: ts(12, c: C.muted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Column(
              children: [
                for (var i = 0; i < ecartTxs.length; i++)
                  TxTile(
                    ecartTxs[i],
                    last: i == ecartTxs.length - 1,
                    onTap: () =>
                        push(context, TxFormScreen(id: ecartTxs[i].id)),
                  ),
              ],
            ),
          ),
        ],
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text("Où part l'argent", style: ts(15, w: w8)),
                  ),
                  Text(
                    num0(sm.expense),
                    style: ts(12, w: w6, c: C.muted),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              if (expenses.isEmpty)
                Text('Aucune dépense ce mois.', style: ts(14, c: C.muted))
              else
                Builder(
                  builder: (context) {
                    final top = expenses.take(4).toList();
                    final rest = expenses
                        .skip(4)
                        .fold(0, (x, c) => x + c.total);
                    final parts = [
                      for (final c in top) (c.cat.name, c.total),
                      if (rest > 0) ('Autres', rest),
                    ];
                    return Row(
                      children: [
                        Donut(
                          size: 118,
                          stroke: 16,
                          data: [
                            for (var i = 0; i < parts.length; i++)
                              (parts[i].$2, _blues[i % _blues.length]),
                          ],
                          center: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('Dépenses', style: ts(10, c: C.muted)),
                              Text(kShort(sm.expense), style: ts(13, w: w8)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            children: [
                              for (var i = 0; i < parts.length; i++)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 4,
                                  ),
                                  child: Row(
                                    children: [
                                      dot(_blues[i % _blues.length], 8),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          parts[i].$1,
                                          style: ts(12, w: w6),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      Text(
                                        '${(parts[i].$2 * 100 / sm.expense).round()} %',
                                        style: ts(12, w: w7),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
            ],
          ),
        ),
        Builder(
          builder: (context) {
            final weeks = List<int>.filled(5, 0);
            for (final t in store.transactions(
              month: month,
              type: TxType.expense,
            )) {
              if (t.trace) continue; // pas de jour précis
              final d = int.tryParse(t.date.substring(8, 10)) ?? 1;
              weeks[((d - 1) ~/ 7).clamp(0, 4)] += t.amount;
            }
            final nWeeks = weeks[4] > 0 || month == currentMonth() ? 5 : 4;
            var cur = nWeeks - 1;
            if (month == currentMonth()) {
              cur = ((DateTime.now().day - 1) ~/ 7).clamp(0, 4);
            }
            final maxW = weeks.fold(1, (x, v) => v > x ? v : x);
            // Mois d'avant l'app : les entrées viennent de l'historique.
            final inc = hist.isNotEmpty ? histNet : sm.income;
            final saved = inc - sm.expense - sm.fees;
            final ratio = inc > 0
                ? (saved / inc).clamp(0.0, 1.0).toDouble()
                : 0.0;
            return IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: AppCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Par semaine',
                            style: ts(12, w: w6, c: C.muted),
                          ),
                          const SizedBox(height: 10),
                          if (weeks.every((v) => v == 0) && sm.expense > 0)
                            SizedBox(
                              height: 70,
                              child: Center(
                                child: Text(
                                  'Notées sans jour précis',
                                  textAlign: TextAlign.center,
                                  style: ts(12, w: w6, c: C.muted),
                                ),
                              ),
                            )
                          else
                            SizedBox(
                              height: 70,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  for (var i = 0; i < nWeeks; i++)
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 3,
                                        ),
                                        child: Container(
                                          height: (weeks[i] / maxW * 70)
                                              .clamp(4, 70)
                                              .toDouble(),
                                          decoration: BoxDecoration(
                                            color: i == cur
                                                ? C.expense
                                                : C.expense.withValues(
                                                    alpha: 0.14,
                                                  ),
                                            borderRadius: BorderRadius.circular(
                                              3,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Text('S1', style: ts(11, c: C.muted)),
                              const Spacer(),
                              Text('S$nWeeks', style: ts(11, c: C.muted)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Épargné',
                            style: ts(12, w: w6, c: C.muted),
                          ),
                          const SizedBox(height: 8),
                          Center(
                            child: Donut(
                              size: 66,
                              stroke: 7,
                              data: [
                                (ratio, C.income),
                                (1 - ratio, Colors.transparent),
                              ],
                              center: Text(
                                '${(ratio * 100).round()} %',
                                style: ts(13, w: w8),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Center(
                            child: Text(
                              saved >= 0
                                  ? '${num0(saved)} gardés'
                                  : '${num0(-saved)} en trop',
                              style: ts(12, c: C.muted),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        Builder(
          builder: (context) {
            final ms = store.incomeMonths();
            if (ms.isEmpty) return const SizedBox.shrink();
            final last12 = ms.length > 12 ? ms.sublist(ms.length - 12) : ms;
            final net = last12.fold(0, (x, m) => x + m.net);
            final maxN = last12.fold(1, (x, m) => m.net > x ? m.net : x);
            return AppCard(
              onTap: () => push(context, const IncomeHistoryScreen()),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Revenus · ${last12.length} mois',
                          style: ts(15, w: w8),
                        ),
                      ),
                      Text(
                        num0(net),
                        style: ts(14, w: w8, c: C.income),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 36,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        for (final m in last12)
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 2,
                              ),
                              child: Container(
                                height: (m.net / maxN * 36)
                                    .clamp(18, 36)
                                    .toDouble(),
                                decoration: BoxDecoration(
                                  color: m == last12.last
                                      ? C.income
                                      : C.income.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        Builder(
          builder: (context) {
            final allBudget = store
                .cats(income: false)
                .fold(0, (x, c) => x + c.budget);
            final spentB = expenses
                .where((c) => c.cat.budget > 0)
                .fold(0, (x, c) => x + c.total);
            return AppCard(
              onTap: () => push(context, BudgetScreen(month: month)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text('Mon budget', style: ts(15, w: w8)),
                      ),
                      Text(
                        allBudget > 0
                            ? '${num0(spentB)} / ${num0(allBudget)}'
                            : 'À définir',
                        style: ts(12, w: w6, c: C.muted),
                      ),
                      Icon(Icons.chevron_right_rounded, color: C.faint),
                    ],
                  ),
                  if (allBudget > 0) ...[
                    const SizedBox(height: 10),
                    ProgressBar(
                      value: spentB,
                      max: allBudget,
                      color: budgetColor(spentB, allBudget),
                      height: 6,
                    ),
                  ],
                ],
              ),
            );
          },
        ),
        const SectionTitle('Pour qui ?'),
        AppCard(
          child: sm.byBeneficiary.isEmpty
              ? Text('Aucune dépense.', style: ts(14, c: C.muted))
              : Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(7),
                      child: SizedBox(
                        height: 14,
                        child: Row(
                          children: [
                            for (final k in beneficiaryLabels.keys.where(
                              sm.byBeneficiary.containsKey,
                            ))
                              Expanded(
                                flex: sm.byBeneficiary[k]!,
                                child: Container(color: benefColors[k]),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    for (final k in beneficiaryLabels.keys.where(
                      sm.byBeneficiary.containsKey,
                    ))
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          children: [
                            dot(benefColors[k]!, 10),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                beneficiaryLabels[k]!,
                                style: ts(14, w: w6),
                              ),
                            ),
                            Text(
                              pct(sm.byBeneficiary[k]!, sm.expense),
                              style: ts(12, w: w7, c: C.muted),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              money(sm.byBeneficiary[k]!),
                              style: ts(14, w: w8),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
        if (sm.byPerson.isNotEmpty) ...[
          const SectionTitle('Par personne'),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Column(
              children: [
                for (final p in sm.byPerson)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Avatar(p.key, size: 34),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.key, style: ts(14, w: w7)),
                              Text(
                                sm.personNatures[p.key]!
                                    .map(
                                      (n) => switch (n) {
                                        Nature.donation => 'donation',
                                        Nature.cadeau => 'cadeau',
                                        _ => 'dépense pour',
                                      },
                                    )
                                    .join(', '),
                                style: ts(11, c: C.muted),
                              ),
                            ],
                          ),
                        ),
                        Text(money(p.value), style: ts(14, w: w8)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
        const SectionTitle('Prêts du mois'),
        AppCard(
          child: Column(
            children: [
              _line('Prêts accordés', sm.lentOut),
              _line('Remboursements reçus', sm.repaidToMe),
              _line('Emprunts reçus', sm.borrowedIn),
              _line('Remboursements payés', sm.repaidByMe),
              const Hr(),
              _line('Sorties nettes', sm.netOut, bold: true),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Dépenses + prêts accordés − remboursements reçus',
                  style: ts(11, c: C.muted),
                ),
              ),
            ],
          ),
        ),
        const SectionTitle('Entrées par source'),
        if (hist.isNotEmpty)
          AppCard(child: HistList(hist))
        else
          AppCard(
            child: incomes.isEmpty
                ? Text('Aucune entrée ce mois.', style: ts(14, c: C.muted))
                : Column(
                    children: [
                      for (final c in incomes)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(
                            children: [
                              IconBubble(
                                iconFor(c.cat.icon),
                                Color(c.cat.color),
                                size: 32,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(c.cat.name, style: ts(14, w: w7)),
                              ),
                              Text(
                                '+${money(c.total)}',
                                style: ts(14, w: w8, c: C.income),
                              ),
                            ],
                          ),
                        ),
                      if (sm.taxes > 0) ...[
                        const Hr(),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Taxes déjà retirées (brut ${money(sm.income + sm.taxes)})',
                                style: ts(12, w: w6, c: C.muted),
                              ),
                            ),
                            Text(
                              money(sm.taxes),
                              style: ts(13, w: w8, c: C.expense),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
          ),
        const SectionTitle('Tendance sur 6 mois'),
        AppCard(
          child: Column(
            children: [
              SizedBox(
                height: 150,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    for (final t in trend)
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                _bar(
                                  t.$2.income / maxTrend,
                                  C.income,
                                  t.$1 == month,
                                ),
                                const SizedBox(width: 3),
                                _bar(
                                  t.$2.expense / maxTrend,
                                  C.expense,
                                  t.$1 == month,
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              monthLabel(t.$1).substring(0, 3),
                              style: ts(
                                11,
                                w: t.$1 == month ? w8 : w6,
                                c: t.$1 == month ? C.primary : C.muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  dot(C.income),
                  const SizedBox(width: 6),
                  Text(
                    'Entrées',
                    style: ts(12, w: w7, c: C.muted),
                  ),
                  const SizedBox(width: 18),
                  dot(C.expense),
                  const SizedBox(width: 6),
                  Text(
                    'Dépenses',
                    style: ts(12, w: w7, c: C.muted),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SectionTitle("Mes avoirs aujourd'hui"),
        Builder(
          builder: (context) {
            final a = store.avoirs();
            return AppCard(
              onTap: () => push(context, const AvoirsScreen()),
              child: Column(
                children: [
                  _line('Comptes et cash', avail),
                  _line('Placements, tontines, bons', a.placements),
                  _line('Créances (on me doit)', a.creances),
                  _line('Dettes (je dois)', -a.dettes),
                  const Hr(),
                  _line('Total', a.total, bold: true),
                ],
              ),
            );
          },
        ),
      ],
    );
  });

  /* ---------- Bilan d'une année, d'une période ou de tout ---------- */
  void _openMonth(String m) => setState(() {
    mode = 0;
    month = m;
  });

  void _openYear(String y) => setState(() {
    mode = 1;
    year = y;
  });

  Widget _periodChip(String label, String m, ValueChanged<String> onPick) =>
      Expanded(
        child: GestureDetector(
          onTap: () async {
            final r = await pickMonth(context, m);
            if (r != null) onPick(r);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: C.primary, width: 1.4),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: ts(11, w: w7, c: C.muted),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        monthLabel(m),
                        style: ts(14, w: w8),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Icon(
                      Icons.calendar_month_rounded,
                      size: 18,
                      color: C.primary,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );

  List<Widget> _yearView(BuildContext context) {
    final all = mode == 3, period = mode == 2;
    final years = store.years();
    if (!years.contains(year)) year = years.last;
    final i = years.indexOf(year);
    if (from.compareTo(to) > 0) {
      final x = from;
      from = to;
      to = x;
    }
    final y = all
        ? store.allYearsSummary()
        : period
        ? store.rangeSummary(from, to)
        : store.yearSummary(year);
    // colonnes du graphique : les mois, ou les années
    final cols = all
        ? years
        : period
        ? [for (var m = from; m.compareTo(to) <= 0; m = shiftMonth(m, 1)) m]
        : [for (var m = 1; m <= 12; m++) '$year-${pad2(m)}'];
    final colLabels = all
        ? years
        : [for (final c in cols) monthLabel(c).substring(0, 1)];
    final showLabels = cols.length <= 24;
    final withData = y.months;
    final avg = y.income.isEmpty ? 0 : y.totalIncome ~/ y.income.length;
    final unit = all ? 'an' : 'mois';
    final label = all
        ? 'toutes les années'
        : period
        ? '${shortMonth(from)} ${from.substring(0, 4)} → ${shortMonth(to)} ${to.substring(0, 4)}'
        : year;
    final maxV = [
      1,
      ...y.income.values,
      ...y.expense.values,
    ].reduce((a, b) => a > b ? a : b);
    final sources = y.bySource.entries.where((e) => e.value > 0).toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    const colors = [
      Color(0xFF1650F0),
      Color(0xFF0E9F6E),
      Color(0xFFD9A21B),
      Color(0xFF8B5CF6),
      Color(0xFFE5484D),
      Color(0xFF06B6D4),
      Color(0xFFF97316),
      Color(0xFFEC4899),
      Color(0xFF64748B),
      Color(0xFF84CC16),
    ];
    final start = all
        ? '${years.first}-01'
        : period
        ? from
        : '$year-01';
    final end = all
        ? '${years.last}-12'
        : period
        ? to
        : '$year-12';
    final fe = y.firstExpenseMonth;
    final partial = fe != null && fe.compareTo(start) > 0;
    void open(String k) => all ? _openYear(k) : _openMonth(k);

    return [
      if (all)
        Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Text(
            '${years.first} → ${years.last}',
            textAlign: TextAlign.center,
            style: ts(20, w: w8),
          ),
        )
      else if (period)
        Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Row(
            children: [
              _periodChip('Du', from, (m) => setState(() => from = m)),
              const SizedBox(width: 10),
              _periodChip('Au', to, (m) => setState(() => to = m)),
            ],
          ),
        )
      else
        Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Row(
            children: [
              Opacity(
                opacity: i > 0 ? 1 : 0.3,
                child: RoundIconButton(
                  Icons.chevron_left_rounded,
                  onTap: i > 0
                      ? () => setState(() => year = years[i - 1])
                      : () {},
                ),
              ),
              Expanded(
                child: Text(
                  year,
                  textAlign: TextAlign.center,
                  style: ts(20, w: w8),
                ),
              ),
              Opacity(
                opacity: i < years.length - 1 ? 1 : 0.3,
                child: RoundIconButton(
                  Icons.chevron_right_rounded,
                  onTap: i < years.length - 1
                      ? () => setState(() => year = years[i + 1])
                      : () {},
                ),
              ),
            ],
          ),
        ),
      Row(
        children: [
          Expanded(
            child: _yearBox(
              all
                  ? 'Entrées (total)'
                  : period
                  ? 'Entrées de la période'
                  : "Entrées de l'année",
              '+${num0(y.totalIncome)}',
              C.income,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: y.hasExpenses
                ? _yearBox(
                    partial ? 'Dépenses*' : 'Dépenses',
                    '−${num0(y.totalExpense)}',
                    C.expense,
                  )
                : _yearBox('Dépenses', 'Pas notées', null),
          ),
        ],
      ),
      AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    all ? 'Année par année' : 'Mois par mois',
                    style: ts(15, w: w8),
                  ),
                ),
                if (avg > 0)
                  Text(
                    'moy. ${num0(avg)}/$unit',
                    style: ts(12, w: w7, c: C.muted),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 110,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (final k in cols)
                    Builder(
                      builder: (context) {
                        final inc = y.income[k] ?? 0, exp = y.expense[k] ?? 0;
                        Widget bar(int v, Color c, [bool est = false]) =>
                            Expanded(
                              child: FractionallySizedBox(
                                heightFactor: v > 0
                                    ? (v / maxV).clamp(0.03, 1.0)
                                    : 0.02,
                                alignment: Alignment.bottomCenter,
                                child: est && v > 0
                                    ? StripedBox(color: c)
                                    : Container(
                                        decoration: BoxDecoration(
                                          color: v > 0 ? c : C.border,
                                          borderRadius: BorderRadius.circular(
                                            3,
                                          ),
                                        ),
                                      ),
                              ),
                            );
                        return Expanded(
                          child: GestureDetector(
                            onTap: withData.contains(k) ? () => open(k) : null,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: cols.length > 16 ? 1 : 2,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  bar(inc, C.income, y.estimated.contains(k)),
                                  if (exp > 0) ...[
                                    const SizedBox(width: 1),
                                    bar(exp, C.expense),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            if (showLabels)
              Row(
                children: [
                  for (final l in colLabels)
                    Expanded(
                      child: Text(
                        l,
                        textAlign: TextAlign.center,
                        style: ts(10, w: w7, c: C.muted),
                      ),
                    ),
                ],
              ),
            const SizedBox(height: 8),
            Row(
              children: [
                dot(C.income, 8),
                const SizedBox(width: 4),
                Text(
                  'Entrées',
                  style: ts(11, w: w7, c: C.muted),
                ),
                const SizedBox(width: 12),
                dot(C.expense, 8),
                const SizedBox(width: 4),
                Text(
                  'Dépenses',
                  style: ts(11, w: w7, c: C.muted),
                ),
                if (y.estimated.isNotEmpty) ...[
                  const SizedBox(width: 12),
                  SizedBox(
                    width: 12,
                    height: 10,
                    child: StripedBox(color: C.income, radius: 2),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Estimé',
                    style: ts(11, w: w7, c: C.muted),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
      if (y.estimated.isNotEmpty && !all)
        _infoBox(
          "≈ Montants estimés : pour ces mois, tu as donné un intervalle (par exemple « entre 55.000 et 70.000 »). L'app met une moyenne pour que le total de l'année soit juste.",
        ),
      if (partial && fe.compareTo(end) <= 0)
        _infoBox(
          "* Tes dépenses sont notées dans l'app depuis ${monthLabel(fe).toLowerCase()}. Avant, on n'a que tes revenus.",
        ),
      if (sources.isNotEmpty) ...[
        SectionTitle('Entrées par source · $label'),
        AppCard(
          child: Column(
            children: [
              for (var j = 0; j < sources.length; j++)
                InkWell(
                  onTap: () => push(
                    context,
                    IncomeSourceScreen(
                      source: sources[j].key,
                      color: colors[j % colors.length],
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        dot(colors[j % colors.length], 10),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            sources[j].key,
                            style: ts(14, w: w6),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Text(num0(sources[j].value), style: ts(14, w: w8)),
                        Icon(Icons.chevron_right_rounded, color: C.faint),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
      if (withData.isNotEmpty) ...[
        SectionTitle(all ? 'Année par année' : 'Mois par mois'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
          child: Column(
            children: [
              for (final m in withData.reversed)
                InkWell(
                  onTap: () => open(m),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 11),
                    decoration: BoxDecoration(
                      border: m == withData.first
                          ? null
                          : Border(bottom: BorderSide(color: C.border)),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    all ? m : monthLabel(m),
                                    style: ts(15, w: w7),
                                  ),
                                  if (y.estimated.contains(m)) estTag(),
                                ],
                              ),
                              Text.rich(
                                TextSpan(
                                  style: ts(12, c: C.muted),
                                  children: [
                                    const TextSpan(text: 'Entrées '),
                                    TextSpan(
                                      text: '+${num0(y.income[m] ?? 0)}',
                                      style: ts(12, w: w8, c: C.income),
                                    ),
                                    const TextSpan(text: ' · Dépenses '),
                                    TextSpan(
                                      text: y.expense.containsKey(m)
                                          ? '−${num0(y.expense[m]!)}'
                                          : '—',
                                      style: ts(12, w: w8, c: C.text),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.chevron_right_rounded, color: C.faint),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(
            all
                ? 'Touche une année pour ouvrir son Bilan.'
                : 'Touche un mois pour ouvrir son Bilan détaillé.',
            style: ts(12, c: C.muted),
          ),
        ),
      ],
    ];
  }

  Widget _yearBox(String label, String value, Color? c) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    decoration: BoxDecoration(
      color: store.dark && c != null ? null : (c ?? C.transferSoft),
      gradient: store.dark && c != null ? tintGradient(c) : null,
      border: store.dark && c != null
          ? Border.all(color: c.withValues(alpha: 0.35))
          : null,
      borderRadius: BorderRadius.circular(cardRadius),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: ts(
            12,
            w: w6,
            c: c == null ? C.muted : (store.dark ? C.muted : Colors.white),
          ),
        ),
        FittedBox(
          child: Text(
            value,
            style: ts(
              18,
              w: w8,
              c: c == null ? C.muted : (store.dark ? c : Colors.white),
            ),
          ),
        ),
      ],
    ),
  );

  Widget _shiftedRow(Tx t, String sub, {bool muted = false}) {
    final acc = store.account(t.accountId);
    final inc = t.type == TxType.income;
    final title = t.label.isNotEmpty
        ? t.label
        : store.category(t.categoryId)?.name ?? 'Opération';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          if (acc != null) AccountBadge(acc, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: ts(15, w: w7, c: muted ? C.muted : null),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(sub, style: ts(12, c: C.muted)),
              ],
            ),
          ),
          Text(
            '${inc ? '+' : '−'}${num0(t.amount)}',
            style: ts(
              15,
              w: w8,
              c: muted ? C.muted : (inc ? C.income : C.text),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoBox(String text) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(top: 6, bottom: 4),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: C.primarySoft,
      borderRadius: BorderRadius.circular(10),
    ),
    child: Text(text, style: ts(12, w: w6, h: 1.45)),
  );

  Widget _flat(String label, int v, Color c, VoidCallback onTap) {
    // Mode Nuit : verre teinté de la couleur, texte coloré ; mode clair : couleur pleine.
    final dark = store.dark;
    final fg = dark ? c : Colors.white;
    final soft = dark ? C.muted : Colors.white.withValues(alpha: 0.9);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: dark ? null : c,
          gradient: dark ? tintGradient(c) : null,
          border: dark ? Border.all(color: c.withValues(alpha: 0.35)) : null,
          borderRadius: BorderRadius.circular(cardRadius),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: ts(12, w: w6, c: soft),
            ),
            FittedBox(
              child: Text(
                num0(v),
                style: ts(18, w: w8, c: fg),
              ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Text(
                  'Voir tout',
                  style: ts(12, w: w7, c: fg),
                ),
                Icon(Icons.chevron_right_rounded, size: 16, color: fg),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _bar(double f, Color c, bool sel) => Container(
    width: 11,
    height: (f * 120).clamp(3, 120).toDouble(),
    decoration: BoxDecoration(
      color: c.withValues(alpha: sel ? 1 : 0.45),
      borderRadius: BorderRadius.circular(6),
    ),
  );

  Widget _line(String label, int v, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: ts(14, w: bold ? w8 : w6, c: bold ? C.text : C.muted),
          ),
        ),
        Text(
          money(v),
          style: ts(14, w: w8, c: v < 0 ? C.expense : C.text),
        ),
      ],
    ),
  );
}
