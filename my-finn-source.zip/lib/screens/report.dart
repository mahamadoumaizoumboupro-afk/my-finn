import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

const benefColors = {
  'moi': Color(0xFF5B4CF5), 'maison': Color(0xFF14C8B4), 'personne:pour': Color(0xFF3B82F6),
  'personne:donation': Color(0xFFF04461), 'personne:cadeau': Color(0xFFF59E0B),
};

/// Partage un texte (WhatsApp, e-mail…) ; sur le web, le copie.
Future<void> shareText(BuildContext context, String text, String title) async {
  if (!kIsWeb) {
    try {
      await SharePlus.instance.share(ShareParams(text: text, subject: title));
      return;
    } catch (_) {}
  }
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted) toast(context, '$title copié. Tu peux le coller où tu veux.');
}

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  String month = currentMonth();

  @override
  Widget build(BuildContext context) => Watch((context) {
        final sm = store.summary(month);
        final expenses = sm.byCategory.where((c) => !c.cat.isIncome).toList();
        final incomes = sm.byCategory.where((c) => c.cat.isIncome).toList();
        final months = [for (var i = 5; i >= 0; i--) shiftMonth(month, -i)];
        final trend = [for (final m in months) (m, store.summary(m))];
        final maxTrend = trend.fold<int>(1, (x, t) => [x, t.$2.income, t.$2.expense].reduce((a, b) => a > b ? a : b));
        final balance = sm.income - sm.expense - sm.fees;
        final avail = store.available();

        return PageScaffold(
          title: 'Bilan',
          trailing: RoundIconButton(Icons.ios_share_rounded,
              onTap: () => shareText(context, store.monthReport(month), 'Rapport ${monthLabel(month)}')),
          children: [
            MonthSwitcher(month: month, onChanged: (m) => setState(() => month = m)),
            GradientBox(
              gradient: heroGradient,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Solde du mois', style: ts(14, w: w6, c: Colors.white70)),
                FittedBox(child: Text('${balance >= 0 ? '+' : ''}${money(balance)}', style: ts(32, w: w8, c: Colors.white, ls: -1))),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(child: _pill('Entrées', sm.income)),
                  const SizedBox(width: 10),
                  Expanded(child: _pill('Dépenses', sm.expense + sm.fees)),
                ]),
                const SizedBox(height: 10),
                Text('${sm.count} opérations', style: ts(12, w: w6, c: Colors.white70)),
              ]),
            ),
            const SectionTitle("Où part l'argent"),
            AppCard(
              child: expenses.isEmpty
                  ? const EmptyState('Aucune dépense ce mois.', icon: Icons.donut_large_rounded)
                  : Column(children: [
                      Donut(size: 190, stroke: 26, data: [for (final c in expenses) (c.total, Color(c.cat.color))],
                          center: Column(mainAxisSize: MainAxisSize.min, children: [
                            Text('Dépenses', style: ts(12, w: w7, c: C.muted)),
                            Text(money(sm.expense), style: ts(16, w: w8)),
                          ])),
                      const SizedBox(height: 16),
                      for (final c in expenses) _catRow(c, expenses.first.total, sm.expense),
                    ]),
            ),
            const SectionTitle('Pour qui ?'),
            AppCard(
              child: sm.byBeneficiary.isEmpty
                  ? Text('Aucune dépense.', style: ts(14, c: C.muted))
                  : Column(children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(7),
                        child: SizedBox(height: 14, child: Row(children: [
                          for (final k in beneficiaryLabels.keys.where(sm.byBeneficiary.containsKey))
                            Expanded(flex: sm.byBeneficiary[k]!, child: Container(color: benefColors[k])),
                        ])),
                      ),
                      const SizedBox(height: 12),
                      for (final k in beneficiaryLabels.keys.where(sm.byBeneficiary.containsKey))
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(children: [
                            dot(benefColors[k]!, 10), const SizedBox(width: 10),
                            Expanded(child: Text(beneficiaryLabels[k]!, style: ts(14, w: w6))),
                            Text(pct(sm.byBeneficiary[k]!, sm.expense), style: ts(12, w: w7, c: C.muted)),
                            const SizedBox(width: 10),
                            Text(money(sm.byBeneficiary[k]!), style: ts(14, w: w8)),
                          ]),
                        ),
                    ]),
            ),
            if (sm.byPerson.isNotEmpty) ...[
              const SectionTitle('Par personne'),
              AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Column(children: [
                  for (final p in sm.byPerson)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(children: [
                        Avatar(p.key, size: 34), const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(p.key, style: ts(14, w: w7)),
                          Text(sm.personNatures[p.key]!.map((n) => switch (n) { Nature.donation => 'donation', Nature.cadeau => 'cadeau', _ => 'dépense pour' }).join(', '),
                              style: ts(11, c: C.muted)),
                        ])),
                        Text(money(p.value), style: ts(14, w: w8)),
                      ]),
                    ),
                ]),
              ),
            ],
            const SectionTitle('Prêts du mois'),
            AppCard(child: Column(children: [
              _line('Prêts accordés', sm.lentOut), _line('Remboursements reçus', sm.repaidToMe),
              _line('Emprunts reçus', sm.borrowedIn), _line('Remboursements payés', sm.repaidByMe),
              const Hr(),
              _line('Sorties nettes', sm.netOut, bold: true),
              Align(alignment: Alignment.centerLeft,
                  child: Text('Dépenses + prêts accordés − remboursements reçus', style: ts(11, c: C.muted))),
            ])),
            const SectionTitle('Entrées par source'),
            AppCard(
              child: incomes.isEmpty
                  ? Text('Aucune entrée ce mois.', style: ts(14, c: C.muted))
                  : Column(children: [
                      for (final c in incomes)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(children: [
                            IconBubble(iconFor(c.cat.icon), Color(c.cat.color), size: 32), const SizedBox(width: 10),
                            Expanded(child: Text(c.cat.name, style: ts(14, w: w7))),
                            Text('+${money(c.total)}', style: ts(14, w: w8, c: C.income)),
                          ]),
                        ),
                    ]),
            ),
            const SectionTitle('Tendance sur 6 mois'),
            AppCard(child: Column(children: [
              SizedBox(
                height: 150,
                child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final t in trend)
                    Expanded(
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                          _bar(t.$2.income / maxTrend, C.income, t.$1 == month),
                          const SizedBox(width: 3),
                          _bar(t.$2.expense / maxTrend, C.expense, t.$1 == month),
                        ]),
                        const SizedBox(height: 6),
                        Text(monthLabel(t.$1).substring(0, 3), style: ts(11, w: t.$1 == month ? w8 : w6, c: t.$1 == month ? C.primary : C.muted)),
                      ]),
                    ),
                ]),
              ),
              const SizedBox(height: 10),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                dot(C.income), const SizedBox(width: 6), Text('Entrées', style: ts(12, w: w7, c: C.muted)),
                const SizedBox(width: 18),
                dot(C.expense), const SizedBox(width: 6), Text('Dépenses', style: ts(12, w: w7, c: C.muted)),
              ]),
            ])),
            const SectionTitle("Mes postes aujourd'hui"),
            AppCard(child: Column(children: [
              _line('Comptes et cash', avail), _line('Créances (on me doit)', store.owedToMe()),
              _line('Dettes (je dois)', -store.iOwe()), const Hr(),
              _line('Total', avail + store.owedToMe() - store.iOwe(), bold: true),
            ])),
          ],
        );
      });

  Widget _pill(String label, int v) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: ts(11, w: w7, c: Colors.white70)),
          FittedBox(child: Text(money(v), style: ts(14, w: w8, c: Colors.white))),
        ]),
      );

  Widget _bar(double f, Color c, bool sel) => Container(
        width: 11, height: (f * 120).clamp(3, 120).toDouble(),
        decoration: BoxDecoration(color: c.withValues(alpha: sel ? 1 : 0.45), borderRadius: BorderRadius.circular(6)),
      );

  Widget _catRow(CatTotal c, int max, int total) {
    final over = c.cat.budget > 0 && c.total > c.cat.budget;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          IconBubble(iconFor(c.cat.icon), Color(c.cat.color), size: 32), const SizedBox(width: 10),
          Expanded(child: Text(c.cat.name, style: ts(14, w: w7), overflow: TextOverflow.ellipsis)),
          Text(money(c.total), style: ts(14, w: w8)),
        ]),
        const SizedBox(height: 6),
        ProgressBar(value: c.total, max: c.cat.budget > 0 ? c.cat.budget : max, color: over ? C.expense : Color(c.cat.color), height: 6),
        const SizedBox(height: 3),
        Text('${pct(c.total, total)} des dépenses${c.cat.budget > 0 ? ' · budget ${money(c.cat.budget)}${over ? ' · dépassé' : ''}' : ''}',
            style: ts(11, w: w6, c: over ? C.expense : C.muted)),
      ]),
    );
  }

  Widget _line(String label, int v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Expanded(child: Text(label, style: ts(14, w: bold ? w8 : w6, c: bold ? C.text : C.muted))),
          Text(money(v), style: ts(14, w: w8, c: v < 0 ? C.expense : C.text)),
        ]),
      );
}
