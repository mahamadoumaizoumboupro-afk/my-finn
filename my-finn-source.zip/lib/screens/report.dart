import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'avoirs.dart';
import 'budget.dart';
import 'month_list.dart';
import 'revenus.dart';
import 'tx_form.dart';

const benefColors = {
  'moi': Color(0xFF5B4CF5),
  'maison': Color(0xFF14C8B4),
  'personne:pour': Color(0xFF3B82F6),
  'personne:donation': Color(0xFFF04461),
  'personne:cadeau': Color(0xFFF59E0B),
};

/// Partage un texte (WhatsApp, e-mail…) ; sur le web, le copie.
Future<void> shareText(BuildContext context, String text, String title) async {
  if (!kIsWeb) {
    try {
      await SharePlus.instance.share(ShareParams(text: text, subject: title));
      return;
    } catch (_) {}
  }
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted)
    toast(context, '$title copié. Tu peux le coller où tu veux.');
}

const _blues = [
  Color(0xFF0D33D9),
  Color(0xFF1650F0),
  Color(0xFF3B82F6),
  Color(0xFF9DBDF4),
  Color(0xFFC9D8F7),
];

String kShort(int v) => v >= 1000000
    ? '${(v / 1000000).toStringAsFixed(1).replaceAll('.', ',')}M'
    : '${(v / 1000).round()}k';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  String month = currentMonth();

  @override
  Widget build(BuildContext context) => Watch((context) {
    final sm = store.summary(month);
    final expenses = sm.byCategory.where((c) => !c.cat.isIncome).toList();
    final incomes = sm.byCategory.where((c) => c.cat.isIncome).toList();
    final months = [for (var i = 5; i >= 0; i--) shiftMonth(month, -i)];
    final trend = [for (final m in months) (m, store.summary(m))];
    final maxTrend = trend.fold<int>(
      1,
      (x, t) => [x, t.$2.income, t.$2.expense].reduce((a, b) => a > b ? a : b),
    );
    final avail = store.available();
    final ecarts = store.ecarts(month);
    final ecartTotal = ecarts.fold(0, (x, e) => x + e.$2);
    final ecartTxs = store
        .transactions(month: month)
        .where((t) => t.adjust)
        .toList();
    final into = store.countedInto(month);
    final elsewhere = store.countedElsewhere(month);
    String signed(int v) => '${v < 0 ? '−' : '+'}${num0(v.abs())}';

    return PageScaffold(
      title: 'Bilan',
      trailing: RoundIconButton(
        Icons.arrow_outward_rounded,
        onTap: () => shareText(
          context,
          store.monthReport(month),
          'Rapport ${monthLabel(month)}',
        ),
      ),
      children: [
        MonthSwitcher(
          month: month,
          onChanged: (m) => setState(() => month = m),
        ),
        Row(
          children: [
            Expanded(
              child: _flat(
                'Entrées',
                sm.income,
                C.income,
                () => push(
                  context,
                  MonthTxScreen(month: month, type: TxType.income),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _flat(
                'Dépenses',
                sm.expense + sm.fees,
                C.expense,
                () => push(
                  context,
                  MonthTxScreen(month: month, type: TxType.expense),
                ),
              ),
            ),
          ],
        ),
        if (into.isNotEmpty || elsewhere.isNotEmpty) ...[
          const SectionTitle('Comptés pour un autre mois'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final t in into)
                  _shiftedRow(
                    t,
                    t.date.compareTo(month) > 0
                        ? '${t.type == TxType.income ? 'Reçu' : 'Payé'} plus tard · le ${dayShort(t.date)}'
                        : '${t.type == TxType.income ? 'Reçu' : 'Payé'} en avance · le ${dayShort(t.date)}',
                  ),
                if (into.isNotEmpty)
                  _infoBox(
                    into.length == 1
                        ? "1 opération arrivée un autre mois compte ici, pour ${monthLabel(month).split(' ').first.toLowerCase()}."
                        : "${into.length} opérations arrivées un autre mois comptent ici, pour ${monthLabel(month).split(' ').first.toLowerCase()}.",
                  ),
                for (final t in elsewhere)
                  _shiftedRow(
                    t,
                    'Le ${dayShort(t.date)} · compte pour ${monthLabel(t.forMonth!).split(' ').first.toLowerCase()}',
                    muted: true,
                  ),
              ],
            ),
          ),
        ],
        if (ecarts.isNotEmpty) ...[
          const SectionTitle('Écarts du mois'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Écart total (argent non noté)',
                        style: ts(12, w: w7, c: C.muted),
                      ),
                    ),
                    Text(
                      signed(ecartTotal),
                      style: ts(
                        20,
                        w: w8,
                        c: ecartTotal < 0 ? C.expense : C.income,
                      ),
                    ),
                  ],
                ),
                for (final e in ecarts)
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(top: BorderSide(color: C.border)),
                    ),
                    margin: const EdgeInsets.only(top: 6),
                    child: Row(
                      children: [
                        AccountBadge(e.$1, size: 40),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(e.$1.name, style: ts(15, w: w7)),
                              Text(
                                e.$3 > 1
                                    ? '${e.$3} réajustements'
                                    : '1 réajustement',
                                style: ts(12, c: C.muted),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          signed(e.$2),
                          style: ts(
                            15,
                            w: w8,
                            c: e.$2 < 0 ? C.expense : C.income,
                          ),
                        ),
                      ],
                    ),
                  ),
                Text(
                  'Ces écarts comptent dans les entrées et dépenses du mois.',
                  style: ts(12, c: C.muted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Column(
              children: [
                for (var i = 0; i < ecartTxs.length; i++)
                  TxTile(
                    ecartTxs[i],
                    last: i == ecartTxs.length - 1,
                    onTap: () =>
                        push(context, TxFormScreen(id: ecartTxs[i].id)),
                  ),
              ],
            ),
          ),
        ],
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text("Où part l'argent", style: ts(15, w: w8)),
                  ),
                  Text(
                    num0(sm.expense),
                    style: ts(12, w: w6, c: C.muted),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              if (expenses.isEmpty)
                Text('Aucune dépense ce mois.', style: ts(14, c: C.muted))
              else
                Builder(
                  builder: (context) {
                    final top = expenses.take(4).toList();
                    final rest = expenses
                        .skip(4)
                        .fold(0, (x, c) => x + c.total);
                    final parts = [
                      for (final c in top) (c.cat.name, c.total),
                      if (rest > 0) ('Autres', rest),
                    ];
                    return Row(
                      children: [
                        Donut(
                          size: 118,
                          stroke: 16,
                          data: [
                            for (var i = 0; i < parts.length; i++)
                              (parts[i].$2, _blues[i % _blues.length]),
                          ],
                          center: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('Dépenses', style: ts(10, c: C.muted)),
                              Text(kShort(sm.expense), style: ts(13, w: w8)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            children: [
                              for (var i = 0; i < parts.length; i++)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 4,
                                  ),
                                  child: Row(
                                    children: [
                                      dot(_blues[i % _blues.length], 8),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          parts[i].$1,
                                          style: ts(12, w: w6),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      Text(
                                        '${(parts[i].$2 * 100 / sm.expense).round()} %',
                                        style: ts(12, w: w7),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
            ],
          ),
        ),
        Builder(
          builder: (context) {
            final weeks = List<int>.filled(5, 0);
            for (final t in store.transactions(
              month: month,
              type: TxType.expense,
            )) {
              final d = int.tryParse(t.date.substring(8, 10)) ?? 1;
              weeks[((d - 1) ~/ 7).clamp(0, 4)] += t.amount;
            }
            final nWeeks = weeks[4] > 0 || month == currentMonth() ? 5 : 4;
            var cur = nWeeks - 1;
            if (month == currentMonth()) {
              cur = ((DateTime.now().day - 1) ~/ 7).clamp(0, 4);
            }
            final maxW = weeks.fold(1, (x, v) => v > x ? v : x);
            final saved = sm.income - sm.expense - sm.fees;
            final ratio = sm.income > 0
                ? (saved / sm.income).clamp(0.0, 1.0).toDouble()
                : 0.0;
            return IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: AppCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Par semaine',
                            style: ts(12, w: w6, c: C.muted),
                          ),
                          const SizedBox(height: 10),
                          SizedBox(
                            height: 70,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                for (var i = 0; i < nWeeks; i++)
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 3,
                                      ),
                                      child: Container(
                                        height: (weeks[i] / maxW * 70)
                                            .clamp(4, 70)
                                            .toDouble(),
                                        decoration: BoxDecoration(
                                          color: i == cur
                                              ? C.expense
                                              : C.expense.withValues(
                                                  alpha: 0.14,
                                                ),
                                          borderRadius: BorderRadius.circular(
                                            3,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Text('S1', style: ts(11, c: C.muted)),
                              const Spacer(),
                              Text('S$nWeeks', style: ts(11, c: C.muted)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Épargné',
                            style: ts(12, w: w6, c: C.muted),
                          ),
                          const SizedBox(height: 8),
                          Center(
                            child: Donut(
                              size: 66,
                              stroke: 7,
                              data: [
                                (ratio, C.income),
                                (1 - ratio, Colors.transparent),
                              ],
                              center: Text(
                                '${(ratio * 100).round()} %',
                                style: ts(13, w: w8),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Center(
                            child: Text(
                              saved >= 0
                                  ? '${num0(saved)} gardés'
                                  : '${num0(-saved)} en trop',
                              style: ts(12, c: C.muted),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        Builder(
          builder: (context) {
            final ms = store.incomeMonths();
            if (ms.isEmpty) return const SizedBox.shrink();
            final last12 = ms.length > 12 ? ms.sublist(ms.length - 12) : ms;
            final net = last12.fold(0, (x, m) => x + m.net);
            final maxN = last12.fold(1, (x, m) => m.net > x ? m.net : x);
            return AppCard(
              onTap: () => push(context, const IncomeHistoryScreen()),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Revenus · ${last12.length} mois',
                          style: ts(15, w: w8),
                        ),
                      ),
                      Text(
                        num0(net),
                        style: ts(14, w: w8, c: C.income),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 36,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        for (final m in last12)
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 2,
                              ),
                              child: Container(
                                height: (m.net / maxN * 36)
                                    .clamp(18, 36)
                                    .toDouble(),
                                decoration: BoxDecoration(
                                  color: m == last12.last
                                      ? C.income
                                      : C.income.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        Builder(
          builder: (context) {
            final allBudget = store
                .cats(income: false)
                .fold(0, (x, c) => x + c.budget);
            final spentB = expenses
                .where((c) => c.cat.budget > 0)
                .fold(0, (x, c) => x + c.total);
            return AppCard(
              onTap: () => push(context, BudgetScreen(month: month)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text('Mon budget', style: ts(15, w: w8)),
                      ),
                      Text(
                        allBudget > 0
                            ? '${num0(spentB)} / ${num0(allBudget)}'
                            : 'À définir',
                        style: ts(12, w: w6, c: C.muted),
                      ),
                      Icon(Icons.chevron_right_rounded, color: C.faint),
                    ],
                  ),
                  if (allBudget > 0) ...[
                    const SizedBox(height: 10),
                    ProgressBar(
                      value: spentB,
                      max: allBudget,
                      color: budgetColor(spentB, allBudget),
                      height: 6,
                    ),
                  ],
                ],
              ),
            );
          },
        ),
        const SectionTitle('Pour qui ?'),
        AppCard(
          child: sm.byBeneficiary.isEmpty
              ? Text('Aucune dépense.', style: ts(14, c: C.muted))
              : Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(7),
                      child: SizedBox(
                        height: 14,
                        child: Row(
                          children: [
                            for (final k in beneficiaryLabels.keys.where(
                              sm.byBeneficiary.containsKey,
                            ))
                              Expanded(
                                flex: sm.byBeneficiary[k]!,
                                child: Container(color: benefColors[k]),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    for (final k in beneficiaryLabels.keys.where(
                      sm.byBeneficiary.containsKey,
                    ))
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          children: [
                            dot(benefColors[k]!, 10),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                beneficiaryLabels[k]!,
                                style: ts(14, w: w6),
                              ),
                            ),
                            Text(
                              pct(sm.byBeneficiary[k]!, sm.expense),
                              style: ts(12, w: w7, c: C.muted),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              money(sm.byBeneficiary[k]!),
                              style: ts(14, w: w8),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
        if (sm.byPerson.isNotEmpty) ...[
          const SectionTitle('Par personne'),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Column(
              children: [
                for (final p in sm.byPerson)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Avatar(p.key, size: 34),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.key, style: ts(14, w: w7)),
                              Text(
                                sm.personNatures[p.key]!
                                    .map(
                                      (n) => switch (n) {
                                        Nature.donation => 'donation',
                                        Nature.cadeau => 'cadeau',
                                        _ => 'dépense pour',
                                      },
                                    )
                                    .join(', '),
                                style: ts(11, c: C.muted),
                              ),
                            ],
                          ),
                        ),
                        Text(money(p.value), style: ts(14, w: w8)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
        const SectionTitle('Prêts du mois'),
        AppCard(
          child: Column(
            children: [
              _line('Prêts accordés', sm.lentOut),
              _line('Remboursements reçus', sm.repaidToMe),
              _line('Emprunts reçus', sm.borrowedIn),
              _line('Remboursements payés', sm.repaidByMe),
              const Hr(),
              _line('Sorties nettes', sm.netOut, bold: true),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Dépenses + prêts accordés − remboursements reçus',
                  style: ts(11, c: C.muted),
                ),
              ),
            ],
          ),
        ),
        const SectionTitle('Entrées par source'),
        AppCard(
          child: incomes.isEmpty
              ? Text('Aucune entrée ce mois.', style: ts(14, c: C.muted))
              : Column(
                  children: [
                    for (final c in incomes)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          children: [
                            IconBubble(
                              iconFor(c.cat.icon),
                              Color(c.cat.color),
                              size: 32,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(c.cat.name, style: ts(14, w: w7)),
                            ),
                            Text(
                              '+${money(c.total)}',
                              style: ts(14, w: w8, c: C.income),
                            ),
                          ],
                        ),
                      ),
                    if (sm.taxes > 0) ...[
                      const Hr(),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Taxes déjà retirées (brut ${money(sm.income + sm.taxes)})',
                              style: ts(12, w: w6, c: C.muted),
                            ),
                          ),
                          Text(
                            money(sm.taxes),
                            style: ts(13, w: w8, c: C.expense),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
        ),
        const SectionTitle('Tendance sur 6 mois'),
        AppCard(
          child: Column(
            children: [
              SizedBox(
                height: 150,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    for (final t in trend)
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                _bar(
                                  t.$2.income / maxTrend,
                                  C.income,
                                  t.$1 == month,
                                ),
                                const SizedBox(width: 3),
                                _bar(
                                  t.$2.expense / maxTrend,
                                  C.expense,
                                  t.$1 == month,
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              monthLabel(t.$1).substring(0, 3),
                              style: ts(
                                11,
                                w: t.$1 == month ? w8 : w6,
                                c: t.$1 == month ? C.primary : C.muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  dot(C.income),
                  const SizedBox(width: 6),
                  Text(
                    'Entrées',
                    style: ts(12, w: w7, c: C.muted),
                  ),
                  const SizedBox(width: 18),
                  dot(C.expense),
                  const SizedBox(width: 6),
                  Text(
                    'Dépenses',
                    style: ts(12, w: w7, c: C.muted),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SectionTitle("Mes avoirs aujourd'hui"),
        Builder(
          builder: (context) {
            final a = store.avoirs();
            return AppCard(
              onTap: () => push(context, const AvoirsScreen()),
              child: Column(
                children: [
                  _line('Comptes et cash', avail),
                  _line('Placements, tontines, bons', a.placements),
                  _line('Créances (on me doit)', a.creances),
                  _line('Dettes (je dois)', -a.dettes),
                  const Hr(),
                  _line('Total', a.total, bold: true),
                ],
              ),
            );
          },
        ),
      ],
    );
  });

  Widget _shiftedRow(Tx t, String sub, {bool muted = false}) {
    final acc = store.account(t.accountId);
    final inc = t.type == TxType.income;
    final title = t.label.isNotEmpty
        ? t.label
        : store.category(t.categoryId)?.name ?? 'Opération';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          if (acc != null) AccountBadge(acc, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: ts(15, w: w7, c: muted ? C.muted : null),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(sub, style: ts(12, c: C.muted)),
              ],
            ),
          ),
          Text(
            '${inc ? '+' : '−'}${num0(t.amount)}',
            style: ts(
              15,
              w: w8,
              c: muted ? C.muted : (inc ? C.income : C.text),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoBox(String text) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(top: 6, bottom: 4),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: C.primarySoft,
      borderRadius: BorderRadius.circular(10),
    ),
    child: Text(text, style: ts(12, w: w6, h: 1.45)),
  );

  Widget _flat(String label, int v, Color c, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: c,
            borderRadius: BorderRadius.circular(cardRadius),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: ts(12, w: w6, c: Colors.white.withValues(alpha: 0.9)),
              ),
              FittedBox(
                child: Text(
                  num0(v),
                  style: ts(18, w: w8, c: Colors.white),
                ),
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Text(
                    'Voir tout',
                    style: ts(
                      12,
                      w: w7,
                      c: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                  Icon(
                    Icons.chevron_right_rounded,
                    size: 16,
                    color: Colors.white.withValues(alpha: 0.9),
                  ),
                ],
              ),
            ],
          ),
        ),
      );

  Widget _bar(double f, Color c, bool sel) => Container(
    width: 11,
    height: (f * 120).clamp(3, 120).toDouble(),
    decoration: BoxDecoration(
      color: c.withValues(alpha: sel ? 1 : 0.45),
      borderRadius: BorderRadius.circular(6),
    ),
  );

  Widget _line(String label, int v, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: ts(14, w: bold ? w8 : w6, c: bold ? C.text : C.muted),
          ),
        ),
        Text(
          money(v),
          style: ts(14, w: w8, c: v < 0 ? C.expense : C.text),
        ),
      ],
    ),
  );
}
