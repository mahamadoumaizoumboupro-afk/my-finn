import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

const _sourceColors = [
  Color(0xFF0E9F6E),
  Color(0xFF2F6FED),
  Color(0xFFD9A21B),
  Color(0xFF8B5CF6),
  Color(0xFFE5484D),
  Color(0xFF06B6D4),
  Color(0xFFF97316),
  Color(0xFFEC4899),
  Color(0xFF64748B),
  Color(0xFF84CC16),
];

String _shortYm(String ym) {
  final l = monthLabel(ym);
  return '${l.split(' ').first.substring(0, 3)}. ${ym.substring(2, 4)}';
}

/// Résumé des revenus, pour le Bilan.
class IncomeHistoryCard extends StatelessWidget {
  const IncomeHistoryCard({super.key});
  @override
  Widget build(BuildContext context) {
    final months = store.incomeMonths();
    if (months.isEmpty) return const SizedBox.shrink();
    final last12 = months.length > 12
        ? months.sublist(months.length - 12)
        : months;
    final net = last12.fold(0, (x, m) => x + m.net);
    final maxNet = months.fold(1, (x, m) => m.net > x ? m.net : x);
    return AppCard(
      onTap: () => push(context, const IncomeHistoryScreen()),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${last12.length} derniers mois · ${_shortYm(last12.first.month)} → ${_shortYm(last12.last.month)}',
            style: ts(12, w: w7, c: C.muted),
          ),
          const SizedBox(height: 4),
          Text(
            money(net),
            style: ts(22, w: w8, c: C.income),
          ),
          Text(
            'net, soit ${money(net / last12.length)} par mois en moyenne',
            style: ts(12, c: C.muted),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 60,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final m in last12)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: FractionallySizedBox(
                        heightFactor: (m.net / maxNet).clamp(0.04, 1.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: m == last12.last
                                ? C.income
                                : C.income.withValues(alpha: 0.4),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                'Voir le détail mois par mois',
                style: ts(13, w: w8, c: C.primary),
              ),
              Icon(Icons.chevron_right_rounded, color: C.primary),
            ],
          ),
        ],
      ),
    );
  }
}

/// Historique complet des revenus : par source et mois par mois.
class IncomeHistoryScreen extends StatefulWidget {
  const IncomeHistoryScreen({super.key});
  @override
  State<IncomeHistoryScreen> createState() => _IncomeHistoryScreenState();
}

class _IncomeHistoryScreenState extends State<IncomeHistoryScreen> {
  final open = <String>{};

  @override
  Widget build(BuildContext context) {
    final months = store.incomeMonths();
    if (months.isEmpty) {
      return const SubPage(
        title: 'Mes revenus',
        children: [
          EmptyState(
            'Aucun revenu pour le moment.',
            icon: Icons.payments_rounded,
          ),
        ],
      );
    }
    final gross = months.fold(0, (x, m) => x + m.gross);
    final tax = months.fold(0, (x, m) => x + m.tax);
    final sources = <String, int>{};
    for (final m in months) {
      m.bySource.forEach((k, v) => sources[k] = (sources[k] ?? 0) + v);
    }
    final srcList = sources.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final colorOf = {
      for (var i = 0; i < srcList.length; i++)
        srcList[i].key: _sourceColors[i % _sourceColors.length],
    };
    final maxNet = months.fold(1, (x, m) => m.net > x ? m.net : x);

    return SubPage(
      title: 'Mes revenus',
      children: [
        GradientBox(
          gradient: heroGradient,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${_shortYm(months.first.month)} → ${_shortYm(months.last.month)} · ${months.length} mois',
                style: ts(13, w: w6, c: Colors.white70),
              ),
              const SizedBox(height: 4),
              FittedBox(
                child: Text(
                  money(gross - tax),
                  style: ts(30, w: w8, c: Colors.white, ls: -1),
                ),
              ),
              Text(
                'net encaissé',
                style: ts(12, w: w6, c: Colors.white70),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _stat('Brut', gross)),
                  const SizedBox(width: 10),
                  Expanded(child: _stat('Taxes', -tax)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _stat('Par mois', (gross - tax) ~/ months.length),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SectionTitle('Par source'),
        AppCard(
          child: Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(7),
                child: SizedBox(
                  height: 14,
                  child: Row(
                    children: [
                      for (final e in srcList)
                        if (e.value > 0)
                          Expanded(
                            flex: e.value,
                            child: Container(color: colorOf[e.key]),
                          ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              for (final e in srcList)
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => push(
                    context,
                    IncomeSourceScreen(source: e.key, color: colorOf[e.key]!),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    child: Row(
                      children: [
                        dot(colorOf[e.key]!, 10),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            e.key,
                            style: ts(14, w: w6),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Text(
                          pct(e.value, gross),
                          style: ts(12, w: w7, c: C.muted),
                        ),
                        const SizedBox(width: 10),
                        Text(money(e.value), style: ts(14, w: w8)),
                        Icon(Icons.chevron_right_rounded, color: C.faint),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SectionTitle('Mois par mois'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              for (final m in months.reversed)
                InkWell(
                  onTap: () => setState(
                    () => open.contains(m.month)
                        ? open.remove(m.month)
                        : open.add(m.month),
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: C.border)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                monthLabel(m.month),
                                style: ts(15, w: w7),
                              ),
                            ),
                            Text(
                              money(m.net),
                              style: ts(15, w: w8, c: C.income),
                            ),
                            Icon(
                              open.contains(m.month)
                                  ? Icons.expand_less_rounded
                                  : Icons.expand_more_rounded,
                              color: C.faint,
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ProgressBar(
                          value: m.net,
                          max: maxNet,
                          color: C.income,
                          height: 6,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Brut ${money(m.gross)}${m.tax > 0 ? ' · taxes ${money(m.tax)}' : ''}'
                          '${m.fromHistory ? '' : ' · d\'après mes entrées'}',
                          style: ts(11, w: w6, c: C.muted),
                        ),
                        if (open.contains(m.month))
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Column(
                              children: [
                                for (final e
                                    in (m.bySource.entries.toList()..sort(
                                      (a, b) => b.value.compareTo(a.value),
                                    )))
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 3,
                                    ),
                                    child: Row(
                                      children: [
                                        dot(colorOf[e.key] ?? C.muted, 8),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            e.key,
                                            style: ts(13, w: w6),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Text(
                                          money(e.value),
                                          style: ts(13, w: w7),
                                        ),
                                      ],
                                    ),
                                  ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        Text(
          'Les montants sont bruts par source. Le net retire les taxes (taxe BCR, ISB).',
          style: ts(12, c: C.muted),
        ),
      ],
    );
  }

  Widget _stat(String label, int v) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: ts(11, w: w7, c: Colors.white70),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        FittedBox(
          child: Text(
            money(v),
            style: ts(14, w: w8, c: Colors.white),
          ),
        ),
      ],
    ),
  );
}

/// Tout ce qu'une source de revenus a versé, mois par mois, avec un choix par année.
class IncomeSourceScreen extends StatefulWidget {
  final String source;
  final Color color;
  const IncomeSourceScreen({
    super.key,
    required this.source,
    required this.color,
  });
  @override
  State<IncomeSourceScreen> createState() => _IncomeSourceScreenState();
}

class _IncomeSourceScreenState extends State<IncomeSourceScreen> {
  String? year; // null = toutes les années

  String get source => widget.source;
  Color get color => widget.color;

  @override
  Widget build(BuildContext context) {
    final all = store.incomeOfSource(source);
    final total = all.fold(0, (x, r) => x + r.gross);
    final nMonths = all.map((r) => r.month).toSet().length;
    final years = all.map((r) => r.month.substring(0, 4)).toSet().toList()
      ..sort((a, b) => b.compareTo(a));
    final first = years.isEmpty ? '' : years.last;
    final rows = year == null
        ? all
        : all.where((r) => r.month.startsWith(year!)).toList();
    final yTotal = rows.fold(0, (x, r) => x + r.gross);
    final yMonths = rows.map((r) => r.month).toSet().length;
    final yEst = rows.any((r) => r.h?.est ?? false);
    return SubPage(
      title: source,
      children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: store.dark ? null : C.income.withValues(alpha: 0.12),
            gradient: store.dark ? tintGradient(C.income) : null,
            border: store.dark
                ? Border.all(color: C.income.withValues(alpha: 0.35))
                : null,
            borderRadius: BorderRadius.circular(cardRadius),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                years.length > 1 ? 'Total reçu depuis $first' : 'Total reçu',
                style: ts(12, w: w7, c: C.income),
              ),
              FittedBox(
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: '${num0(total)} ',
                        style: ts(30, w: w8, c: C.income, ls: -1),
                      ),
                      TextSpan(
                        text: 'FCFA',
                        style: ts(14, w: w8, c: C.income),
                      ),
                    ],
                  ),
                ),
              ),
              if (nMonths > 0)
                Text(
                  '$nMonths mois · environ ${money(total / nMonths)} par mois',
                  style: ts(12, w: w6, c: C.muted),
                ),
            ],
          ),
        ),
        if (years.length > 1)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final y in [null, ...years])
                  GestureDetector(
                    onTap: () => setState(() => year = y),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: year == y ? C.primary : C.card,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: year == y ? Colors.transparent : C.border,
                        ),
                      ),
                      child: Text(
                        y ?? 'Tout',
                        style: ts(
                          13,
                          w: w8,
                          c: year == y ? Colors.white : C.muted,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        if (year != null)
          AppCard(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            '$year · $yMonths mois',
                            style: ts(12, w: w6, c: C.muted),
                          ),
                          if (yEst) estTag(),
                        ],
                      ),
                      Text(
                        '+${num0(yTotal)}',
                        style: ts(22, w: w8, c: C.income, ls: -0.5),
                      ),
                    ],
                  ),
                ),
                if (yMonths > 0)
                  Text(
                    'environ\n${num0(yTotal ~/ yMonths)} / mois',
                    textAlign: TextAlign.right,
                    style: ts(12, w: w6, c: C.muted),
                  ),
              ],
            ),
          ),
        SectionTitle(year == null ? 'Mois par mois' : 'Mois par mois · $year'),
        if (rows.isEmpty)
          const EmptyState('Rien pour le moment.')
        else
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(
              children: [
                for (var i = 0; i < rows.length; i++)
                  _row(context, rows[i], i == rows.length - 1),
              ],
            ),
          ),
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Text(
            'Montants bruts. Chaque versement est rangé dans son mois (« Pour quel mois ? »), avec le jour où il est vraiment arrivé.',
            style: ts(12, c: C.muted),
          ),
        ),
      ],
    );
  }

  Widget _row(
    BuildContext context,
    ({String month, Tx? tx, HistIncome? h, int gross}) r,
    bool last,
  ) {
    final t = r.tx;
    final acc = t == null ? null : store.account(t.accountId);
    // Le détail (nom de la mission, du client…) quand il y en a un.
    final h = r.h;
    final detail = h != null
        ? (h.label.isNotEmpty && h.label != h.source && h.label != 'Salaire'
              ? h.label
              : null)
        : (t!.label.isNotEmpty && t.label != source ? t.label : null);
    final when = t == null
        ? "d'après ton historique"
        : 'reçu le ${dayShort(t.date)}${acc != null ? ' · ${acc.name}' : ''}';
    final title = detail ?? monthLabel(r.month);
    final sub = detail != null
        ? '${monthLabel(r.month)} · $when'
        : '${when[0].toUpperCase()}${when.substring(1)}';
    return InkWell(
      onTap: t == null ? null : () => push(context, TxFormScreen(id: t.id)),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
          border: last ? null : Border(bottom: BorderSide(color: C.border)),
        ),
        child: Row(
          children: [
            acc != null
                ? AccountBadge(acc, size: 40)
                : IconBubble(Icons.history_rounded, color, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          title,
                          style: ts(15, w: w7),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (h?.est ?? false) estTag(),
                    ],
                  ),
                  Text(
                    sub,
                    style: ts(12, c: C.muted),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Text(
              '+${num0(r.gross)}',
              style: ts(15, w: w8, c: C.income),
            ),
          ],
        ),
      ),
    );
  }
}
