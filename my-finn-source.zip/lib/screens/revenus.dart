import 'package:flutter/material.dart';

import '../format.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

const _sourceColors = [
  Color(0xFF0E9F6E),
  Color(0xFF2F6FED),
  Color(0xFFD9A21B),
  Color(0xFF8B5CF6),
  Color(0xFFE5484D),
  Color(0xFF06B6D4),
  Color(0xFFF97316),
  Color(0xFFEC4899),
  Color(0xFF64748B),
  Color(0xFF84CC16),
];

String shortMonth(String ym) {
  final l = monthLabel(ym);
  return '${l.split(' ').first.substring(0, 3)}. ${ym.substring(2, 4)}';
}

/// Résumé des revenus, pour le Bilan.
class IncomeHistoryCard extends StatelessWidget {
  const IncomeHistoryCard({super.key});
  @override
  Widget build(BuildContext context) {
    final months = store.incomeMonths();
    if (months.isEmpty) return const SizedBox.shrink();
    final last12 = months.length > 12
        ? months.sublist(months.length - 12)
        : months;
    final net = last12.fold(0, (x, m) => x + m.net);
    final maxNet = months.fold(1, (x, m) => m.net > x ? m.net : x);
    return AppCard(
      onTap: () => push(context, const IncomeHistoryScreen()),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${last12.length} derniers mois · ${shortMonth(last12.first.month)} → ${shortMonth(last12.last.month)}',
            style: ts(12, w: w7, c: C.muted),
          ),
          const SizedBox(height: 4),
          Text(
            money(net),
            style: ts(22, w: w8, c: C.income),
          ),
          Text(
            'net, soit ${money(net / last12.length)} par mois en moyenne',
            style: ts(12, c: C.muted),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 60,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final m in last12)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: FractionallySizedBox(
                        heightFactor: (m.net / maxNet).clamp(0.04, 1.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: m == last12.last
                                ? C.income
                                : C.income.withValues(alpha: 0.4),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                'Voir le détail mois par mois',
                style: ts(13, w: w8, c: C.primary),
              ),
              Icon(Icons.chevron_right_rounded, color: C.primary),
            ],
          ),
        ],
      ),
    );
  }
}

/// Historique complet des revenus : par source et mois par mois.
class IncomeHistoryScreen extends StatefulWidget {
  const IncomeHistoryScreen({super.key});
  @override
  State<IncomeHistoryScreen> createState() => _IncomeHistoryScreenState();
}

class _IncomeHistoryScreenState extends State<IncomeHistoryScreen> {
  final open = <String>{};

  @override
  Widget build(BuildContext context) {
    final months = store.incomeMonths();
    if (months.isEmpty) {
      return const SubPage(
        title: 'Mes revenus',
        children: [
          EmptyState(
            'Aucun revenu pour le moment.',
            icon: Icons.payments_rounded,
          ),
        ],
      );
    }
    final gross = months.fold(0, (x, m) => x + m.gross);
    final tax = months.fold(0, (x, m) => x + m.tax);
    final sources = <String, int>{};
    for (final m in months) {
      m.bySource.forEach((k, v) => sources[k] = (sources[k] ?? 0) + v);
    }
    final srcList = sources.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final colorOf = {
      for (var i = 0; i < srcList.length; i++)
        srcList[i].key: _sourceColors[i % _sourceColors.length],
    };
    final maxNet = months.fold(1, (x, m) => m.net > x ? m.net : x);

    return SubPage(
      title: 'Mes revenus',
      children: [
        GradientBox(
          gradient: heroGradient,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${shortMonth(months.first.month)} → ${shortMonth(months.last.month)} · ${months.length} mois',
                style: ts(13, w: w6, c: Colors.white70),
              ),
              const SizedBox(height: 4),
              FittedBox(
                child: Text(
                  money(gross - tax),
                  style: ts(30, w: w8, c: Colors.white, ls: -1),
                ),
              ),
              Text(
                'net encaissé',
                style: ts(12, w: w6, c: Colors.white70),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _stat('Brut', gross)),
                  const SizedBox(width: 10),
                  Expanded(child: _stat('Taxes', -tax)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _stat('Par mois', (gross - tax) ~/ months.length),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SectionTitle('Par source'),
        AppCard(
          child: Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(7),
                child: SizedBox(
                  height: 14,
                  child: Row(
                    children: [
                      for (final e in srcList)
                        if (e.value > 0)
                          Expanded(
                            flex: e.value,
                            child: Container(color: colorOf[e.key]),
                          ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              for (final e in srcList)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Row(
                    children: [
                      dot(colorOf[e.key]!, 10),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          e.key,
                          style: ts(14, w: w6),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(
                        pct(e.value, gross),
                        style: ts(12, w: w7, c: C.muted),
                      ),
                      const SizedBox(width: 10),
                      Text(money(e.value), style: ts(14, w: w8)),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SectionTitle('Mois par mois'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              for (final m in months.reversed)
                InkWell(
                  onTap: () => setState(
                    () => open.contains(m.month)
                        ? open.remove(m.month)
                        : open.add(m.month),
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: C.border)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                monthLabel(m.month),
                                style: ts(15, w: w7),
                              ),
                            ),
                            Text(
                              money(m.net),
                              style: ts(15, w: w8, c: C.income),
                            ),
                            Icon(
                              open.contains(m.month)
                                  ? Icons.expand_less_rounded
                                  : Icons.expand_more_rounded,
                              color: C.faint,
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ProgressBar(
                          value: m.net,
                          max: maxNet,
                          color: C.income,
                          height: 6,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Brut ${money(m.gross)}${m.tax > 0 ? ' · taxes ${money(m.tax)}' : ''}'
                          '${m.fromHistory ? '' : ' · d\'après mes entrées'}',
                          style: ts(11, w: w6, c: C.muted),
                        ),
                        if (open.contains(m.month))
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Column(
                              children: [
                                for (final e
                                    in (m.bySource.entries.toList()..sort(
                                      (a, b) => b.value.compareTo(a.value),
                                    )))
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 3,
                                    ),
                                    child: Row(
                                      children: [
                                        dot(colorOf[e.key] ?? C.muted, 8),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            e.key,
                                            style: ts(13, w: w6),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Text(
                                          money(e.value),
                                          style: ts(13, w: w7),
                                        ),
                                      ],
                                    ),
                                  ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        Text(
          'Les montants sont bruts par source. Le net retire les taxes (taxe BCR, ISB).',
          style: ts(12, c: C.muted),
        ),
      ],
    );
  }

  Widget _stat(String label, int v) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: ts(11, w: w7, c: Colors.white70),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        FittedBox(
          child: Text(
            money(v),
            style: ts(14, w: w8, c: Colors.white),
          ),
        ),
      ],
    ),
  );
}
