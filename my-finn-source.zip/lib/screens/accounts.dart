import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});
  @override
  Widget build(BuildContext context) => Watch((context) {
    final accs = store.activeAccounts;
    final inT = accs.where((a) => a.includeInTotal).toList();
    final outT = accs.where((a) => !a.includeInTotal).toList();
    final avail = store.available();
    Widget list(List<Account> l) => AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Column(
        children: [
          for (var i = 0; i < l.length; i++)
            InkWell(
              onTap: () => push(context, AccountDetailScreen(id: l[i].id)),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  border: i == l.length - 1
                      ? null
                      : Border(bottom: BorderSide(color: C.border)),
                ),
                child: Row(
                  children: [
                    AccountBadge(l[i]),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(l[i].name, style: ts(15, w: w7)),
                          Text(
                            accountTypeLabel(l[i].type),
                            style: ts(12, c: C.muted),
                          ),
                        ],
                      ),
                    ),
                    Text(num0(store.balance(l[i])), style: ts(15, w: w8)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
    final shares = [
      for (final a in inT)
        if (store.balance(a) > 0) (a, store.balance(a)),
    ]..sort((x, y) => y.$2.compareTo(x.$2));
    final shareTotal = shares.fold(0, (x, e) => x + e.$2);
    const barColors = [
      Color(0xFF1650F0),
      Color(0xFF0E9F6E),
      Color(0xFFF97316),
      Color(0xFF9DBDF4),
      Color(0xFF8B5CF6),
    ];
    String short(String n) => n.replaceFirst(RegExp(r'^Compte\s+'), '');
    return SubPage(
      title: 'Mes comptes',
      actions: [
        RoundIconButton(
          Icons.add_rounded,
          onTap: () => push(context, const AccountFormScreen()),
        ),
      ],
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Disponible',
                style: ts(12, w: w6, c: C.muted),
              ),
              const SizedBox(height: 4),
              FittedBox(
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: num0(avail),
                        style: ts(30, w: w8, ls: -0.8),
                      ),
                      TextSpan(
                        text: '  FCFA',
                        style: ts(13, w: w8, c: C.muted),
                      ),
                    ],
                  ),
                ),
              ),
              if (shareTotal > 0) ...[
                const SizedBox(height: 12),
                SizedBox(
                  height: 8,
                  child: Row(
                    children: [
                      for (var i = 0; i < shares.length; i++) ...[
                        if (i > 0) const SizedBox(width: 3),
                        Expanded(
                          flex: (shares[i].$2 * 1000 ~/ shareTotal).clamp(
                            12,
                            1000,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: barColors[i % barColors.length],
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  [
                    for (final e in shares.take(3))
                      '${short(e.$1.name)} ${(e.$2 * 100 / shareTotal).round()} %',
                  ].join(' · '),
                  style: ts(12, c: C.muted),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
        const SectionTitle('Comptes'),
        list(inT),
        if (outT.isNotEmpty) ...[
          SectionTitle(
            'Placements',
            trailing: Text(
              num0(outT.fold(0, (x, a) => x + store.balance(a))),
              style: ts(13, w: w8, c: C.primary),
            ),
          ),
          list(outT),
        ],
      ],
    );
  });
}

class AccountDetailScreen extends StatefulWidget {
  final int id;
  const AccountDetailScreen({super.key, required this.id});
  @override
  State<AccountDetailScreen> createState() => _AccountDetailScreenState();
}

class _AccountDetailScreenState extends State<AccountDetailScreen> {
  String month = currentMonth();
  @override
  Widget build(BuildContext context) => Watch((context) {
    final a = store.account(widget.id);
    if (a == null) return const SubPage(title: '', children: []);
    final txs = store.transactions(accountId: a.id, month: month);
    return SubPage(
      title: a.name,
      actions: [
        RoundIconButton(
          Icons.edit_outlined,
          onTap: () => push(context, AccountFormScreen(id: a.id)),
        ),
      ],
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  AccountBadge(a, size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "Solde dans l'app",
                      style: ts(14, w: w6, c: C.muted),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(money(store.balance(a)), style: ts(30, w: w8, ls: -0.8)),
              Text(
                'Solde de départ : ${money(a.initialBalance)}',
                style: ts(12, c: C.muted),
              ),
              Text(
                'Les prêts et remboursements liés à ce compte sont inclus.',
                style: ts(12, c: C.muted),
              ),
              const SizedBox(height: 14),
              AppButton(
                'Réajuster le solde',
                icon: Icons.sync_rounded,
                kind: BtnKind.ghost,
                onTap: () => push(context, AdjustBalanceScreen(id: a.id)),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  'Tu as moins (ou plus) en vrai ? Corrige ici.',
                  style: ts(12, c: C.muted),
                ),
              ),
            ],
          ),
        ),
        MonthSwitcher(
          month: month,
          onChanged: (m) => setState(() => month = m),
        ),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: txs.isEmpty
              ? const EmptyState('Aucune opération sur ce compte ce mois-ci.')
              : Column(
                  children: [
                    for (var i = 0; i < txs.length; i++)
                      TxTile(
                        txs[i],
                        last: i == txs.length - 1,
                        onTap: () => push(context, TxFormScreen(id: txs[i].id)),
                      ),
                  ],
                ),
        ),
      ],
    );
  });
}

class AccountFormScreen extends StatefulWidget {
  final int? id;
  const AccountFormScreen({super.key, this.id});
  @override
  State<AccountFormScreen> createState() => _AccountFormScreenState();
}

class _AccountFormScreenState extends State<AccountFormScreen> {
  final name = TextEditingController(),
      initial = TextEditingController(text: '0');
  String type = 'mobile';
  bool include = true;
  int color = paletteChoices.first;

  @override
  void initState() {
    super.initState();
    final a = widget.id == null ? null : store.account(widget.id);
    if (a != null) {
      name.text = a.name;
      type = a.type;
      initial.text = num0(a.initialBalance);
      include = a.includeInTotal;
      color = a.color;
    }
  }

  void save() {
    if (name.text.trim().isEmpty)
      return toast(context, 'Donne un nom au compte.');
    final v = parseAmount(initial.text.isEmpty ? '0' : initial.text);
    if (v == null) return toast(context, 'Solde de départ invalide.');
    final a = widget.id == null
        ? Account(id: 0, name: '')
        : store.account(widget.id)!;
    a
      ..name = name.text.trim()
      ..type = type
      ..initialBalance = v
      ..includeInTotal = include
      ..color = color;
    store.saveAccount(a);
    savedToast(context, 'Compte enregistré ✅');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => SubPage(
    title: widget.id == null ? 'Nouveau compte' : 'Modifier le compte',
    children: [
      AppField(
        label: 'Nom',
        controller: name,
        hint: 'Ex : Compte Coris, Nita, Cash',
      ),
      const FieldLabel('Type'),
      Wrap(
        children: [
          for (final t in accountTypes)
            AppChip(
              t.$2,
              icon: t.$3,
              selected: type == t.$1,
              onTap: () => setState(() => type = t.$1),
            ),
        ],
      ),
      const SizedBox(height: 8),
      AppField(
        label: 'Solde de départ (avant la première opération notée)',
        controller: initial,
        keyboard: TextInputType.number,
      ),
      AppCard(
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Compter dans le disponible', style: ts(14, w: w7)),
                  Text(
                    "Désactive pour les bons d'essence, tickets, etc.",
                    style: ts(12, c: C.muted),
                  ),
                ],
              ),
            ),
            Switch(
              value: include,
              onChanged: (v) => setState(() => include = v),
            ),
          ],
        ),
      ),
      const FieldLabel('Couleur'),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final c in paletteChoices)
            GestureDetector(
              onTap: () => setState(() => color = c),
              child: Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: Color(c),
                  shape: BoxShape.circle,
                  border: color == c
                      ? Border.all(color: C.text, width: 3)
                      : null,
                ),
              ),
            ),
        ],
      ),
      const SizedBox(height: 20),
      AppButton('Enregistrer', icon: Icons.check_rounded, onTap: save),
      if (widget.id != null) ...[
        const SizedBox(height: 10),
        AppButton(
          'Supprimer / archiver',
          icon: Icons.delete_outline_rounded,
          kind: BtnKind.danger,
          onTap: () {
            deleteWithUndo(
              context,
              'Compte supprimé (archivé s\'il avait des opérations)',
              () => store.deleteAccount(widget.id!),
            );
            Navigator.of(context).popUntil((r) => r.isFirst);
          },
        ),
      ],
    ],
  );
}

/// Réajuster le solde d'un compte : on tape l'argent réel, l'app note l'écart.
class AdjustBalanceScreen extends StatefulWidget {
  final int id;
  const AdjustBalanceScreen({super.key, required this.id});
  @override
  State<AdjustBalanceScreen> createState() => _AdjustBalanceScreenState();
}

class _AdjustBalanceScreenState extends State<AdjustBalanceScreen> {
  final real = TextEditingController(),
      date = TextEditingController(text: today()),
      note = TextEditingController();
  int? catId; // null = « Je ne sais pas »

  /// Suggestions : (texte du bouton, nom de la catégorie)
  static const guesses = [
    ('Nourriture', 'Alimentation'),
    ('Transport', 'Transport'),
    ('Recharge', 'Recharge & téléphone'),
    ('Don / cadeau', 'Dons & donations'),
    ('Autre', 'Divers'),
  ];

  void save(Account a) {
    final v = parseAmount(real.text);
    if (real.text.trim().isEmpty || v == null) {
      return toast(context, "Tape l'argent que tu as vraiment.");
    }
    final t = store.adjustBalance(
      a,
      v,
      categoryId: catId,
      date: date.text.isEmpty ? null : date.text,
      note: note.text,
    );
    if (t == null) {
      toast(context, "Pas d'écart : le solde est déjà juste 👍");
    } else {
      savedToast(context, 'Solde corrigé à ${num0(v)} ✅');
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final a = store.account(widget.id);
    if (a == null) return const SubPage(title: '', children: []);
    final appBal = store.balance(
      a,
      until: date.text.isEmpty ? null : date.text,
    );
    final v = real.text.trim().isEmpty ? null : parseAmount(real.text);
    final diff = v == null ? null : v - appBal;
    final minus = diff != null && diff < 0;
    final col = diff == null || diff == 0
        ? C.transfer
        : (minus ? C.expense : C.income);
    final soft = diff == null || diff == 0
        ? C.transferSoft
        : (minus ? C.expenseSoft : C.incomeSoft);
    final cats = [
      for (final g in guesses)
        if (store.cats(income: false).where((c) => c.name == g.$2).firstOrNull
            case final c?)
          (g.$1, c.id),
    ];
    return SubPage(
      title: 'Réajuster ${a.name}',
      children: [
        AppCard(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "L'app dit que tu as",
                      style: ts(12, w: w6, c: C.muted),
                    ),
                    const SizedBox(height: 2),
                    Text(money(appBal), style: ts(20, w: w8, ls: -0.4)),
                  ],
                ),
              ),
              AccountBadge(a),
            ],
          ),
        ),
        const SizedBox(height: 14),
        AppField(
          label: 'Combien tu as vraiment en ce moment ?',
          controller: real,
          hint: 'Ex : 15.000',
          keyboard: TextInputType.number,
          onChanged: (_) => setState(() {}),
          style: ts(20, w: w8),
        ),
        if (diff != null)
          Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: soft,
              borderRadius: BorderRadius.circular(cardRadius),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        diff == 0 ? 'Pas d\'écart' : 'Écart trouvé',
                        style: ts(13, w: w7, c: col),
                      ),
                    ),
                    Text(
                      diff == 0
                          ? '0'
                          : '${minus ? '−' : '+'}${num0(diff.abs())}',
                      style: ts(20, w: w8, c: col),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  diff == 0
                      ? 'Le solde de l\'app est déjà juste.'
                      : minus
                      ? '${num0(-diff)} $currency sont sortis sans être notés. '
                            "L'app va l'enregistrer comme une dépense « Écart »."
                      : 'Tu as ${num0(diff)} $currency de plus que prévu. '
                            "L'app va l'enregistrer comme une entrée « Écart ».",
                  style: ts(12, w: w6, c: C.muted),
                ),
              ],
            ),
          ),
        if (diff == null || minus) ...[
          const FieldLabel("C'était quoi, à peu près ? (pas obligé)"),
          Wrap(
            children: [
              AppChip(
                'Je ne sais pas',
                selected: catId == null,
                onTap: () => setState(() => catId = null),
              ),
              for (final c in cats)
                AppChip(
                  c.$1,
                  selected: catId == c.$2,
                  onTap: () => setState(() => catId = c.$2),
                ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        DateField(
          label: 'Date',
          controller: date,
          onChanged: () => setState(() {}),
        ),
        AppField(
          label: 'Note (pas obligé)',
          controller: note,
          hint: 'Ex : sûrement les petites dépenses de la semaine',
        ),
        const SizedBox(height: 8),
        AppButton(
          v == null ? 'Corriger le solde' : 'Corriger le solde à ${num0(v)}',
          icon: Icons.check_rounded,
          onTap: () => save(a),
        ),
      ],
    );
  }
}
