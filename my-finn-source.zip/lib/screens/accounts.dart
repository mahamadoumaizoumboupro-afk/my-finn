import 'package:flutter/material.dart';
import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart';

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});
  @override
  Widget build(BuildContext context) => Watch((context) {
        final accs = store.activeAccounts;
        final inT = accs.where((a) => a.includeInTotal).toList();
        final outT = accs.where((a) => !a.includeInTotal).toList();
        final avail = store.available();
        Widget list(List<Account> l) => AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Column(children: [
                for (var i = 0; i < l.length; i++)
                  InkWell(
                    onTap: () => push(context, AccountDetailScreen(id: l[i].id)),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(border: i == l.length - 1 ? null : Border(bottom: BorderSide(color: C.border))),
                      child: Row(children: [
                        IconBubble(accountIcon(l[i].type), Color(l[i].color)), const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(l[i].name, style: ts(15, w: w7)),
                          Text(accountTypeLabel(l[i].type), style: ts(12, c: C.muted)),
                        ])),
                        MoneyText(store.balance(l[i]), size: 15),
                        Icon(Icons.chevron_right_rounded, color: C.faint),
                      ]),
                    ),
                  ),
              ]),
            );
        return SubPage(
          title: 'Mes comptes',
          fab: GradientFab(onTap: () => push(context, const AccountFormScreen())),
          children: [
            GradientBox(
              gradient: inkGradient, glow: false,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Patrimoine total', style: ts(14, w: w6, c: Colors.white70)),
                FittedBox(child: Text(money(avail + store.owedToMe() - store.iOwe()), style: ts(30, w: w8, c: Colors.white, ls: -0.8))),
                Container(height: 1, color: Colors.white12, margin: const EdgeInsets.symmetric(vertical: 12)),
                for (final r in [('Disponible', avail), ('Créances (on me doit)', store.owedToMe()), ('Dettes (je dois)', -store.iOwe())])
                  Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [
                    Expanded(child: Text(r.$1, style: ts(13, c: Colors.white70))),
                    Text(money(r.$2), style: ts(13, w: w7, c: Colors.white)),
                  ])),
              ]),
            ),
            const SectionTitle('Comptes et cash'),
            list(inT),
            if (outT.isNotEmpty) ...[const SectionTitle('Hors disponible'), list(outT)],
          ],
        );
      });
}

class AccountDetailScreen extends StatefulWidget {
  final int id;
  const AccountDetailScreen({super.key, required this.id});
  @override
  State<AccountDetailScreen> createState() => _AccountDetailScreenState();
}

class _AccountDetailScreenState extends State<AccountDetailScreen> {
  String month = currentMonth();
  @override
  Widget build(BuildContext context) => Watch((context) {
        final a = store.account(widget.id);
        if (a == null) return const SubPage(title: '', children: []);
        final txs = store.transactions(accountId: a.id, month: month);
        return SubPage(
          title: a.name,
          actions: [RoundIconButton(Icons.edit_outlined, onTap: () => push(context, AccountFormScreen(id: a.id)))],
          children: [
            AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                IconBubble(accountIcon(a.type), Color(a.color), size: 48), const SizedBox(width: 12),
                Expanded(child: Text('Solde actuel', style: ts(14, w: w6, c: C.muted))),
              ]),
              const SizedBox(height: 8),
              Text(money(store.balance(a)), style: ts(30, w: w8, ls: -0.8)),
              Text('Solde de départ : ${money(a.initialBalance)}', style: ts(12, c: C.muted)),
              Text('Les prêts et remboursements liés à ce compte sont inclus.', style: ts(12, c: C.muted)),
            ])),
            MonthSwitcher(month: month, onChanged: (m) => setState(() => month = m)),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: txs.isEmpty
                  ? const EmptyState('Aucune opération sur ce compte ce mois-ci.')
                  : Column(children: [
                      for (var i = 0; i < txs.length; i++)
                        TxTile(txs[i], last: i == txs.length - 1, onTap: () => push(context, TxFormScreen(id: txs[i].id))),
                    ]),
            ),
          ],
        );
      });
}

class AccountFormScreen extends StatefulWidget {
  final int? id;
  const AccountFormScreen({super.key, this.id});
  @override
  State<AccountFormScreen> createState() => _AccountFormScreenState();
}

class _AccountFormScreenState extends State<AccountFormScreen> {
  final name = TextEditingController(), initial = TextEditingController(text: '0');
  String type = 'mobile';
  bool include = true;
  int color = paletteChoices.first;

  @override
  void initState() {
    super.initState();
    final a = widget.id == null ? null : store.account(widget.id);
    if (a != null) {
      name.text = a.name; type = a.type; initial.text = num0(a.initialBalance); include = a.includeInTotal; color = a.color;
    }
  }

  void save() {
    if (name.text.trim().isEmpty) return toast(context, 'Donne un nom au compte.');
    final v = parseAmount(initial.text.isEmpty ? '0' : initial.text);
    if (v == null) return toast(context, 'Solde de départ invalide.');
    final a = widget.id == null ? Account(id: 0, name: '') : store.account(widget.id)!;
    a..name = name.text.trim()..type = type..initialBalance = v..includeInTotal = include..color = color;
    store.saveAccount(a);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => SubPage(title: widget.id == null ? 'Nouveau compte' : 'Modifier le compte', children: [
        AppField(label: 'Nom', controller: name, hint: 'Ex : Compte Coris, Nita, Cash'),
        const FieldLabel('Type'),
        Wrap(children: [
          for (final t in accountTypes) AppChip(t.$2, icon: t.$3, selected: type == t.$1, onTap: () => setState(() => type = t.$1)),
        ]),
        const SizedBox(height: 8),
        AppField(label: 'Solde de départ (avant la première opération notée)', controller: initial, keyboard: TextInputType.number),
        AppCard(child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Compter dans le disponible', style: ts(14, w: w7)),
            Text("Désactive pour les bons d'essence, tickets, etc.", style: ts(12, c: C.muted)),
          ])),
          Switch(value: include, onChanged: (v) => setState(() => include = v)),
        ])),
        const FieldLabel('Couleur'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final c in paletteChoices)
            GestureDetector(
              onTap: () => setState(() => color = c),
              child: Container(width: 34, height: 34, decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle,
                  border: color == c ? Border.all(color: C.text, width: 3) : null)),
            ),
        ]),
        const SizedBox(height: 20),
        AppButton('Enregistrer', icon: Icons.check_rounded, onTap: save),
        if (widget.id != null) ...[
          const SizedBox(height: 10),
          AppButton('Supprimer / archiver', icon: Icons.delete_outline_rounded, kind: BtnKind.danger, onTap: () async {
            if (await confirmDialog(context, 'Supprimer le compte', "S'il a déjà des opérations, il sera seulement archivé.", danger: true)) {
              store.deleteAccount(widget.id!);
              if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            }
          }),
        ],
      ]);
}
