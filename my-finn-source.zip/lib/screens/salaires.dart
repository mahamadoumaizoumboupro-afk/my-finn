import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'tx_form.dart' show ThousandsFormatter, TxFormScreen;

String _de(String month) {
  final n = monthLabel(month).split(' ').first.toLowerCase();
  return RegExp('^[aeiouéèêâô]').hasMatch(n) ? "d'$n" : 'de $n';
}

/// « Salaire reçu » : tout est rempli, on vérifie le mois et la date.
Future<bool> salarySheet(
  BuildContext context,
  SalaryPlan p, {
  String? month,
}) async {
  var saved = false;
  final gross = TextEditingController(text: num0(p.net + p.tax));
  final tax = TextEditingController(text: num0(p.tax));
  final date = TextEditingController(text: today());
  int? acc = p.accountId == 0 ? null : p.accountId;
  final cur = currentMonth();
  var forMonth = month ?? shiftMonth(cur, p.offset);
  final accs = AccountPicker.byUsage(
    store.activeAccounts.where((a) => a.includeInTotal).toList(),
  );
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: C.sheet,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) {
        final g = parseAmount(gross.text) ?? 0;
        final tx = parseAmount(tax.text) ?? 0;
        final prev = shiftMonth(cur, -1);
        final other = forMonth != cur && forMonth != prev;
        Widget field(String label, TextEditingController c, Color? col) =>
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FieldLabel(label),
                  TextField(
                    controller: c,
                    keyboardType: TextInputType.number,
                    inputFormatters: [ThousandsFormatter()],
                    onChanged: (_) => set(() {}),
                    style: ts(18, w: w8, c: col),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: C.text.withValues(alpha: 0.07),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ],
              ),
            );
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: C.border,
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text('${p.source} reçu', style: ts(19, w: w8)),
                  Text(
                    'Tout est déjà rempli, vérifie et valide',
                    style: ts(12, c: C.muted),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      field('Brut', gross, null),
                      const SizedBox(width: 10),
                      field('Taxe retenue', tax, C.expense),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: C.income.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Net reçu',
                            style: ts(14, w: w8, c: C.income),
                          ),
                        ),
                        Text(
                          num0(g - tx),
                          style: ts(14, w: w8, c: C.income),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  const FieldLabel('Arrivé sur'),
                  AccountPicker(
                    accounts: accs,
                    selected: acc,
                    onChanged: (id) => set(() => acc = id),
                  ),
                  const SizedBox(height: 8),
                  const FieldLabel('Salaire de quel mois ?'),
                  Wrap(
                    children: [
                      AppChip(
                        monthLabel(cur).split(' ').first,
                        selected: forMonth == cur,
                        onTap: () => set(() => forMonth = cur),
                      ),
                      AppChip(
                        monthLabel(prev).split(' ').first,
                        selected: forMonth == prev,
                        onTap: () => set(() => forMonth = prev),
                      ),
                      AppChip(
                        other ? monthLabel(forMonth) : 'Autre…',
                        icon: Icons.calendar_month_rounded,
                        selected: other,
                        onTap: () async {
                          final m = await pickMonth(ctx, forMonth);
                          if (m != null) set(() => forMonth = m);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  DateField(label: 'Date de réception', controller: date),
                  const SizedBox(height: 8),
                  AppButton(
                    'Valider',
                    kind: BtnKind.success,
                    onTap: () {
                      if (g <= 0 || tx < 0 || tx >= g || acc == null) {
                        return toast(ctx, 'Vérifie le brut et la taxe.');
                      }
                      store.addSalary(
                        p,
                        gross: g,
                        tax: tx,
                        accountId: acc!,
                        month: forMonth,
                        date: date.text.isEmpty ? today() : date.text,
                      );
                      saved = true;
                      Navigator.pop(ctx);
                      savedToast(
                        context,
                        '${p.source} ${_de(forMonth)} noté ✅',
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );
  return saved;
}

Widget _check() => Container(
  width: 36,
  height: 36,
  decoration: BoxDecoration(color: C.income, shape: BoxShape.circle),
  child: const Icon(Icons.check_rounded, color: Color(0xFF04231A), size: 22),
);

Widget _bubble(bool on) =>
    IconBubble(Icons.work_rounded, on ? C.income : C.muted, size: 36);

Widget _button(String label, VoidCallback onTap) => GestureDetector(
  onTap: onTap,
  child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(
      color: C.income,
      borderRadius: BorderRadius.circular(10),
    ),
    child: Text(
      label,
      style: ts(13, w: w8, c: const Color(0xFF04231A)),
    ),
  ),
);

Widget _row(
  Widget lead,
  String title,
  List<String> subs,
  Widget trail, {
  bool last = false,
  VoidCallback? onTap,
}) => InkWell(
  onTap: onTap,
  child: Container(
    padding: const EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(
      border: last ? null : Border(bottom: BorderSide(color: C.border)),
    ),
    child: Row(
      children: [
        lead,
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: ts(14, w: w7)),
              for (final s in subs)
                Text(
                  s,
                  style: ts(12, c: C.muted),
                  overflow: TextOverflow.ellipsis,
                ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        trail,
      ],
    ),
  ),
);

/// Accueil : les salaires qui arrivent ce mois-ci, avec « Reçu ».
class SalaryHomeCard extends StatelessWidget {
  const SalaryHomeCard({super.key});
  @override
  Widget build(BuildContext context) {
    final cur = currentMonth();
    final plans = store.salaryPlans();
    final items = [
      for (final p in plans)
        (
          p,
          shiftMonth(cur, p.offset),
          store.salaryFor(p.source, shiftMonth(cur, p.offset)),
        ),
    ];
    if (items.isEmpty) return const SizedBox.shrink();
    final allIn = items.every((e) => e.$3 != null);
    final name = monthLabel(cur).split(' ').first.toLowerCase();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mes salaires de $name', style: ts(15, w: w8)),
            Text(
              allIn
                  ? 'Tout est reçu, bravo ✓'
                  : "Touche « Reçu » le jour où l'argent arrive",
              style: ts(12, c: allIn ? C.income : C.muted),
            ),
            const SizedBox(height: 4),
            for (var i = 0; i < items.length; i++)
              () {
                final (p, m, t) = items[i];
                final last = i == items.length - 1;
                final de = m == cur ? '' : '${_de(m)} · ';
                if (t != null) {
                  return _row(
                    _check(),
                    p.source,
                    ['$de${'reçu le ${dayShort(t.date)}'}'],
                    Text(
                      num0(t.amount),
                      style: ts(14, w: w8, c: C.income),
                    ),
                    last: last,
                  );
                }
                return _row(
                  _bubble(true),
                  p.source,
                  ['$de${num0(p.net)} net · d\'habitude le ${p.day}'],
                  _button('Reçu', () => salarySheet(context, p, month: m)),
                  last: last,
                );
              }(),
          ],
        ),
      ),
    );
  }
}

/// Bilan : les salaires du mois, avec la date d'arrivée, le brut et la taxe.
class SalaryBilanCard extends StatelessWidget {
  final String month;
  const SalaryBilanCard(this.month, {super.key});
  @override
  Widget build(BuildContext context) {
    final plans = store.salaryPlans();
    if (plans.isEmpty) return const SizedBox.shrink();
    final items = [
      for (final p in plans) (p, store.salaryFor(p.source, month)),
    ];
    final first = store.txs
        .where(store.isSalary)
        .map(store.salaryMonth)
        .fold<String?>(null, (a, b) => a == null || b.compareTo(a) < 0 ? b : a);
    if (items.every((e) => e.$2 == null) &&
        (first == null || month.compareTo(first) < 0)) {
      return const SizedBox.shrink();
    }
    final net = items.fold(0, (x, e) => x + (e.$2?.amount ?? 0));
    final tax = items.fold(0, (x, e) => x + (e.$2?.tax ?? 0));
    final name = monthLabel(month).split(' ').first.toLowerCase();
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('Salaires ${_de(month)}', style: ts(15, w: w8)),
              ),
              Text(
                num0(net),
                style: ts(15, w: w8, c: C.income),
              ),
            ],
          ),
          Text(
            'net reçu${tax > 0 ? ' · ${num0(tax)} de taxe retenue' : ''}',
            style: ts(12, c: C.muted),
          ),
          const SizedBox(height: 4),
          for (var i = 0; i < items.length; i++)
            () {
              final (p, t) = items[i];
              final last = i == items.length - 1;
              if (t == null) {
                final when = shiftMonth(month, -p.offset);
                return _row(
                  _bubble(false),
                  p.source,
                  ['Pas encore reçu · d\'habitude le ${p.day} ${shortMonth(when)}'],
                  month.compareTo(currentMonth()) <= 0
                      ? _button(
                          'Reçu',
                          () => salarySheet(context, p, month: month),
                        )
                      : Text(
                          '—',
                          style: ts(14, w: w8, c: C.muted),
                        ),
                  last: last,
                );
              }
              final acc = store.account(t.accountId)?.name ?? '';
              return _row(
                _bubble(true),
                p.source,
                [
                  'Reçu le ${dayShort(t.date)}${t.date.substring(0, 7) == month ? '' : ' ${t.date.substring(0, 4)}'} · sur $acc',
                  if (t.tax > 0)
                    'Brut ${num0(t.amount + t.tax)} · taxe ${num0(t.tax)}',
                ],
                Text(
                  num0(t.amount),
                  style: ts(14, w: w8, c: C.income),
                ),
                last: last,
                onTap: () => push(context, TxFormScreen(id: t.id)),
              );
            }(),
          if (items.every((e) => e.$2 == null))
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(
                'Aucun salaire $name noté pour l\'instant.',
                style: ts(12, c: C.muted),
              ),
            ),
        ],
      ),
    );
  }
}
