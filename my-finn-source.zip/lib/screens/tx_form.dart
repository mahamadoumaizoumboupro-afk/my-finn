import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'debts.dart';

/// Formate le montant pendant la saisie : 1479050 -> 1.479.050
class ThousandsFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    final t = digits.isEmpty ? '' : num0(int.parse(digits));
    return TextEditingValue(
      text: t,
      selection: TextSelection.collapsed(offset: t.length),
    );
  }
}

class TxFormScreen extends StatefulWidget {
  final int? id;
  final TxType type;
  const TxFormScreen({super.key, this.id, this.type = TxType.expense});
  @override
  State<TxFormScreen> createState() => _TxFormScreenState();
}

class _TxFormScreenState extends State<TxFormScreen> {
  late TxType type = widget.type;
  final amount = TextEditingController(),
      fee = TextEditingController(),
      tax = TextEditingController(),
      label = TextEditingController();
  final note = TextEditingController(),
      date = TextEditingController(text: today()),
      person = TextEditingController();
  int? accountId, toAccountId, categoryId;
  bool categoryTouched = false, repeat = false;

  /// « Pour quel mois ? » : null = le mois de la date.
  String? forMonth;
  Beneficiary beneficiary = Beneficiary.moi;
  Nature nature = Nature.pour;
  Timer? _guess;

  @override
  void initState() {
    super.initState();
    final t = widget.id == null ? null : store.tx(widget.id!);
    if (t != null) {
      type = t.type;
      amount.text = num0(t.amount);
      fee.text = t.fee > 0 ? num0(t.fee) : '';
      tax.text = t.tax > 0 ? num0(t.tax) : '';
      label.text = t.label;
      note.text = t.note ?? '';
      date.text = t.date;
      accountId = t.accountId;
      toAccountId = t.toAccountId;
      categoryId = t.categoryId;
      categoryTouched = true;
      beneficiary = t.beneficiary;
      person.text = t.person ?? '';
      nature = t.nature;
      forMonth = t.shifted ? t.forMonth : null;
    } else {
      final accs = store.activeAccounts;
      accountId =
          accs.where((a) => a.type == 'cash').firstOrNull?.id ??
          accs.firstOrNull?.id;
    }
  }

  void onLabel(String v) {
    if (categoryTouched || type == TxType.transfer) return;
    _guess?.cancel();
    _guess = Timer(const Duration(milliseconds: 250), () {
      final c = store.guessCategory(type, v);
      if (c != null && mounted) setState(() => categoryId = c);
    });
  }

  void applyTemplate(Tx t) => setState(() {
    amount.text = num0(t.amount);
    label.text = t.label;
    categoryId = t.categoryId;
    categoryTouched = true;
    accountId = t.accountId;
    beneficiary = t.beneficiary;
    person.text = t.person ?? '';
    nature = t.nature;
  });

  /// Choix du mois pour le Bilan (ex. salaire d'octobre reçu en novembre).
  List<Widget> _monthChoice() {
    final dm = date.text.substring(0, 7);
    final prev = shiftMonth(dm, -1);
    final chosen = forMonth ?? dm;
    final other = chosen != dm && chosen != prev;
    final accName = store.account(accountId)?.name ?? 'ton compte';
    return [
      const FieldLabel('Pour quel mois ?'),
      Wrap(
        children: [
          AppChip(
            '${monthLabel(dm).split(' ').first} (mois de la date)',
            selected: chosen == dm,
            onTap: () => setState(() => forMonth = null),
          ),
          AppChip(
            monthLabel(prev),
            selected: chosen == prev,
            onTap: () => setState(() => forMonth = prev),
          ),
          AppChip(
            other ? monthLabel(chosen) : 'Autre mois…',
            icon: Icons.calendar_month_rounded,
            selected: other,
            onTap: () async {
              final m = await pickMonth(
                context,
                chosen,
                start: shiftMonth(dm, 3),
              );
              if (m != null && mounted) {
                setState(() => forMonth = m == dm ? null : m);
              }
            },
          ),
        ],
      ),
      if (chosen != dm)
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: C.primarySoft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text.rich(
            TextSpan(
              style: ts(12, w: w6, h: 1.5),
              children: [
                TextSpan(text: 'Ton solde $accName bouge le '),
                TextSpan(
                  text: dayShort(date.text),
                  style: ts(12, w: w8),
                ),
                TextSpan(
                  text:
                      '${dayShort(date.text).endsWith('.') ? '' : '.'}\nDans le Bilan, cette opération compte pour ',
                ),
                TextSpan(
                  text: monthLabel(chosen).split(' ').first.toLowerCase(),
                  style: ts(12, w: w8),
                ),
                const TextSpan(text: '.'),
              ],
            ),
          ),
        ),
    ];
  }

  void save() {
    final v = parseAmount(amount.text);
    if (v == null || v <= 0) return toast(context, 'Saisis un montant valide.');
    if (accountId == null) return toast(context, 'Choisis un compte.');
    if (!isValidISO(date.text)) return toast(context, 'Choisis une date.');
    if (type == TxType.transfer &&
        (toAccountId == null || toAccountId == accountId)) {
      return toast(context, 'Choisis un compte de destination différent.');
    }
    final forPerson =
        type == TxType.expense && beneficiary == Beneficiary.personne;
    if (forPerson && person.text.trim().isEmpty)
      return toast(context, 'Indique le nom de la personne.');
    final t = widget.id == null
        ? Tx(id: 0, type: type, amount: 0, accountId: 0, date: '')
        : store.tx(widget.id!)!;
    t
      ..type = type
      ..amount = v
      ..fee = type == TxType.transfer ? (parseAmount(fee.text) ?? 0) : 0
      ..tax = type == TxType.income ? (parseAmount(tax.text) ?? 0) : 0
      ..accountId = accountId!
      ..toAccountId = type == TxType.transfer ? toAccountId : null
      ..categoryId = type == TxType.transfer ? null : categoryId
      ..beneficiary = type == TxType.expense ? beneficiary : Beneficiary.moi
      ..person = forPerson ? person.text.trim() : null
      ..nature = forPerson ? nature : Nature.pour
      ..label = label.text.trim()
      ..note = note.text.trim().isEmpty ? null : note.text.trim()
      ..date = date.text
      ..forMonth =
          type == TxType.transfer || forMonth == date.text.substring(0, 7)
          ? null
          : forMonth;
    store.saveTx(t);
    if (repeat && widget.id == null && type != TxType.transfer) {
      store.addRecurring(
        Recurring(
          id: 0,
          type: type,
          amount: v,
          accountId: accountId!,
          categoryId: categoryId,
          label: t.label,
          day: int.parse(date.text.substring(8, 10)),
          beneficiary: t.beneficiary,
          person: t.person,
          nature: t.nature,
          lastMonth: date.text.substring(0, 7),
        ),
      );
    }
    savedToast(
      context,
      widget.id == null
          ? 'Opération enregistrée ✅'
          : 'Modification enregistrée ✅',
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final tColor = switch (type) {
      TxType.income => C.income,
      TxType.expense => C.expense,
      _ => C.transfer,
    };
    final tSoft = switch (type) {
      TxType.income => C.incomeSoft,
      TxType.expense => C.expenseSoft,
      _ => C.transferSoft,
    };
    final templates = widget.id == null && type != TxType.transfer
        ? store.templates(type)
        : <Template>[];
    final cats = store.cats(income: type == TxType.income);
    final accs = AccountPicker.byUsage(store.activeAccounts);
    final people = store
        .people()
        .where(
          (p) =>
              person.text.isEmpty ||
              p.toLowerCase().contains(person.text.toLowerCase()),
        )
        .take(8);

    return SubPage(
      title: widget.id == null ? 'Nouvelle opération' : 'Modifier',
      children: [
        Segmented<TxType>(
          value: type,
          onChanged: (v) => setState(() {
            type = v;
            categoryId = null;
            categoryTouched = false;
          }),
          options: [
            (TxType.expense, 'Dépense', C.expense),
            (TxType.income, 'Entrée', C.income),
            (TxType.transfer, 'Transfert', C.transfer),
          ],
        ),
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                tSoft.withValues(alpha: 0.85),
                Color.alphaBlend(tColor.withValues(alpha: 0.10), glassFill),
              ],
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: glassBorder, width: 1.2),
          ),
          child: Column(
            children: [
              Text(
                'Montant',
                style: ts(13, w: w7, c: tColor),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IntrinsicWidth(
                    child: TextField(
                      controller: amount,
                      autofocus: widget.id == null,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      inputFormatters: [ThousandsFormatter()],
                      style: ts(42, w: w8, c: tColor),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: '0',
                        hintStyle: ts(
                          42,
                          w: w8,
                          c: tColor.withValues(alpha: 0.35),
                        ),
                        isDense: true,
                        constraints: const BoxConstraints(minWidth: 60),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    currency,
                    style: ts(18, w: w8, c: tColor),
                  ),
                ],
              ),
            ],
          ),
        ),
        if (templates.isNotEmpty) ...[
          const FieldLabel('Saisie rapide'),
          SizedBox(
            height:
                MediaQuery.textScalerOf(context).scale(44) +
                22, // s'adapte à la taille du texte
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final tp in templates)
                  GestureDetector(
                    onTap: () => applyTemplate(tp.tx),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8, bottom: 6),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: glassFill,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: glassBorder, width: 1.2),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            iconFor(
                              store.category(tp.tx.categoryId)?.icon ?? 'bolt',
                            ),
                            size: 17,
                            color: Color(
                              store.category(tp.tx.categoryId)?.color ??
                                  C.primary.toARGB32(),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(tp.tx.label, style: ts(13, w: w7)),
                              Text(
                                num0(tp.tx.amount),
                                style: ts(11, w: w7, c: C.muted),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
        ],
        AppField(
          label: 'Libellé',
          controller: label,
          onChanged: onLabel,
          hint: type == TxType.income
              ? 'Ex : Salaire BCR'
              : type == TxType.transfer
              ? 'Ex : Retrait Nita vers cash'
              : 'Ex : Pain + brochette',
        ),
        FieldLabel(type == TxType.transfer ? 'Depuis' : 'Compte'),
        AccountPicker(
          accounts: accs,
          selected: accountId,
          onChanged: (id) => setState(() {
            accountId = id;
            if (toAccountId == id) toAccountId = null;
          }),
        ),
        if (type == TxType.transfer) ...[
          const FieldLabel('Vers'),
          AccountPicker(
            accounts: accs.where((a) => a.id != accountId).toList(),
            selected: toAccountId,
            onChanged: (id) => setState(() => toAccountId = id),
          ),
          AppField(
            label: 'Frais de retrait / transfert',
            controller: fee,
            keyboard: TextInputType.number,
            hint: '0',
          ),
        ],
        if (type == TxType.income) ...[
          AppField(
            label: 'Taxe déjà retirée (optionnel)',
            controller: tax,
            keyboard: TextInputType.number,
            hint: 'Ex : 25.250',
            onChanged: (_) => setState(() {}),
          ),
          if ((parseAmount(tax.text) ?? 0) > 0 &&
              (parseAmount(amount.text) ?? 0) > 0)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                'Brut ${money(parseAmount(amount.text)! + parseAmount(tax.text)!)} − taxe ${money(parseAmount(tax.text)!)} '
                '= reçu ${money(parseAmount(amount.text)!)}',
                style: ts(12, c: C.muted, w: w6),
              ),
            ),
        ],
        if (type != TxType.transfer) ...[
          const FieldLabel('Catégorie'),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 0.95,
            children: [
              for (final c in cats)
                GestureDetector(
                  onTap: () => setState(() {
                    categoryId = c.id;
                    categoryTouched = true;
                  }),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      gradient: categoryId == c.id
                          ? fillGradient(Color(c.color))
                          : null,
                      color: categoryId == c.id ? null : glassFill,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: categoryId == c.id
                            ? Colors.white.withValues(alpha: 0.4)
                            : glassBorder,
                      ),
                      boxShadow: categoryId == c.id
                          ? [
                              BoxShadow(
                                color: Color(c.color).withValues(alpha: 0.4),
                                blurRadius: 12,
                                offset: const Offset(0, 5),
                              ),
                            ]
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          iconFor(c.icon),
                          size: 21,
                          color: categoryId == c.id
                              ? Colors.white
                              : Color(c.color),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          c.name,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: ts(
                            10,
                            w: w7,
                            c: categoryId == c.id ? Colors.white : C.text,
                            h: 1.15,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
        ],
        if (type == TxType.expense) ...[
          const FieldLabel('Pour qui ?'),
          Wrap(
            children: [
              AppChip(
                'Moi',
                icon: Icons.person_rounded,
                selected: beneficiary == Beneficiary.moi,
                onTap: () => setState(() => beneficiary = Beneficiary.moi),
              ),
              AppChip(
                'Chez moi',
                icon: Icons.home_rounded,
                color: C.accent,
                selected: beneficiary == Beneficiary.maison,
                onTap: () => setState(() => beneficiary = Beneficiary.maison),
              ),
              AppChip(
                'Une personne',
                icon: Icons.people_rounded,
                color: C.warn,
                selected: beneficiary == Beneficiary.personne,
                onTap: () => setState(() => beneficiary = Beneficiary.personne),
              ),
            ],
          ),
          if (beneficiary == Beneficiary.personne)
            Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: C.warnSoft,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppField(
                    label: 'Nom de la personne',
                    controller: person,
                    hint: 'Ex : Nado',
                    onChanged: (_) => setState(() {}),
                  ),
                  if (people.isNotEmpty)
                    Wrap(
                      children: [
                        for (final p in people)
                          AppChip(
                            p,
                            color: C.muted,
                            onTap: () => setState(() => person.text = p),
                          ),
                      ],
                    ),
                  const FieldLabel('Nature'),
                  Wrap(
                    children: [
                      AppChip(
                        'Dépense pour elle/lui',
                        color: C.transfer,
                        selected: nature == Nature.pour,
                        onTap: () => setState(() => nature = Nature.pour),
                      ),
                      AppChip(
                        'Donation',
                        icon: Icons.favorite_rounded,
                        color: C.expense,
                        selected: nature == Nature.donation,
                        onTap: () => setState(() => nature = Nature.donation),
                      ),
                      AppChip(
                        'Cadeau',
                        icon: Icons.card_giftcard_rounded,
                        color: C.warn,
                        selected: nature == Nature.cadeau,
                        onTap: () => setState(() => nature = Nature.cadeau),
                      ),
                      AppChip(
                        "C'est un prêt",
                        icon: Icons.arrow_forward_rounded,
                        color: C.primary,
                        onTap: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const DebtFormScreen(
                              direction: DebtDirection.lent,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
        ],
        DateField(
          label: type == TxType.income ? "Date où l'argent est arrivé" : 'Date',
          controller: date,
          onChanged: () => setState(() {}),
        ),
        if (type != TxType.transfer && isValidISO(date.text)) ..._monthChoice(),
        AppField(
          label: 'Note (optionnel)',
          controller: note,
          hint: 'Détails…',
          maxLines: 3,
        ),
        if (widget.id == null && type != TxType.transfer)
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: glassFill,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: glassBorder, width: 1.2),
            ),
            child: Row(
              children: [
                Icon(Icons.autorenew_rounded, color: C.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Répéter chaque mois', style: ts(14, w: w7)),
                      Text(
                        'Salaire, tontine, abonnement… ajoutés automatiquement le '
                        '${date.text.length == 10 ? int.tryParse(date.text.substring(8)) ?? 1 : 1} du mois',
                        style: ts(12, c: C.muted),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: repeat,
                  onChanged: (v) => setState(() => repeat = v),
                ),
              ],
            ),
          ),
        AppButton('Enregistrer', icon: Icons.check_rounded, onTap: save),
        if (widget.id != null) ...[
          const SizedBox(height: 10),
          AppButton(
            'Supprimer',
            icon: Icons.delete_outline_rounded,
            kind: BtnKind.danger,
            onTap: () {
              deleteWithUndo(
                context,
                'Opération supprimée',
                () => store.deleteTx(widget.id!),
              );
              Navigator.pop(context);
            },
          ),
        ],
      ],
    );
  }
}
