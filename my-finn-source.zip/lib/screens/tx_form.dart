import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'debts.dart';

/// Formate le montant pendant la saisie : 1479050 -> 1.479.050
class ThousandsFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    final t = digits.isEmpty ? '' : num0(int.parse(digits));
    return TextEditingValue(text: t, selection: TextSelection.collapsed(offset: t.length));
  }
}

class TxFormScreen extends StatefulWidget {
  final int? id;
  final TxType type;
  const TxFormScreen({super.key, this.id, this.type = TxType.expense});
  @override
  State<TxFormScreen> createState() => _TxFormScreenState();
}

class _TxFormScreenState extends State<TxFormScreen> {
  late TxType type = widget.type;
  final amount = TextEditingController(), fee = TextEditingController(), label = TextEditingController();
  final note = TextEditingController(), date = TextEditingController(text: today()), person = TextEditingController();
  int? accountId, toAccountId, categoryId;
  bool categoryTouched = false, repeat = false;
  Beneficiary beneficiary = Beneficiary.moi;
  Nature nature = Nature.pour;
  Timer? _guess;

  @override
  void initState() {
    super.initState();
    final t = widget.id == null ? null : store.tx(widget.id!);
    if (t != null) {
      type = t.type; amount.text = num0(t.amount); fee.text = t.fee > 0 ? num0(t.fee) : ''; label.text = t.label;
      note.text = t.note ?? ''; date.text = t.date; accountId = t.accountId; toAccountId = t.toAccountId;
      categoryId = t.categoryId; categoryTouched = true; beneficiary = t.beneficiary; person.text = t.person ?? ''; nature = t.nature;
    } else {
      final accs = store.activeAccounts;
      accountId = accs.where((a) => a.type == 'cash').firstOrNull?.id ?? accs.firstOrNull?.id;
    }
  }

  void onLabel(String v) {
    if (categoryTouched || type == TxType.transfer) return;
    _guess?.cancel();
    _guess = Timer(const Duration(milliseconds: 250), () {
      final c = store.guessCategory(type, v);
      if (c != null && mounted) setState(() => categoryId = c);
    });
  }

  void applyTemplate(Tx t) => setState(() {
        amount.text = num0(t.amount); label.text = t.label; categoryId = t.categoryId; categoryTouched = true;
        accountId = t.accountId; beneficiary = t.beneficiary; person.text = t.person ?? ''; nature = t.nature;
      });

  void save() {
    final v = parseAmount(amount.text);
    if (v == null || v <= 0) return toast(context, 'Saisis un montant valide.');
    if (accountId == null) return toast(context, 'Choisis un compte.');
    if (!isValidISO(date.text)) return toast(context, 'Date : format AAAA-MM-JJ');
    if (type == TxType.transfer && (toAccountId == null || toAccountId == accountId)) {
      return toast(context, 'Choisis un compte de destination différent.');
    }
    final forPerson = type == TxType.expense && beneficiary == Beneficiary.personne;
    if (forPerson && person.text.trim().isEmpty) return toast(context, 'Indique le nom de la personne.');
    final t = widget.id == null ? Tx(id: 0, type: type, amount: 0, accountId: 0, date: '') : store.tx(widget.id!)!;
    t..type = type..amount = v..fee = type == TxType.transfer ? (parseAmount(fee.text) ?? 0) : 0..accountId = accountId!
      ..toAccountId = type == TxType.transfer ? toAccountId : null..categoryId = type == TxType.transfer ? null : categoryId
      ..beneficiary = type == TxType.expense ? beneficiary : Beneficiary.moi..person = forPerson ? person.text.trim() : null
      ..nature = forPerson ? nature : Nature.pour..label = label.text.trim()..note = note.text.trim().isEmpty ? null : note.text.trim()
      ..date = date.text;
    store.saveTx(t);
    if (repeat && widget.id == null && type != TxType.transfer) {
      store.addRecurring(Recurring(id: 0, type: type, amount: v, accountId: accountId!, categoryId: categoryId, label: t.label,
          day: int.parse(date.text.substring(8, 10)), beneficiary: t.beneficiary, person: t.person, nature: t.nature,
          lastMonth: date.text.substring(0, 7)));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final tColor = switch (type) { TxType.income => C.income, TxType.expense => C.expense, _ => C.transfer };
    final tSoft = switch (type) { TxType.income => C.incomeSoft, TxType.expense => C.expenseSoft, _ => C.transferSoft };
    final templates = widget.id == null && type != TxType.transfer ? store.templates(type) : <Template>[];
    final cats = store.cats(income: type == TxType.income);
    final accs = store.activeAccounts;
    final people = store.people().where((p) => person.text.isEmpty || p.toLowerCase().contains(person.text.toLowerCase())).take(8);

    return SubPage(title: widget.id == null ? 'Nouvelle opération' : 'Modifier', children: [
      Segmented<TxType>(value: type, onChanged: (v) => setState(() { type = v; categoryId = null; categoryTouched = false; }), options: [
        (TxType.expense, 'Dépense', C.expense), (TxType.income, 'Entrée', C.income), (TxType.transfer, 'Transfert', C.transfer),
      ]),
      Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        decoration: BoxDecoration(color: tSoft, borderRadius: BorderRadius.circular(24)),
        child: Column(children: [
          Text('Montant', style: ts(13, w: w7, c: tColor)),
          Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
            IntrinsicWidth(
              child: TextField(
                controller: amount, autofocus: widget.id == null, keyboardType: TextInputType.number, textAlign: TextAlign.center,
                inputFormatters: [ThousandsFormatter()], style: ts(42, w: w8, c: tColor),
                decoration: InputDecoration(border: InputBorder.none, hintText: '0', hintStyle: ts(42, w: w8, c: tColor.withValues(alpha: 0.35)),
                    isDense: true, constraints: const BoxConstraints(minWidth: 60)),
              ),
            ),
            const SizedBox(width: 6),
            Text(currency, style: ts(18, w: w8, c: tColor)),
          ]),
        ]),
      ),
      if (templates.isNotEmpty) ...[
        const FieldLabel('Saisie rapide'),
        SizedBox(
          height: 62,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final tp in templates)
              GestureDetector(
                onTap: () => applyTemplate(tp.tx),
                child: Container(
                  margin: const EdgeInsets.only(right: 8, bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: C.border)),
                  child: Row(children: [
                    Icon(iconFor(store.category(tp.tx.categoryId)?.icon ?? 'bolt'), size: 17,
                        color: Color(store.category(tp.tx.categoryId)?.color ?? C.primary.toARGB32())),
                    const SizedBox(width: 8),
                    Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(tp.tx.label, style: ts(13, w: w7)),
                      Text(num0(tp.tx.amount), style: ts(11, w: w7, c: C.muted)),
                    ]),
                  ]),
                ),
              ),
          ]),
        ),
        const SizedBox(height: 10),
      ],
      AppField(label: 'Libellé', controller: label, onChanged: onLabel,
          hint: type == TxType.income ? 'Ex : Salaire BCR' : type == TxType.transfer ? 'Ex : Retrait Nita vers cash' : 'Ex : Pain + brochette'),
      FieldLabel(type == TxType.transfer ? 'Depuis' : 'Compte'),
      ChipScroll(children: [
        for (final a in accs) AppChip(a.name, color: Color(a.color), selected: accountId == a.id, onTap: () => setState(() => accountId = a.id)),
      ]),
      if (type == TxType.transfer) ...[
        const FieldLabel('Vers'),
        ChipScroll(children: [
          for (final a in accs.where((a) => a.id != accountId))
            AppChip(a.name, color: Color(a.color), selected: toAccountId == a.id, onTap: () => setState(() => toAccountId = a.id)),
        ]),
        AppField(label: 'Frais de retrait / transfert', controller: fee, keyboard: TextInputType.number, hint: '0'),
      ],
      if (type != TxType.transfer) ...[
        const FieldLabel('Catégorie'),
        GridView.count(
          crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 0.95,
          children: [
            for (final c in cats)
              GestureDetector(
                onTap: () => setState(() { categoryId = c.id; categoryTouched = true; }),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(color: categoryId == c.id ? Color(c.color) : C.card, borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: categoryId == c.id ? Color(c.color) : C.border)),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(iconFor(c.icon), size: 21, color: categoryId == c.id ? Colors.white : Color(c.color)),
                    const SizedBox(height: 4),
                    Text(c.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: ts(10, w: w7, c: categoryId == c.id ? Colors.white : C.text, h: 1.15)),
                  ]),
                ),
              ),
          ],
        ),
        const SizedBox(height: 16),
      ],
      if (type == TxType.expense) ...[
        const FieldLabel('Pour qui ?'),
        Wrap(children: [
          AppChip('Moi', icon: Icons.person_rounded, selected: beneficiary == Beneficiary.moi, onTap: () => setState(() => beneficiary = Beneficiary.moi)),
          AppChip('Chez moi', icon: Icons.home_rounded, color: C.accent, selected: beneficiary == Beneficiary.maison,
              onTap: () => setState(() => beneficiary = Beneficiary.maison)),
          AppChip('Une personne', icon: Icons.people_rounded, color: C.warn, selected: beneficiary == Beneficiary.personne,
              onTap: () => setState(() => beneficiary = Beneficiary.personne)),
        ]),
        if (beneficiary == Beneficiary.personne)
          Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: C.warnSoft, borderRadius: BorderRadius.circular(18)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              AppField(label: 'Nom de la personne', controller: person, hint: 'Ex : Nado', onChanged: (_) => setState(() {})),
              if (people.isNotEmpty) Wrap(children: [for (final p in people) AppChip(p, color: C.muted, onTap: () => setState(() => person.text = p))]),
              const FieldLabel('Nature'),
              Wrap(children: [
                AppChip('Dépense pour elle/lui', color: C.transfer, selected: nature == Nature.pour, onTap: () => setState(() => nature = Nature.pour)),
                AppChip('Donation', icon: Icons.favorite_rounded, color: C.expense, selected: nature == Nature.donation,
                    onTap: () => setState(() => nature = Nature.donation)),
                AppChip('Cadeau', icon: Icons.card_giftcard_rounded, color: C.warn, selected: nature == Nature.cadeau,
                    onTap: () => setState(() => nature = Nature.cadeau)),
                AppChip("C'est un prêt", icon: Icons.arrow_forward_rounded, color: C.primary, onTap: () => Navigator.pushReplacement(
                    context, MaterialPageRoute(builder: (_) => const DebtFormScreen(direction: DebtDirection.lent)))),
              ]),
            ]),
          ),
      ],
      const FieldLabel('Date'),
      Wrap(children: [
        AppChip("Aujourd'hui", selected: date.text == today(), onTap: () => setState(() => date.text = today())),
        AppChip('Hier', selected: date.text == yesterday(), onTap: () => setState(() => date.text = yesterday())),
      ]),
      AppField(controller: date, hint: 'AAAA-MM-JJ', onChanged: (_) => setState(() {})),
      AppField(label: 'Note (optionnel)', controller: note, hint: 'Détails…', maxLines: 3),
      if (widget.id == null && type != TxType.transfer)
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: C.border)),
          child: Row(children: [
            Icon(Icons.autorenew_rounded, color: C.primary),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Répéter chaque mois', style: ts(14, w: w7)),
              Text('Salaire, tontine, abonnement… ajoutés automatiquement le '
                  '${date.text.length == 10 ? int.tryParse(date.text.substring(8)) ?? 1 : 1} du mois', style: ts(12, c: C.muted)),
            ])),
            Switch(value: repeat, onChanged: (v) => setState(() => repeat = v)),
          ]),
        ),
      AppButton('Enregistrer', icon: Icons.check_rounded, onTap: save),
      if (widget.id != null) ...[
        const SizedBox(height: 10),
        AppButton('Supprimer', icon: Icons.delete_outline_rounded, kind: BtnKind.danger, onTap: () async {
          if (await confirmDialog(context, 'Supprimer', 'Supprimer cette opération ?', ok: 'Supprimer', danger: true)) {
            store.deleteTx(widget.id!);
            if (context.mounted) Navigator.pop(context);
          }
        }),
      ],
    ]);
  }
}
