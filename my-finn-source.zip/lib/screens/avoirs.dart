import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';
import 'accounts.dart';
import 'debts.dart';

/// « Mes avoirs » : tout ce que je possède, utilisable tout de suite ou non.
class AvoirsScreen extends StatelessWidget {
  const AvoirsScreen({super.key});

  @override
  Widget build(BuildContext context) => Watch((context) => _build(context));

  Widget _build(BuildContext context) {
    final a = store.avoirs();
    return SubPage(
      title: 'Mes avoirs',
      children: [
        GradientBox(
          gradient: heroGradient,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Total de mes avoirs',
                style: ts(14, w: w6, c: Colors.white70),
              ),
              const SizedBox(height: 4),
              FittedBox(
                child: Text(
                  money(a.total),
                  style: ts(32, w: w8, c: Colors.white, ls: -1),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Disponible + placements + ce qu\'on me doit − ce que je dois',
                style: ts(12, w: w6, c: Colors.white70),
              ),
            ],
          ),
        ),
        const SectionTitle('Utilisable tout de suite'),
        AppCard(
          onTap: () => push(context, const AccountsScreen()),
          child: _row(
            Icons.account_balance_wallet_rounded,
            C.primary,
            'Disponible',
            'Comptes et cash',
            a.disponible,
          ),
        ),
        if (a.horsDisponible.isNotEmpty) ...[
          SectionTitle(
            'Placements, tontines et bons',
            trailing: Text(money(a.placements), style: ts(14, w: w8)),
          ),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Column(
              children: [
                for (final (acc, v) in a.horsDisponible)
                  InkWell(
                    onTap: () => push(context, AccountDetailScreen(id: acc.id)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: _row(
                        accountIcon(acc.type),
                        Color(acc.color),
                        acc.name,
                        _since(acc),
                        v,
                        subColor:
                            store.isTontine(acc) &&
                                store.savingsInfo(acc).count > 0
                            ? C.income
                            : null,
                        badge: AccountBadge(acc, size: 40),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
        if (store.closedSavings().isNotEmpty) ...[
          const SectionTitle('Terminées'),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Column(
              children: [
                for (final (acc, t) in store.closedSavings())
                  InkWell(
                    onTap: () => push(context, AccountDetailScreen(id: acc.id)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: _row(
                        Icons.check_circle_rounded,
                        C.income,
                        acc.name,
                        'Touchée le ${dayShort(acc.closed!)} '
                        '${acc.closed!.substring(0, 4)}'
                        '${t == null ? '' : ' · sur ${store.account(t.toAccountId)?.name ?? ''}'}',
                        t?.amount ?? 0,
                        badge: AccountBadge(acc, size: 40),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
        const SectionTitle('Prêts et dettes'),
        AppCard(
          onTap: () => push(context, const DebtsScreen()),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: _row(
                  Icons.call_received_rounded,
                  C.income,
                  'On me doit',
                  'Créances, prêts, sommes à recevoir',
                  a.creances,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: _row(
                  Icons.call_made_rounded,
                  C.expense,
                  'Je dois',
                  'Mes dettes et l\'argent à rendre',
                  -a.dettes,
                ),
              ),
            ],
          ),
        ),
        Text(
          'Les placements et tontines ne sont pas comptés dans le disponible : y mettre de l\'argent n\'est pas une dépense.',
          style: ts(12, c: C.muted),
        ),
      ],
    );
  }

  /// « 25.000 / mois · depuis juin 2024 » sous une tontine ou un placement.
  static String _since(Account acc) {
    final i = store.savingsInfo(acc);
    if (i.count == 0) return accountTypeLabel(acc.type);
    final s =
        '${num0(i.monthly)} / mois · depuis ${shortMonth(i.since!)} ${i.since!.substring(0, 4)}';
    return store.isTontine(acc) ? s : 'Placement · $s';
  }

  Widget _row(
    IconData icon,
    Color color,
    String title,
    String sub,
    int v, {
    Widget? badge,
    Color? subColor,
  }) => Row(
    children: [
      badge ?? IconBubble(icon, color, size: 40),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: ts(15, w: w7),
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              sub,
              style: subColor == null
                  ? ts(12, c: C.muted)
                  : ts(12, w: w7, c: subColor),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
      const SizedBox(width: 8),
      Text(
        money(v),
        style: ts(15, w: w8, c: v < 0 ? C.expense : C.text),
      ),
    ],
  );
}
