import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/ui.dart';

Color budgetColor(int spent, int budget) {
  if (budget <= 0) return C.primary;
  if (spent > budget) return C.expense;
  if (spent >= budget * 0.9) return C.warn;
  return C.income;
}

/// Budget du mois : dépensé par catégorie face au budget fixé.
class BudgetScreen extends StatefulWidget {
  final String? month;
  const BudgetScreen({super.key, this.month});
  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  late String month = widget.month ?? currentMonth();
  bool editing = false;

  @override
  Widget build(BuildContext context) => Watch((context) {
    final sm = store.summary(month);
    final spentOf = {
      for (final c in sm.byCategory.where((c) => !c.cat.isIncome))
        c.cat.id: c.total,
    };
    final all = store.cats(income: false);
    final withBudget = all.where((c) => c.budget > 0).toList()
      ..sort(
        (a, b) =>
            (spentOf[b.id] ?? 0) * 1000 ~/ b.budget -
            (spentOf[a.id] ?? 0) * 1000 ~/ a.budget,
      );
    final shown = editing || withBudget.isEmpty ? all : withBudget;
    final totalBudget = withBudget.fold(0, (x, c) => x + c.budget);
    final totalSpent = withBudget.fold(0, (x, c) => x + (spentOf[c.id] ?? 0));
    final left = totalBudget - totalSpent;
    final pc = totalBudget > 0 ? (totalSpent * 100 / totalBudget).round() : 0;
    return SubPage(
      title: 'Budget',
      actions: [
        Center(
          child: MonthChip(
            month: month,
            onChanged: (m) => setState(() => month = m),
          ),
        ),
      ],
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Dépensé',
                      style: ts(12, w: w6, c: C.muted),
                    ),
                  ),
                  Text(
                    'Budget du mois',
                    style: ts(12, w: w6, c: C.muted),
                  ),
                ],
              ),
              const SizedBox(height: 2),
              Row(
                children: [
                  Expanded(
                    child: Text(num0(totalSpent), style: ts(20, w: w8)),
                  ),
                  Text(num0(totalBudget), style: ts(15, w: w7)),
                ],
              ),
              const SizedBox(height: 10),
              ProgressBar(
                value: totalSpent,
                max: totalBudget,
                color: budgetColor(totalSpent, totalBudget),
                height: 8,
              ),
              const SizedBox(height: 10),
              Text(
                totalBudget == 0
                    ? 'Touche « Modifier » pour fixer tes budgets.'
                    : left >= 0
                    ? 'Il te reste ${money(left)} ($pc % utilisé)'
                    : 'Dépassé de ${money(-left)} ($pc %)',
                style: ts(12, w: w7, c: left < 0 ? C.expense : C.muted),
              ),
            ],
          ),
        ),
        SectionTitle(
          'Par catégorie',
          trailing: LinkText(
            editing ? 'Terminé' : 'Modifier',
            onTap: () => setState(() => editing = !editing),
          ),
        ),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Column(
            children: [
              for (final c in shown) _row(context, c, spentOf[c.id] ?? 0),
            ],
          ),
        ),
        if (editing)
          Text(
            'Touche une catégorie pour changer son budget.',
            style: ts(12, c: C.muted),
          ),
      ],
    );
  });

  Widget _row(BuildContext context, Cat c, int spent) {
    final color = budgetColor(spent, c.budget);
    final over = c.budget > 0 && spent > c.budget;
    return InkWell(
      onTap: () => editBudget(context, c),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(
          children: [
            Row(
              children: [
                IconBubble(iconFor(c.icon), C.transfer, size: 38),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        c.name,
                        style: ts(14, w: w7),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        c.budget > 0
                            ? '${num0(spent)} / ${num0(c.budget)}'
                            : '${num0(spent)} · pas de budget',
                        style: ts(12, c: C.muted),
                      ),
                    ],
                  ),
                ),
                if (c.budget > 0)
                  Text(
                    '${(spent * 100 / c.budget).round()} %',
                    style: ts(13, w: w8, c: over ? C.expense : C.text),
                  )
                else
                  Icon(Icons.add_rounded, color: C.faint, size: 20),
              ],
            ),
            if (c.budget > 0) ...[
              const SizedBox(height: 10),
              ProgressBar(value: spent, max: c.budget, color: color, height: 6),
            ],
          ],
        ),
      ),
    );
  }
}

/// Petite fenêtre pour fixer le budget mensuel d'une catégorie.
Future<void> editBudget(BuildContext context, Cat c) async {
  final ctrl = TextEditingController(text: c.budget > 0 ? num0(c.budget) : '');
  final v = await showDialog<int>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: C.sheet,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(cardRadius),
      ),
      title: Text('Budget « ${c.name} »', style: ts(17, w: w8)),
      content: AppField(
        label: 'Montant par mois (FCFA)',
        controller: ctrl,
        hint: 'Vide = pas de budget',
        keyboard: TextInputType.number,
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: Text(
            'Annuler',
            style: ts(14, w: w7, c: C.muted),
          ),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, parseAmount(ctrl.text) ?? 0),
          child: Text(
            'Enregistrer',
            style: ts(14, w: w8, c: C.primary),
          ),
        ),
      ],
    ),
  );
  if (v == null) return;
  c.budget = v < 0 ? 0 : v;
  store.saveCategory(c);
}
