import 'dart:ui' show ImageFilter;

import 'package:flutter/foundation.dart' show kIsWeb;

import 'demo.dart';
import 'update.dart';
import 'cloud.dart';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

import 'format.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets/common.dart';
import 'widgets/ui.dart';
import 'screens/debts.dart';
import 'screens/home.dart';
import 'screens/report.dart';
import 'screens/transactions.dart';
import 'screens/tx_form.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Aperçu web : démo préremplie avec le suivi complet, vue au 03/11/2026
  if (webDemo) fixedToday = '2026-11-03';
  await store.load(demo: webDemo);
  // Aperçu web : ?theme=dark ou ?theme=light pour choisir le mode.
  final th = webDemo ? Uri.base.queryParameters['theme'] : null;
  if (th != null) store.settings['theme'] = th;
  await cloud.init();
  runApp(const MyFinnApp());
  checkForUpdate();
}

class MyFinnApp extends StatefulWidget {
  const MyFinnApp({super.key});
  @override
  State<MyFinnApp> createState() => _MyFinnAppState();
}

class _MyFinnAppState extends State<MyFinnApp> {
  late bool locked = store.pinHash != null;
  late final AppLifecycleListener _life;

  @override
  void initState() {
    super.initState();
    // Reverrouille quand l'app passe en arrière-plan
    _life = AppLifecycleListener(
      onHide: () {
        if (store.pinHash != null) setState(() => locked = true);
        cloud.schedule(
          delay: Duration.zero,
        ); // envoie tout de suite ce qui reste à envoyer
      },
      onResume: () => cloud.schedule(),
    );
  }

  @override
  void dispose() {
    _life.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      SystemChrome.setSystemUIOverlayStyle(
        store.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      );
      return MaterialApp(
        title: 'MY FINN',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        locale: const Locale('fr', 'FR'),
        supportedLocales: const [Locale('fr', 'FR')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        // Suit la taille du texte choisie sur le téléphone, sans casser la mise en page.
        builder: (context, child) => MediaQuery.withClampedTextScaling(
          maxScaleFactor: 1.35,
          child: child!,
        ),
        home: locked && store.pinHash != null
            ? LockScreen(onUnlock: () => setState(() => locked = false))
            : const Shell(),
      );
    },
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) => Watch((context) {
    final pages = [
      HomeScreen(goTab: (i) => setState(() => tab = i)),
      const TransactionsScreen(),
      const DebtsScreen(),
      const ReportScreen(),
    ];
    return Scaffold(
      backgroundColor: C.bg,
      extendBody: true,
      body: Stack(
        children: [
          Positioned.fill(child: Aurora(key: ValueKey(store.dark))),
          IndexedStack(index: tab, children: pages),
        ],
      ),
      bottomNavigationBar: _BottomBar(
        tab: tab,
        onTab: (i) => setState(() => tab = i),
        onAdd: () => push(context, const TxFormScreen(type: TxType.expense)),
      ),
    );
  });
}

class _BottomBar extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onTab;
  final VoidCallback onAdd;
  const _BottomBar({
    required this.tab,
    required this.onTab,
    required this.onAdd,
  });

  static const _items = [
    (Icons.home_rounded, Icons.home_outlined, 'Accueil'),
    (Icons.receipt_long_rounded, Icons.receipt_long_outlined, 'Opérations'),
    (Icons.handshake_rounded, Icons.handshake_outlined, 'Prêts'),
    (Icons.pie_chart_rounded, Icons.pie_chart_outline_rounded, 'Bilan'),
  ];

  @override
  Widget build(BuildContext context) {
    Widget item(int i) {
      final sel = tab == i;
      final it = _items[i];
      final col = store.dark
          ? (sel ? C.primary : C.muted)
          : (sel ? Colors.white : Colors.white.withValues(alpha: 0.62));
      return Expanded(
        child: InkWell(
          onTap: () => onTab(i),
          child: SizedBox(
            height: 64,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(sel ? it.$1 : it.$2, color: col, size: 24),
                const SizedBox(height: 3),
                Text(
                  it.$3,
                  style: ts(11, w: sel ? w8 : w6, c: col),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      );
    }

    final plus = Semantics(
      button: true,
      label: 'Ajouter une opération',
      child: GestureDetector(
        onTap: onAdd,
        child: Container(
          width: store.dark ? 56 : 52,
          height: store.dark ? 56 : 52,
          decoration: store.dark
              ? BoxDecoration(
                  gradient: plusGradient,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF5B5CFF).withValues(alpha: 0.5),
                      blurRadius: 26,
                      offset: const Offset(0, 10),
                    ),
                  ],
                )
              : BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
          child: Icon(
            Icons.add_rounded,
            color: store.dark ? Colors.white : const Color(0xFF0D33D9),
            size: 30,
          ),
        ),
      ),
    );
    final row = SafeArea(
      top: false,
      child: SizedBox(
        height: 68,
        child: Row(
          children: [
            item(0),
            item(1),
            Expanded(child: Center(child: plus)),
            item(3),
            item(2),
          ],
        ),
      ),
    );

    // Mode Nuit : barre en verre dépoli, le fond coloré se voit à travers.
    if (store.dark) {
      return ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
        clipBehavior: Clip.antiAlias,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 26, sigmaY: 26),
          child: Container(
            decoration: BoxDecoration(
              color: C.tabBar,
              border: const Border(top: BorderSide(color: Color(0x1FFFFFFF))),
            ),
            child: row,
          ),
        ),
      );
    }

    // Mode clair : barre posée en bas, coins du haut légèrement arrondis.
    return DecoratedBox(
      decoration: BoxDecoration(
        color: C.tabBar,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF04103F).withValues(alpha: 0.18),
            blurRadius: 18,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: row,
    );
  }
}

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String pin = '';
  bool error = false, bio = false;
  final _auth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) _initBio();
  }

  Future<void> _initBio() async {
    try {
      final ok =
          await _auth.canCheckBiometrics && await _auth.isDeviceSupported();
      if (!mounted) return;
      setState(() => bio = ok);
      if (ok) _tryBio();
    } catch (_) {}
  }

  Future<void> _tryBio() async {
    try {
      if (await _auth.authenticate(localizedReason: 'Déverrouiller MY FINN'))
        widget.onUnlock();
    } catch (_) {}
  }

  void change(String v) {
    setState(() {
      pin = v;
      error = false;
    });
    if (v.length == 4) {
      if (hashPin(v) == store.pinHash) {
        widget.onUnlock();
      } else {
        Future.delayed(const Duration(milliseconds: 150), () {
          if (mounted)
            setState(() {
              error = true;
              pin = '';
            });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(gradient: slateGradient),
      child: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.lock_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'MY FINN',
                style: ts(24, w: w8, c: Colors.white),
              ),
              const SizedBox(height: 6),
              Text(
                error ? 'Code incorrect, réessaie' : 'Entre ton code PIN',
                style: ts(14, w: w6, c: Colors.white70),
              ),
              const SizedBox(height: 30),
              PinPad(
                value: pin,
                onChanged: change,
                light: true,
                extra: bio
                    ? IconButton(
                        onPressed: _tryBio,
                        icon: const Icon(
                          Icons.fingerprint_rounded,
                          color: Colors.white,
                          size: 34,
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
