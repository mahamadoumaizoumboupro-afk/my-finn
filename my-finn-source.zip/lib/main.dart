import 'package:flutter/foundation.dart' show kIsWeb;
import 'update.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'format.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets/common.dart';
import 'widgets/ui.dart';
import 'screens/debts.dart';
import 'screens/home.dart';
import 'screens/report.dart';
import 'screens/transactions.dart';
import 'screens/tx_form.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Aperçu web : démo préremplie avec septembre 2026, vue au 30/09
  if (kIsWeb) fixedToday = '2026-09-30';
  await store.load(demo: kIsWeb);
  runApp(const MyFinnApp());
  checkForUpdate();
}

class MyFinnApp extends StatefulWidget {
  const MyFinnApp({super.key});
  @override
  State<MyFinnApp> createState() => _MyFinnAppState();
}

class _MyFinnAppState extends State<MyFinnApp> {
  late bool locked = store.pinHash != null;
  late final AppLifecycleListener _life;

  @override
  void initState() {
    super.initState();
    // Reverrouille quand l'app passe en arrière-plan
    _life = AppLifecycleListener(onHide: () {
      if (!kIsWeb && store.pinHash != null) setState(() => locked = true);
    });
  }

  @override
  void dispose() {
    _life.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          SystemChrome.setSystemUIOverlayStyle(store.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark);
          return MaterialApp(
            title: 'MY FINN',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(),
            home: locked && store.pinHash != null ? LockScreen(onUnlock: () => setState(() => locked = false)) : const Shell(),
          );
        },
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) => Watch((context) {
        final pages = [
          HomeScreen(goTab: (i) => setState(() => tab = i)),
          const TransactionsScreen(),
          const DebtsScreen(),
          const ReportScreen(),
        ];
        return Scaffold(
          backgroundColor: C.bg,
          extendBody: true,
          body: IndexedStack(index: tab, children: pages),
          bottomNavigationBar: _BottomBar(tab: tab, onTab: (i) => setState(() => tab = i),
              onAdd: () => push(context, const TxFormScreen(type: TxType.expense))),
        );
      });
}

class _BottomBar extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onTab;
  final VoidCallback onAdd;
  const _BottomBar({required this.tab, required this.onTab, required this.onAdd});

  static const _items = [
    (Icons.home_rounded, Icons.home_outlined, 'Accueil'),
    (Icons.receipt_long_rounded, Icons.receipt_long_outlined, 'Opérations'),
    (Icons.people_rounded, Icons.people_outline_rounded, 'Prêts'),
    (Icons.pie_chart_rounded, Icons.pie_chart_outline_rounded, 'Bilan'),
  ];

  @override
  Widget build(BuildContext context) {
    Widget item(int i) {
      final sel = tab == i;
      final it = _items[i];
      return Expanded(
        child: InkWell(
          onTap: () => onTab(i),
          child: Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 4),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(sel ? it.$1 : it.$2, color: sel ? C.primary : C.faint, size: 24),
              const SizedBox(height: 3),
              Text(it.$3, style: ts(11, w: sel ? w8 : w6, c: sel ? C.primary : C.muted)),
            ]),
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: C.tabBar,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 16, offset: const Offset(0, -4))],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            item(0), item(1),
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -22),
                child: Center(
                  child: GestureDetector(
                    onTap: onAdd,
                    child: Container(
                      width: 62, height: 62,
                      decoration: BoxDecoration(
                        gradient: heroGradient, shape: BoxShape.circle, border: Border.all(color: C.tabBar, width: 4),
                        boxShadow: [BoxShadow(color: C.primary.withValues(alpha: 0.45), blurRadius: 14, offset: const Offset(0, 6))],
                      ),
                      child: const Icon(Icons.add_rounded, color: Colors.white, size: 32),
                    ),
                  ),
                ),
              ),
            ),
            item(2), item(3),
          ]),
        ),
      ),
    );
  }
}

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String pin = '';
  bool error = false, bio = false;
  final _auth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) _initBio();
  }

  Future<void> _initBio() async {
    try {
      final ok = await _auth.canCheckBiometrics && await _auth.isDeviceSupported();
      if (!mounted) return;
      setState(() => bio = ok);
      if (ok) _tryBio();
    } catch (_) {}
  }

  Future<void> _tryBio() async {
    try {
      if (await _auth.authenticate(localizedReason: 'Déverrouiller MY FINN')) widget.onUnlock();
    } catch (_) {}
  }

  void change(String v) {
    setState(() { pin = v; error = false; });
    if (v.length == 4) {
      if (hashPin(v) == store.pinHash) {
        widget.onUnlock();
      } else {
        Future.delayed(const Duration(milliseconds: 150), () { if (mounted) setState(() { error = true; pin = ''; }); });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: heroGradient),
          child: Center(
            child: SingleChildScrollView(
              child: Column(children: [
                Container(width: 64, height: 64, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(22)),
                    child: const Icon(Icons.lock_rounded, color: Colors.white, size: 30)),
                const SizedBox(height: 16),
                Text('MY FINN', style: ts(24, w: w8, c: Colors.white)),
                const SizedBox(height: 6),
                Text(error ? 'Code incorrect, réessaie' : 'Entre ton code PIN', style: ts(14, w: w6, c: Colors.white70)),
                const SizedBox(height: 30),
                PinPad(value: pin, onChanged: change, light: true,
                    extra: bio ? IconButton(onPressed: _tryBio, icon: const Icon(Icons.fingerprint_rounded, color: Colors.white, size: 34)) : null),
              ]),
            ),
          ),
        ),
      );
}
