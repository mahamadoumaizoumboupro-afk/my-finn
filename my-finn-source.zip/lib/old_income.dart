/// Revenus d'avant l'app (Abib Digit, 2022 → août 2025), donnés par Mahamadou le 12/11/2026.
/// 2023 : « entre 55.000 et 70.000 » pour 11 mois → montants estimés (63.000), total de l'année exact.
library;

import 'models.dart';

const _abib = 'Salaire Abib Digit';

HistIncome _h(
  String month,
  int amount, [
  String label = 'Salaire',
  bool est = false,
]) => HistIncome(
  month: month,
  source: _abib,
  label: label,
  amount: amount,
  est: est,
);

List<HistIncome> oldIncome() => [
  // 2022 : 2 mois à 15.000, puis 10 mois à 40.000 (430.000)
  _h('2022-01', 15000),
  _h('2022-02', 15000),
  for (var m = 3; m <= 12; m++)
    _h('2022-${m.toString().padLeft(2, '0')}', 40000),
  // 2023 : 11 mois entre 55.000 et 70.000 (693.000 en tout), décembre 80.000 (773.000)
  for (var m = 1; m <= 11; m++)
    _h(
      '2023-${m.toString().padLeft(2, '0')}',
      63000,
      'Salaire (entre 55.000 et 70.000)',
      true,
    ),
  _h('2023-12', 80000),
  // 2024 : mois par mois (2.091.000)
  _h('2024-01', 100000),
  _h('2024-02', 175000),
  _h('2024-03', 130000),
  _h('2024-04', 160000, 'Salaire (dont complément 30.000)'),
  _h('2024-05', 130000),
  _h('2024-05', 21000, 'Prime'),
  _h('2024-05', 50000, 'Cadeau Nigelec'),
  _h('2024-06', 130000),
  _h('2024-07', 175000),
  _h('2024-08', 175000),
  _h('2024-09', 175000),
  _h('2024-10', 175000),
  _h('2024-11', 175000),
  _h('2024-11', 120000, 'Achat téléphone (par Ibou)'),
  _h('2024-12', 200000),
  // 2025 : janvier → août (septembre et octobre sont déjà dans l'historique)
  _h('2025-01', 185000),
  _h('2025-02', 172400),
  _h('2025-02', 50000, 'Commission Saflan'),
  _h('2025-02', 50000, 'Commission Event'),
  _h('2025-03', 175300),
  _h('2025-04', 185000),
  _h('2025-04', 20000, 'Commission Bingo'),
  _h('2025-04', 10000, 'Commission Likadu'),
  _h('2025-05', 172400),
  _h('2025-06', 176000),
  _h('2025-06', 149000, 'Commission Phasaoc'),
  _h('2025-07', 175300),
  _h('2025-08', 190200),
];
