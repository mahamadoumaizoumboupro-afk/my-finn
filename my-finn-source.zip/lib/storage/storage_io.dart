import 'package:flutter/painting.dart';

import 'dart:io';

import 'package:path_provider/path_provider.dart';

Future<File> _file(String name) async {
  final dir = await getApplicationDocumentsDirectory();
  return File('${dir.path}/$name.json');
}

Future<String?> loadData({String name = 'myfinn'}) async {
  final f = await _file(name);
  return await f.exists() ? f.readAsString() : null;
}

Future<void> saveData(String json, {String name = 'myfinn'}) async {
  final f = await _file(name);
  final tmp = File('${f.path}.tmp');
  await tmp.writeAsString(json, flush: true);
  await tmp.rename(f.path); // écriture atomique : pas de fichier à moitié écrit
}

/// Photo de profil : copiée dans le dossier de l'app, jamais envoyée en ligne.
Future<String?> savePhoto(List<int> bytes) async {
  final dir = await getApplicationDocumentsDirectory();
  final f = File(
    '${dir.path}/photo_profil_${DateTime.now().millisecondsSinceEpoch}.jpg',
  );
  await f.writeAsBytes(bytes, flush: true);
  return f.path;
}

ImageProvider? photoProvider(String? path) {
  if (path == null || path.isEmpty) return null;
  final f = File(path);
  return f.existsSync() ? FileImage(f) : null;
}
