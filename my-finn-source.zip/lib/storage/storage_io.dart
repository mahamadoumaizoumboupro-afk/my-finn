import 'dart:io';
import 'package:path_provider/path_provider.dart';

Future<File> _file(String name) async {
  final dir = await getApplicationDocumentsDirectory();
  return File('${dir.path}/$name.json');
}

Future<String?> loadData({String name = 'myfinn'}) async {
  final f = await _file(name);
  return await f.exists() ? f.readAsString() : null;
}

Future<void> saveData(String json, {String name = 'myfinn'}) async {
  final f = await _file(name);
  final tmp = File('${f.path}.tmp');
  await tmp.writeAsString(json, flush: true);
  await tmp.rename(f.path); // écriture atomique : pas de fichier à moitié écrit
}
