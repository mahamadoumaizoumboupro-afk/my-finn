import 'package:web/web.dart' as web;

String _key(String name) => name == 'myfinn' ? 'myfinn-data' : 'myfinn-$name';

Future<String?> loadData({String name = 'myfinn'}) async {
  try {
    return web.window.localStorage.getItem(_key(name));
  } catch (_) {
    return null;
  }
}

Future<void> saveData(String json, {String name = 'myfinn'}) async {
  try {
    web.window.localStorage.setItem(_key(name), json);
  } catch (_) {
    /* stockage indisponible : les données restent en mémoire */
  }
}
