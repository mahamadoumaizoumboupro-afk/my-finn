import 'package:web/web.dart' as web;

const _key = 'myfinn-data';

Future<String?> loadData() async {
  try {
    return web.window.localStorage.getItem(_key);
  } catch (_) {
    return null;
  }
}

Future<void> saveData(String json) async {
  try {
    web.window.localStorage.setItem(_key, json);
  } catch (_) {/* stockage indisponible : les données restent en mémoire */}
}
