/// Stockage local des données (fichier sur téléphone, localStorage sur le web).
library;

export 'storage_io.dart' if (dart.library.js_interop) 'storage_web.dart';
