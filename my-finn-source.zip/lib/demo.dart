import 'package:flutter/foundation.dart' show kIsWeb;

/// Aperçu de démonstration (captures d'écran) : `--dart-define=DEMO=true`.
/// Sans ce réglage, la version web est la vraie app (pour l'iPhone).
const kDemo = bool.fromEnvironment('DEMO');
bool get webDemo => kIsWeb && kDemo;
