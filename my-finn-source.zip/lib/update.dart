import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

/// Numéro de cette version, donné par GitHub Actions (--dart-define=BUILD_NUMBER=…).
/// 0 = version de développement ou aperçu web : pas de vérification.
const int buildNumber = int.fromEnvironment('BUILD_NUMBER');
String get versionLabel =>
    buildNumber == 0 ? 'développement' : '1.0.$buildNumber';

const _latestUrl =
    'https://api.github.com/repos/mahamadoumaizoumboupro-afk/my-finn/releases/latest';
const releasesPage =
    'https://github.com/mahamadoumaizoumboupro-afk/my-finn/releases/latest';

class UpdateInfo {
  final int number;
  final String apkUrl;
  const UpdateInfo(this.number, this.apkUrl);
  String get label => '1.0.$number';
}

/// Nouvelle version trouvée sur GitHub, ou null.
final ValueNotifier<UpdateInfo?> updateAvailable = ValueNotifier(null);

/// Lit le numéro dans un tag comme "v1.0.7" → 7.
int? releaseNumber(String tag) => int.tryParse(tag.split('.').last);

/// Vérifie en silence s'il existe une version plus récente. Sans internet : ne fait rien.
/// Renvoie true si une mise à jour est disponible.
Future<bool> checkForUpdate() async {
  if (kIsWeb || buildNumber == 0) return false;
  try {
    final res = await http
        .get(
          Uri.parse(_latestUrl),
          headers: {'Accept': 'application/vnd.github+json'},
        )
        .timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) return false;
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final n = releaseNumber('${data['tag_name'] ?? ''}');
    if (n == null || n <= buildNumber) return false;
    final assets = (data['assets'] as List? ?? []).cast<Map<String, dynamic>>();
    final apk = assets
        .where((a) => '${a['name']}'.endsWith('.apk'))
        .firstOrNull;
    updateAvailable.value = UpdateInfo(
      n,
      apk?['browser_download_url'] as String? ?? releasesPage,
    );
    return true;
  } catch (_) {
    return false;
  }
}

Future<void> openUpdate([UpdateInfo? info]) async {
  final url = (info ?? updateAvailable.value)?.apkUrl ?? releasesPage;
  await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
}
