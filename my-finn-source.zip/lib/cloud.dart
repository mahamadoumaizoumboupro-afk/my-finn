import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import 'storage/storage.dart';
import 'store.dart';

/// Identifiants du projet Firebase (publics : ce ne sont pas des secrets,
/// la sécurité vient des règles Firestore : chacun ne lit que ses propres données).
const firebaseApiKey = String.fromEnvironment('FIREBASE_API_KEY', defaultValue: 'AIzaSyAkJZ4QxLgZ9rzin6X1uppvGzhOBtbhznc');
const firebaseProjectId = String.fromEnvironment('FIREBASE_PROJECT_ID', defaultValue: 'my-finn-f93b5');

/// Pas sur l'aperçu web (données de démonstration).
bool get cloudAvailable => !kIsWeb && firebaseApiKey.isNotEmpty && firebaseProjectId.isNotEmpty;

class CloudError implements Exception {
  final String message;
  const CloudError(this.message);
  @override
  String toString() => message;
}

/// Traduit les codes d'erreur de Firebase en phrases simples.
String frenchAuthError(String code) {
  if (code.startsWith('EMAIL_EXISTS')) return 'Un compte existe déjà avec cet e-mail. Utilise « Me connecter ».';
  if (code.startsWith('EMAIL_NOT_FOUND') || code.startsWith('INVALID_LOGIN_CREDENTIALS') || code.startsWith('INVALID_PASSWORD')) {
    return 'E-mail ou mot de passe incorrect.';
  }
  if (code.startsWith('INVALID_EMAIL')) return 'Cette adresse e-mail n\'est pas valide.';
  if (code.startsWith('WEAK_PASSWORD')) return 'Mot de passe trop court : au moins 6 caractères.';
  if (code.startsWith('TOO_MANY_ATTEMPTS')) return 'Trop d\'essais. Réessaie dans quelques minutes.';
  if (code.startsWith('USER_DISABLED')) return 'Ce compte est désactivé.';
  if (code.startsWith('OPERATION_NOT_ALLOWED')) return 'La connexion par e-mail n\'est pas activée dans Firebase.';
  return 'Erreur : $code';
}

/// Sauvegarde en ligne dans Firebase (Authentication + Firestore), par l'API web :
/// aucun réglage Android particulier n'est nécessaire.
class Cloud extends ChangeNotifier {
  final AppStore store;
  final http.Client _http;
  Cloud(this.store, {http.Client? client}) : _http = client ?? http.Client();

  String? uid;
  String? email;
  String? _refreshToken;
  String? _idToken;
  DateTime? _idTokenExpiry;
  /// Empreinte de chaque document déjà envoyé : on n'envoie que ce qui a changé.
  Map<String, String> _sent = {};
  DateTime? lastSync;
  bool syncing = false;
  String? lastError;
  Timer? _timer;

  bool get signedIn => uid != null;

  /* ---------- État local (fichier séparé, jamais dans les sauvegardes) ---------- */
  Future<void> init() async {
    if (!cloudAvailable) return;
    try {
      final raw = await loadData(name: 'cloud');
      if (raw != null) {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        uid = j['uid'];
        email = j['email'];
        _refreshToken = j['refresh'];
        _sent = Map<String, String>.from(j['sent'] ?? {});
        lastSync = DateTime.tryParse(j['last_sync'] ?? '');
      }
    } catch (_) {}
    store.onSaved = schedule;
    notifyListeners();
    if (signedIn) schedule(delay: const Duration(seconds: 2));
  }

  Future<void> _saveState() async => !store.persist ? null : saveData(jsonEncode({
        'uid': uid, 'email': email, 'refresh': _refreshToken, 'sent': _sent,
        'last_sync': lastSync?.toIso8601String(),
      }), name: 'cloud');

  /* ---------- Compte ---------- */
  Future<Map<String, dynamic>> _post(Uri url, Map<String, dynamic> body) async {
    final http.Response res;
    try {
      res = await _http.post(url, headers: {'Content-Type': 'application/json'}, body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      throw const CloudError('Pas de connexion internet.');
    }
    final j = jsonDecode(res.body.isEmpty ? '{}' : res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) {
      throw CloudError(frenchAuthError('${(j['error'] as Map?)?['message'] ?? res.statusCode}'));
    }
    return j;
  }

  Uri _auth(String method) =>
      Uri.parse('https://identitytoolkit.googleapis.com/v1/accounts:$method?key=$firebaseApiKey');

  Future<void> _signedIn(Map<String, dynamic> j) async {
    uid = j['localId'];
    email = j['email'];
    _refreshToken = j['refreshToken'];
    _idToken = j['idToken'];
    _idTokenExpiry = DateTime.now().add(Duration(seconds: int.tryParse('${j['expiresIn']}') ?? 3600) - const Duration(minutes: 2));
    _sent = {};
    await _saveState();
    notifyListeners();
  }

  Future<void> signUp(String mail, String password) async =>
      _signedIn(await _post(_auth('signUp'), {'email': mail.trim(), 'password': password, 'returnSecureToken': true}));

  Future<void> signIn(String mail, String password) async =>
      _signedIn(await _post(_auth('signInWithPassword'), {'email': mail.trim(), 'password': password, 'returnSecureToken': true}));

  Future<void> resetPassword(String mail) async =>
      _post(_auth('sendOobCode'), {'requestType': 'PASSWORD_RESET', 'email': mail.trim()});

  Future<void> signOut() async {
    _timer?.cancel();
    uid = email = _refreshToken = _idToken = null;
    _sent = {};
    lastSync = null;
    lastError = null;
    await _saveState();
    notifyListeners();
  }

  Future<String> _token() async {
    if (_idToken != null && _idTokenExpiry != null && DateTime.now().isBefore(_idTokenExpiry!)) return _idToken!;
    if (_refreshToken == null) throw const CloudError('Reconnecte-toi à ta sauvegarde en ligne.');
    final http.Response res;
    try {
      res = await _http.post(Uri.parse('https://securetoken.googleapis.com/v1/token?key=$firebaseApiKey'),
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: {'grant_type': 'refresh_token', 'refresh_token': _refreshToken!}).timeout(const Duration(seconds: 20));
    } catch (_) {
      throw const CloudError('Pas de connexion internet.');
    }
    if (res.statusCode != 200) throw const CloudError('Reconnecte-toi à ta sauvegarde en ligne.');
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    _idToken = j['id_token'];
    _refreshToken = j['refresh_token'] ?? _refreshToken;
    _idTokenExpiry = DateTime.now().add(Duration(seconds: int.tryParse('${j['expires_in']}') ?? 3600) - const Duration(minutes: 2));
    return _idToken!;
  }

  /* ---------- Firestore : users/{uid}/data/{document} avec un champ texte "json" ---------- */
  String get _base =>
      'https://firestore.googleapis.com/v1/projects/$firebaseProjectId/databases/(default)/documents/users/$uid/data';

  Future<http.Response> _call(String method, Uri url, {Object? body}) async {
    final headers = {'Authorization': 'Bearer ${await _token()}', 'Content-Type': 'application/json'};
    try {
      final req = http.Request(method, url)..headers.addAll(headers);
      if (body != null) req.body = jsonEncode(body);
      return await http.Response.fromStream(await _http.send(req).timeout(const Duration(seconds: 30)));
    } catch (e) {
      debugPrint('MY FINN cloud: $e');
      throw const CloudError('Pas de connexion internet.');
    }
  }

  void _check(http.Response res, {bool allow404 = false}) {
    if (res.statusCode == 200 || (allow404 && res.statusCode == 404)) return;
    if (res.statusCode == 403 || res.statusCode == 401) {
      throw const CloudError('Accès refusé par Firebase (règles de la base de données).');
    }
    throw CloudError('Erreur Firebase ${res.statusCode}.');
  }

  /// Toutes les données enregistrées en ligne pour ce compte.
  Future<Map<String, String>> download() async {
    final docs = <String, String>{};
    String? page;
    do {
      final url = Uri.parse('$_base?pageSize=300${page == null ? '' : '&pageToken=$page'}');
      final res = await _call('GET', url);
      _check(res, allow404: true);
      if (res.statusCode == 404) break;
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      for (final d in (j['documents'] as List? ?? [])) {
        final id = '${d['name']}'.split('/').last;
        final v = d['fields']?['json']?['stringValue'];
        if (v is String) docs[id] = v;
      }
      page = j['nextPageToken'];
    } while (page != null);
    return docs;
  }

  Future<bool> hasRemoteData() async => (await download()).containsKey('core');

  /// Envoie les documents qui ont changé depuis le dernier envoi, et efface les mois vidés.
  Future<void> upload() async {
    final docs = store.cloudDocs();
    for (final e in docs.entries) {
      final h = _hash(e.value);
      if (_sent[e.key] == h) continue;
      final res = await _call('PATCH', Uri.parse('$_base/${e.key}'), body: {
        'fields': {
          'json': {'stringValue': e.value},
          'updated': {'timestampValue': DateTime.now().toUtc().toIso8601String()},
        },
      });
      _check(res);
      _sent[e.key] = h;
    }
    for (final gone in _sent.keys.where((k) => !docs.containsKey(k)).toList()) {
      final res = await _call('DELETE', Uri.parse('$_base/$gone'));
      _check(res, allow404: true);
      _sent.remove(gone);
    }
  }

  /// Synchronisation complète, avec mémorisation de l'état.
  Future<void> syncNow() async {
    if (!signedIn || syncing) return;
    syncing = true;
    notifyListeners();
    try {
      await upload();
      lastSync = DateTime.now();
      lastError = null;
    } on CloudError catch (e) {
      lastError = e.message;
    } catch (e) {
      lastError = 'Erreur : $e';
    } finally {
      syncing = false;
      await _saveState();
      notifyListeners();
    }
  }

  /// Récupère les données en ligne et remplace celles du téléphone.
  Future<void> restore() async {
    final docs = await download();
    store.onSaved = null; // pas de renvoi pendant la restauration
    try {
      store.restoreFromCloud(docs);
    } finally {
      store.onSaved = schedule;
    }
    _sent = {for (final e in docs.entries) e.key: _hash(e.value)};
    lastSync = DateTime.now();
    await _saveState();
    notifyListeners();
  }

  /// Envoi groupé quelques secondes après la dernière modification.
  void schedule({Duration delay = const Duration(seconds: 3)}) {
    if (!signedIn) return;
    _timer?.cancel();
    _timer = Timer(delay, syncNow);
  }

  static String _hash(String s) {
    var h = 0x811c9dc5;
    for (final c in utf8.encode(s)) {
      h = ((h ^ c) * 0x01000193) & 0xFFFFFFFF;
    }
    return '${s.length}-${h.toRadixString(16)}';
  }
}

final Cloud cloud = Cloud(store);
