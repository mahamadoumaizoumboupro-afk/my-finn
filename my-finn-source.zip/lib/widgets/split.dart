import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../screens/tx_form.dart' show ThousandsFormatter;
import 'ui.dart';

/// Une ligne « compte · montant · frais » d'un paiement en plusieurs parts.
class SplitRow {
  int? accountId;
  final amount = TextEditingController();
  final fee = TextEditingController();
  SplitRow([this.accountId, int? a, int f = 0]) {
    if (a != null) amount.text = num0(a);
    if (f > 0) fee.text = num0(f);
  }
  int get value => parseAmount(amount.text) ?? 0;
  int get feeValue => parseAmount(fee.text) ?? 0;
}

/// Répartir un montant sur plusieurs comptes (avec frais si [fees]).
class SplitEditor extends StatefulWidget {
  final List<SplitRow> rows;
  final TextEditingController total;
  final List<Account> accounts;
  final bool fees;
  final bool income;
  const SplitEditor({
    super.key,
    required this.rows,
    required this.total,
    required this.accounts,
    this.fees = true,
    this.income = false,
  });

  /// Message d'erreur, ou null si tout est bien réparti.
  static String? check(List<SplitRow> rows, int total) {
    if (rows.any((r) => r.accountId == null)) {
      return 'Choisis un compte pour chaque part.';
    }
    if (rows.any((r) => r.value <= 0)) return 'Mets un montant à chaque part.';
    final ids = rows.map((r) => r.accountId).toSet();
    if (ids.length != rows.length) return 'Un compte est en double.';
    final rest = total - rows.fold(0, (x, r) => x + r.value);
    if (rest > 0) return 'Il reste ${num0(rest)} à répartir.';
    if (rest < 0) return 'Les parts dépassent le total de ${num0(-rest)}.';
    return null;
  }

  static List<TxPart> parts(List<SplitRow> rows) => [
    for (final r in rows) TxPart(r.accountId!, r.value, r.feeValue),
  ];

  @override
  State<SplitEditor> createState() => _SplitEditorState();
}

class _SplitEditorState extends State<SplitEditor> {
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: Listenable.merge([
      widget.total,
      for (final r in widget.rows) ...[r.amount, r.fee],
    ]),
    builder: (context, _) {
      final total = parseAmount(widget.total.text) ?? 0;
      final sum = widget.rows.fold(0, (x, r) => x + r.value);
      final fees = widget.rows.fold(0, (x, r) => x + r.feeValue);
      final rest = total - sum;
      final ok = rest == 0 && total > 0;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
            child: Row(
              children: [
                SizedBox(
                  width: 104,
                  child: Text('Compte', style: ts(11, c: C.muted)),
                ),
                Expanded(
                  child: Text('Montant', style: ts(11, c: C.muted)),
                ),
                if (widget.fees)
                  SizedBox(
                    width: 66,
                    child: Text(
                      'Frais',
                      textAlign: TextAlign.center,
                      style: ts(11, c: C.muted),
                    ),
                  ),
                const SizedBox(width: 32),
              ],
            ),
          ),
          for (final r in widget.rows) _row(r),
          GestureDetector(
            onTap: () => setState(() {
              final r = SplitRow();
              if (rest > 0) r.amount.text = num0(rest);
              widget.rows.add(r);
            }),
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: C.primary.withValues(alpha: 0.5)),
              ),
              child: Text(
                '+ Ajouter un compte',
                textAlign: TextAlign.center,
                style: ts(14, w: w7, c: C.primary),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: (ok ? C.income : C.warn).withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    ok
                        ? '✓ Tout est réparti'
                        : rest > 0
                        ? 'Reste à répartir'
                        : 'Les parts dépassent le total',
                    style: ts(14, w: w8, c: ok ? C.income : C.warn),
                  ),
                ),
                Text(
                  num0(ok ? total : rest.abs()),
                  style: ts(14, w: w8, c: ok ? C.income : C.warn),
                ),
              ],
            ),
          ),
          if (fees > 0)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                widget.income
                    ? 'Arrivé sur tes comptes : ${num0(sum - fees)} (frais ${num0(fees)} retirés).'
                    : 'Total sorti de tes comptes : ${num0(sum + fees)} (dont ${num0(fees)} de frais).',
                style: ts(12, c: C.muted),
              ),
            ),
          const SizedBox(height: 14),
        ],
      );
    },
  );

  Widget _row(SplitRow r) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.fromLTRB(10, 6, 4, 6),
    decoration: BoxDecoration(
      color: glassFill,
      border: Border.all(color: glassBorder),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Row(
      children: [
        SizedBox(
          width: 100,
          child: DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              value: r.accountId,
              isExpanded: true,
              hint: Text('Compte', style: ts(13, c: C.muted)),
              dropdownColor: C.sheet,
              style: ts(13, w: w8),
              items: [
                for (final a in widget.accounts)
                  DropdownMenuItem(
                    value: a.id,
                    child: Text(a.name, overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => setState(() => r.accountId = v),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(child: _num(r.amount, '0', big: true)),
        if (widget.fees) ...[
          const SizedBox(width: 6),
          SizedBox(width: 62, child: _num(r.fee, '—')),
        ],
        SizedBox(
          width: 32,
          child: widget.rows.length > 2
              ? IconButton(
                  padding: EdgeInsets.zero,
                  icon: Icon(Icons.close_rounded, size: 18, color: C.muted),
                  onPressed: () => setState(() => widget.rows.remove(r)),
                )
              : null,
        ),
      ],
    ),
  );

  Widget _num(TextEditingController c, String hint, {bool big = false}) =>
      TextField(
        controller: c,
        keyboardType: TextInputType.number,
        inputFormatters: [ThousandsFormatter()],
        textAlign: big ? TextAlign.start : TextAlign.center,
        style: ts(big ? 16 : 13, w: big ? w8 : w6),
        decoration: InputDecoration(
          isDense: true,
          hintText: hint,
          filled: true,
          fillColor: C.text.withValues(alpha: 0.07),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 10,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      );
}
