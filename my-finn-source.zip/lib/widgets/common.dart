import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'ui.dart';

/// Reconstruit son contenu à chaque changement des données
class Watch extends StatelessWidget {
  final WidgetBuilder builder;
  const Watch(this.builder, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: store, builder: (c, _) => builder(c));
}

Future<T?> push<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute(builder: (_) => page));

/// Écran secondaire avec barre de titre
class SubPage extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final List<Widget>? actions;
  final Widget? fab;
  const SubPage({super.key, required this.title, required this.children, this.actions, this.fab});
  @override
  Widget build(BuildContext context) => Watch((context) => Scaffold(
        backgroundColor: C.bg,
        appBar: AppBar(
          backgroundColor: C.bg, foregroundColor: C.text,
          titleTextStyle: ts(18, w: w8),
          title: Text(title),
          leading: Navigator.canPop(context)
              ? Padding(padding: const EdgeInsets.all(6), child: RoundIconButton(Icons.chevron_left_rounded, onTap: () => Navigator.pop(context)))
              : null,
          actions: [...?actions, const SizedBox(width: 10)],
        ),
        floatingActionButton: fab,
        body: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 40), children: children),
      ));
}

class GradientFab extends StatelessWidget {
  final VoidCallback onTap;
  final IconData icon;
  const GradientFab({super.key, required this.onTap, this.icon = Icons.add_rounded});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 58, height: 58,
          decoration: BoxDecoration(gradient: primaryGradient, shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: C.primary.withValues(alpha: 0.4), blurRadius: 14, offset: const Offset(0, 6))]),
          child: Icon(icon, color: Colors.white, size: 30),
        ),
      );
}

(String, Color)? whoTag(Tx t) {
  if (t.type != TxType.expense) return null;
  if (t.beneficiary == Beneficiary.maison) return ('Chez moi', C.accent);
  if (t.beneficiary == Beneficiary.personne) {
    final n = switch (t.nature) { Nature.donation => 'Donation', Nature.cadeau => 'Cadeau', _ => 'Pour' };
    return ('$n · ${t.person ?? '?'}', C.warn);
  }
  return null;
}

class TxTile extends StatelessWidget {
  final Tx t;
  final VoidCallback? onTap;
  final bool last;
  const TxTile(this.t, {super.key, this.onTap, this.last = false});
  @override
  Widget build(BuildContext context) {
    final cat = store.category(t.categoryId);
    final isT = t.type == TxType.transfer;
    final icon = isT ? Icons.swap_horiz_rounded : iconFor(cat?.icon ?? 'tag');
    final color = isT ? C.transfer : Color(cat?.color ?? 0xFF7A7F99);
    final title = t.label.isNotEmpty ? t.label : cat?.name ?? (isT ? 'Transfert' : 'Opération');
    final acc = store.account(t.accountId)?.name ?? '';
    final sub = isT
        ? '$acc → ${store.account(t.toAccountId)?.name ?? ''}${t.fee > 0 ? ' · frais ${t.fee}' : ''}'
        : '${cat?.name ?? 'Sans catégorie'} · $acc';
    final who = whoTag(t);
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(border: last ? null : Border(bottom: BorderSide(color: C.border))),
        child: Row(children: [
          IconBubble(icon, color),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: ts(15, w: w7), maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(sub, style: ts(12, c: C.muted), maxLines: 1, overflow: TextOverflow.ellipsis),
              if (who != null)
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(color: who.$2.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(6)),
                  child: Text(who.$1, style: ts(11, w: w7, c: who.$2)),
                ),
            ]),
          ),
          const SizedBox(width: 8),
          MoneyText(t.amount, size: 15, flow: switch (t.type) { TxType.income => MoneyFlow.income, TxType.expense => MoneyFlow.expense, _ => MoneyFlow.transfer }),
        ]),
      ),
    );
  }
}

/// Clavier de code PIN (4 chiffres)
class PinPad extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  final bool light;
  final Widget? extra;
  const PinPad({super.key, required this.value, required this.onChanged, this.light = false, this.extra});
  @override
  Widget build(BuildContext context) {
    final fg = light ? Colors.white : C.text;
    final bg = light ? Colors.white.withValues(alpha: 0.14) : C.card;
    Widget key(String k) => Material(
          color: bg, shape: const CircleBorder(),
          child: InkWell(customBorder: const CircleBorder(), onTap: () { if (value.length < 4) onChanged(value + k); },
              child: SizedBox(width: 76, height: 76, child: Center(child: Text(k, style: ts(28, w: w7, c: fg))))),
        );
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Row(mainAxisSize: MainAxisSize.min, children: [
        for (var i = 0; i < 4; i++)
          Container(margin: const EdgeInsets.symmetric(horizontal: 9), width: 16, height: 16,
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: fg, width: 2),
                  color: i < value.length ? fg : Colors.transparent)),
      ]),
      const SizedBox(height: 36),
      SizedBox(
        width: 280,
        child: Wrap(spacing: 26, runSpacing: 16, children: [
          for (final k in ['1', '2', '3', '4', '5', '6', '7', '8', '9']) key(k),
          SizedBox(width: 76, height: 76, child: Center(child: extra)),
          key('0'),
          SizedBox(width: 76, height: 76, child: IconButton(icon: Icon(Icons.backspace_outlined, color: fg),
              onPressed: () => onChanged(value.isEmpty ? '' : value.substring(0, value.length - 1)))),
        ]),
      ),
    ]);
  }
}

String hashPin(String pin) {
  var h = 2166136261;
  for (final c in 'myfinn:$pin'.codeUnits) {
    h ^= c;
    h = (h * 16777619) & 0xffffffff;
  }
  return h.toRadixString(16);
}
