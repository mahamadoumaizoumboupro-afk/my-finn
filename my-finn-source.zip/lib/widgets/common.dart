import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../format.dart';
import '../models.dart';
import '../storage/storage.dart';
import '../store.dart';
import '../theme.dart';
import 'ui.dart';

/// Reconstruit son contenu à chaque changement des données
class Watch extends StatelessWidget {
  final WidgetBuilder builder;
  const Watch(this.builder, {super.key});
  @override
  Widget build(BuildContext context) =>
      ListenableBuilder(listenable: store, builder: (c, _) => builder(c));
}

Future<T?> push<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute(builder: (_) => page));

/// Écran secondaire avec barre de titre
class SubPage extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final List<Widget>? actions;
  final Widget? fab;
  const SubPage({
    super.key,
    required this.title,
    required this.children,
    this.actions,
    this.fab,
  });
  @override
  Widget build(BuildContext context) => Watch(
    (context) => Scaffold(
      backgroundColor: C.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: C.text,
        flexibleSpace: store.dark
            ? ClipRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(color: C.bg.withValues(alpha: 0.55)),
                ),
              )
            : Container(color: C.bg),
        titleTextStyle: ts(18, w: w8),
        title: Text(title),
        leading: Navigator.canPop(context)
            ? Padding(
                padding: const EdgeInsets.all(6),
                child: RoundIconButton(
                  Icons.chevron_left_rounded,
                  onTap: () => Navigator.pop(context),
                ),
              )
            : null,
        actions: [...?actions, const SizedBox(width: 10)],
      ),
      floatingActionButton: fab,
      body: Stack(
        children: [
          const Positioned.fill(child: Aurora()),
          ListView(
            padding: EdgeInsets.fromLTRB(
              18,
              MediaQuery.paddingOf(context).top + kToolbarHeight + 8,
              18,
              40,
            ),
            children: children,
          ),
        ],
      ),
    ),
  );
}

class GradientFab extends StatelessWidget {
  final VoidCallback onTap;
  final IconData icon;
  const GradientFab({
    super.key,
    required this.onTap,
    this.icon = Icons.add_rounded,
  });
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        gradient: primaryGradient,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: C.primary.withValues(alpha: 0.4),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Icon(icon, color: Colors.white, size: 30),
    ),
  );
}

(String, Color)? whoTag(Tx t) {
  if (t.type != TxType.expense) return null;
  if (t.beneficiary == Beneficiary.maison) return ('Chez moi', C.accent);
  if (t.beneficiary == Beneficiary.personne) {
    final n = switch (t.nature) {
      Nature.donation => 'Donation',
      Nature.cadeau => 'Cadeau',
      _ => 'Pour',
    };
    return ('$n · ${t.person ?? '?'}', C.warn);
  }
  return null;
}

class TxTile extends StatelessWidget {
  final Tx t;
  final VoidCallback? onTap;
  final bool last;
  const TxTile(this.t, {super.key, this.onTap, this.last = false});
  @override
  Widget build(BuildContext context) {
    final cat = store.category(t.categoryId);
    final isT = t.type == TxType.transfer;
    final icon = isT ? Icons.swap_horiz_rounded : iconFor(cat?.icon ?? 'tag');
    final title = t.label.isNotEmpty
        ? t.label
        : cat?.name ?? (isT ? 'Transfert' : 'Opération');
    final acc = store.account(t.accountId)?.name ?? '';
    final sub = isT
        ? '$acc → ${store.account(t.toAccountId)?.name ?? ''}${t.fee > 0 ? ' · frais ${t.fee}' : ''}'
        : '${cat?.name ?? 'Sans catégorie'} · $acc';
    final who = whoTag(t);
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
          border: last ? null : Border(bottom: BorderSide(color: C.border)),
        ),
        child: Row(
          children: [
            IconBubble(
              t.adjust ? Icons.help_outline_rounded : icon,
              t.adjust ? C.warn : C.transfer,
              size: 40,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          title,
                          style: ts(15, w: w7),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (t.adjust) ...[
                        const SizedBox(width: 6),
                        const EcartTag(),
                      ],
                    ],
                  ),
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          sub,
                          style: ts(12, c: C.muted),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (t.shifted) ...[
                        const SizedBox(width: 6),
                        PeriodTag(t.forMonth!),
                      ],
                    ],
                  ),
                  if (who != null)
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: who.$2.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        who.$1,
                        style: ts(11, w: w7, c: who.$2),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Text(
              switch (t.type) {
                TxType.income => '+${num0(t.amount)}',
                TxType.expense => '−${num0(t.amount)}',
                _ => num0(t.amount),
              },
              style: ts(
                15,
                w: w8,
                c: switch (t.type) {
                  TxType.income => C.income,
                  TxType.expense => C.text,
                  _ => C.muted,
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Choix du compte : tous les comptes visibles d'un coup (3 par ligne), avec
/// logo et solde. Les comptes les plus utilisés passent devant.
class AccountPicker extends StatefulWidget {
  final List<Account> accounts;
  final int? selected;
  final ValueChanged<int> onChanged;
  const AccountPicker({
    super.key,
    required this.accounts,
    required this.selected,
    required this.onChanged,
  });

  @override
  State<AccountPicker> createState() => _AccountPickerState();

  static List<Account> byUsage(List<Account> l) {
    final n = <int, int>{};
    for (final t in store.txs) {
      n[t.accountId] = (n[t.accountId] ?? 0) + 1;
      if (t.toAccountId != null) {
        n[t.toAccountId!] = (n[t.toAccountId!] ?? 0) + 1;
      }
    }
    final idx = {for (var i = 0; i < l.length; i++) l[i].id: i};
    return [...l]..sort((a, b) {
      final c = (n[b.id] ?? 0).compareTo(n[a.id] ?? 0);
      return c != 0 ? c : idx[a.id]!.compareTo(idx[b.id]!);
    });
  }
}

class _AccountPickerState extends State<AccountPicker> {
  bool more = false;

  Widget _tile(Account a, double w) {
    final sel = widget.selected == a.id;
    return GestureDetector(
      onTap: () => widget.onChanged(a.id),
      child: Container(
        width: w,
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        decoration: BoxDecoration(
          color: sel ? C.primarySoft : C.card,
          borderRadius: BorderRadius.circular(cardRadius),
          border: Border.all(
            color: sel ? C.primary : C.border,
            width: sel ? 2 : 1.2,
          ),
        ),
        child: Column(
          children: [
            AccountBadge(a, size: 34),
            const SizedBox(height: 6),
            Text(
              a.name.replaceFirst(RegExp(r'^Compte\s+'), ''),
              style: ts(13, w: w7),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              num0(store.balance(a)),
              style: ts(11, w: w6, c: sel ? C.primary : C.muted),
              maxLines: 1,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final main = widget.accounts.where((a) => a.includeInTotal).toList();
    final others = widget.accounts.where((a) => !a.includeInTotal).toList();
    final open =
        more || others.any((a) => a.id == widget.selected) || main.isEmpty;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: LayoutBuilder(
        builder: (context, box) {
          const gap = 8.0;
          final w = (box.maxWidth - gap * 2) / 3;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: gap,
                runSpacing: gap,
                children: [
                  for (final a in main) _tile(a, w),
                  if (open)
                    for (final a in others) _tile(a, w),
                ],
              ),
              if (others.isNotEmpty && !open)
                TextButton.icon(
                  onPressed: () => setState(() => more = true),
                  icon: Icon(Icons.expand_more_rounded, color: C.primary),
                  label: Text(
                    'Placements et bons (${others.length})',
                    style: ts(13, w: w7, c: C.primary),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

/// Petite étiquette « ÉCART » sur les réajustements de solde.
class EcartTag extends StatelessWidget {
  const EcartTag({super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
    decoration: BoxDecoration(
      color: C.warnSoft,
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(
      'ÉCART',
      style: ts(10, w: w8, c: C.warn),
    ),
  );
}

/// Étiquette « POUR OCT. » : l'opération compte pour un autre mois que sa date.
class PeriodTag extends StatelessWidget {
  final String month;
  const PeriodTag(this.month, {super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
    decoration: BoxDecoration(
      color: C.primarySoft,
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(
      'POUR ${shortMonth(month).toUpperCase()}',
      style: ts(10, w: w8, c: C.primary),
    ),
  );
}

/// Clavier de code PIN (4 chiffres)
class PinPad extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  final bool light;
  final Widget? extra;
  const PinPad({
    super.key,
    required this.value,
    required this.onChanged,
    this.light = false,
    this.extra,
  });
  @override
  Widget build(BuildContext context) {
    final fg = light ? Colors.white : C.text;
    final bg = light ? Colors.white.withValues(alpha: 0.14) : C.card;
    Widget key(String k) => Material(
      color: bg,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: () {
          if (value.length < 4) onChanged(value + k);
        },
        child: SizedBox(
          width: 76,
          height: 76,
          child: Center(
            child: Text(
              k,
              style: ts(28, w: w7, c: fg),
            ),
          ),
        ),
      ),
    );
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 0; i < 4; i++)
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 9),
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: fg, width: 2),
                  color: i < value.length ? fg : Colors.transparent,
                ),
              ),
          ],
        ),
        const SizedBox(height: 36),
        SizedBox(
          width: 280,
          child: Wrap(
            spacing: 26,
            runSpacing: 16,
            children: [
              for (final k in ['1', '2', '3', '4', '5', '6', '7', '8', '9'])
                key(k),
              SizedBox(width: 76, height: 76, child: Center(child: extra)),
              key('0'),
              SizedBox(
                width: 76,
                height: 76,
                child: IconButton(
                  icon: Icon(Icons.backspace_outlined, color: fg),
                  onPressed: () => onChanged(
                    value.isEmpty ? '' : value.substring(0, value.length - 1),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

String hashPin(String pin) {
  var h = 2166136261;
  for (final c in 'myfinn:$pin'.codeUnits) {
    h ^= c;
    h = (h * 16777619) & 0xffffffff;
  }
  return h.toRadixString(16);
}

/// Choix de la date dans un calendrier (un appui sur le jour), avec raccourcis.
/// La valeur reste au format AAAA-MM-JJ dans [controller].
class DateField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final bool optional;
  final bool quick;
  final VoidCallback? onChanged;
  const DateField({
    super.key,
    required this.label,
    required this.controller,
    this.optional = false,
    this.quick = true,
    this.onChanged,
  });

  Future<void> _pick(BuildContext context) async {
    final initial =
        DateTime.tryParse(controller.text) ?? DateTime.parse(today());
    final d = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035, 12, 31),
      locale: const Locale('fr', 'FR'),
      helpText: label,
      cancelText: 'Annuler',
      confirmText: 'OK',
    );
    if (d != null) _set(toISO(d));
  }

  void _set(String v) {
    controller.text = v;
    onChanged?.call();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: controller,
    builder: (context, _) {
      final has = isValidISO(controller.text);
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FieldLabel(label),
            if (quick)
              Wrap(
                children: [
                  AppChip(
                    "Aujourd'hui",
                    selected: controller.text == today(),
                    onTap: () => _set(today()),
                  ),
                  AppChip(
                    'Hier',
                    selected: controller.text == yesterday(),
                    onTap: () => _set(yesterday()),
                  ),
                ],
              ),
            GestureDetector(
              onTap: () => _pick(context),
              child: Glass(
                radius: 12,
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                child: Row(
                  children: [
                    IconBubble(
                      Icons.calendar_month_rounded,
                      C.primary,
                      size: 34,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        has
                            ? '${dayLabel(controller.text)} ${controller.text.substring(0, 4)}'
                            : 'Choisir une date',
                        style: ts(16, w: w7, c: has ? C.text : C.muted),
                      ),
                    ),
                    if (optional && has)
                      IconButton(
                        icon: Icon(Icons.close_rounded, color: C.muted),
                        tooltip: 'Effacer',
                        onPressed: () => _set(''),
                      )
                    else
                      Icon(Icons.expand_more_rounded, color: C.muted),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}

/// Photo de profil (choisie dans la galerie), ou initiales sur fond bleu.
class ProfilePhoto extends StatelessWidget {
  final String name;
  final double size;
  const ProfilePhoto({super.key, required this.name, this.size = 48});
  @override
  Widget build(BuildContext context) {
    final img = photoProvider(store.settings['photo_path']);
    final initials = name
        .trim()
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .take(2)
        .map((w) => w[0].toUpperCase())
        .join();
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: C.primary,
        border: Border.all(color: C.primary, width: 2),
        image: img == null
            ? null
            : DecorationImage(image: img, fit: BoxFit.cover),
      ),
      alignment: Alignment.center,
      child: img == null
          ? Text(
              initials,
              style: ts(size * 0.32, w: w8, c: Colors.white),
            )
          : null,
    );
  }
}

/// Choisir un mois dans une liste (36 mois).
Future<String?> pickMonth(
  BuildContext context,
  String current, {
  String? start,
}) => showModalBottomSheet<String>(
  context: context,
  backgroundColor: C.sheet,
  shape: const RoundedRectangleBorder(
    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
  ),
  builder: (ctx) => SafeArea(
    child: ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.symmetric(vertical: 12),
      children: [
        for (var i = 0; i < 36; i++)
          Builder(
            builder: (ctx) {
              final m = shiftMonth(start ?? currentMonth(), -i);
              return ListTile(
                title: Text(
                  monthLabel(m),
                  style: ts(15, w: m == current ? w8 : w6),
                ),
                trailing: m == current
                    ? Icon(Icons.check_rounded, color: C.primary)
                    : null,
                onTap: () => Navigator.pop(ctx, m),
              );
            },
          ),
      ],
    ),
  ),
);

/// Petite pastille avec le nom du mois ; la toucher change de mois.
class MonthChip extends StatelessWidget {
  final String month;
  final ValueChanged<String> onChanged;
  const MonthChip({super.key, required this.month, required this.onChanged});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () async {
      final m = await pickMonth(context, month);
      if (m != null) onChanged(m);
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: C.primarySoft,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        monthLabel(month).split(' ').first,
        style: ts(12, w: w7, c: C.primary),
      ),
    ),
  );
}
