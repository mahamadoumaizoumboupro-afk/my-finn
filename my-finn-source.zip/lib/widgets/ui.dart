/// Composants visuels réutilisables de MY FINN.
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../format.dart';
import '../store.dart';
import '../models.dart';
import '../theme.dart';

/// Style de texte. Les petites tailles sont relevées d'un point pour rester lisibles ;
/// la taille de texte choisie dans les réglages du téléphone s'applique en plus.
/// Style de texte. Les titres et gros montants (17 px et plus, gras) prennent la police Inter Tight ;
/// les petits textes restent en Manrope, plus lisible.
TextStyle ts(
  double size, {
  FontWeight w = FontWeight.w500,
  Color? c,
  double? ls,
  double? h,
}) {
  final display = size >= 17 && w.value >= 700;
  return TextStyle(
    fontFamily: display ? 'InterTight' : 'Manrope',
    fontSize: size < 14 ? size + 1 : size,
    fontWeight: w,
    fontVariations: display
        ? [FontVariation('wght', w.value.toDouble())]
        : null,
    color: c ?? C.text,
    letterSpacing: display ? (ls ?? 0) - 0.3 : ls,
    height: h,
  );
}

const w6 = FontWeight.w600, w7 = FontWeight.w700, w8 = FontWeight.w800;

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final EdgeInsets margin;
  final VoidCallback? onTap;
  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.margin = const EdgeInsets.only(bottom: 14),
    this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    final box = Padding(
      padding: margin,
      child: Glass(tint: color, padding: padding, child: child),
    );
    if (onTap == null) return box;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: box,
    );
  }
}

/// Carte pleine : fond uni, fin liseré, ombre douce.
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? tint;
  const Glass({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 12,
    this.tint,
  });
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: tint ?? C.card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: tint == null ? C.border : Colors.transparent),
      boxShadow: tint == null ? softShadow : null,
    ),
    child: child,
  );
}

class GradientBox extends StatelessWidget {
  final Gradient gradient;
  final Widget child;
  final double radius;
  final EdgeInsets padding;
  final bool glow;
  const GradientBox({
    super.key,
    required this.gradient,
    required this.child,
    this.radius = 12,
    this.padding = const EdgeInsets.all(20),
    this.glow = true,
  });
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 16),
    decoration: BoxDecoration(
      gradient: gradient,
      borderRadius: BorderRadius.circular(radius),
      boxShadow: glow
          ? [
              BoxShadow(
                color: gradient.colors.first.withValues(alpha: 0.35),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ]
          : null,
    ),
    clipBehavior: Clip.antiAlias,
    child: Stack(
      children: [Padding(padding: padding, child: child)],
    ),
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 8, bottom: 10),
    child: Row(
      children: [
        Expanded(
          child: Text(text, style: ts(17, w: w8, ls: -0.2)),
        ),
        ?trailing,
      ],
    ),
  );
}

class LinkText extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const LinkText(this.text, {super.key, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Text(
      text,
      style: ts(13, w: w8, c: C.primary),
    ),
  );
}

enum MoneyFlow { income, expense, transfer, neutral }

class MoneyText extends StatelessWidget {
  final num value;
  final MoneyFlow flow;
  final double size;
  final Color? color;
  final FontWeight weight;
  const MoneyText(
    this.value, {
    super.key,
    this.flow = MoneyFlow.neutral,
    this.size = 16,
    this.color,
    this.weight = w8,
  });
  @override
  Widget build(BuildContext context) {
    final c =
        color ??
        switch (flow) {
          MoneyFlow.income => C.income,
          MoneyFlow.expense => C.expense,
          MoneyFlow.transfer => C.transfer,
          MoneyFlow.neutral => value < 0 ? C.expense : C.text,
        };
    final prefix = flow == MoneyFlow.income
        ? '+'
        : flow == MoneyFlow.expense
        ? '−'
        : '';
    return Text(
      '$prefix${money(value)}',
      style: ts(size, w: weight, c: c, ls: -0.3),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

enum BtnKind { primary, secondary, danger, ghost }

class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final IconData? icon;
  final BtnKind kind;
  const AppButton(
    this.label, {
    super.key,
    required this.onTap,
    this.icon,
    this.kind = BtnKind.primary,
  });
  @override
  Widget build(BuildContext context) {
    final fg = switch (kind) {
      BtnKind.primary => Colors.white,
      BtnKind.danger => C.expense,
      BtnKind.ghost => C.primary,
      _ => C.text,
    };
    final bg = switch (kind) {
      BtnKind.danger => C.expenseSoft,
      BtnKind.ghost => C.primarySoft,
      BtnKind.secondary => C.card,
      _ => null,
    };
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 18),
          decoration: BoxDecoration(
            gradient: kind == BtnKind.primary ? primaryGradient : null,
            color: bg,
            borderRadius: BorderRadius.circular(10),
            border: kind == BtnKind.secondary
                ? Border.all(color: C.border)
                : null,
            boxShadow: kind == BtnKind.primary
                ? [
                    BoxShadow(
                      color: C.primary.withValues(alpha: 0.35),
                      blurRadius: 14,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, color: fg, size: 19),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Text(
                  label,
                  style: ts(15, w: w7, c: fg),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FieldLabel extends StatelessWidget {
  final String text;
  const FieldLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: ts(13, w: w7, c: C.muted),
    ),
  );
}

class AppField extends StatelessWidget {
  final String? label;
  final TextEditingController controller;
  final String? hint;
  final TextInputType? keyboard;
  final int maxLines;
  final ValueChanged<String>? onChanged;
  final TextStyle? style;
  final bool obscure;
  const AppField({
    super.key,
    this.label,
    required this.controller,
    this.hint,
    this.keyboard,
    this.maxLines = 1,
    this.onChanged,
    this.style,
    this.obscure = false,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) FieldLabel(label!),
        TextField(
          controller: controller,
          keyboardType: keyboard,
          maxLines: maxLines,
          onChanged: onChanged,
          obscureText: obscure,
          autocorrect: !obscure,
          enableSuggestions: !obscure,
          style: style ?? ts(16, w: FontWeight.w500),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: ts(15, c: C.faint),
            filled: true,
            fillColor: glassFill,
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: glassBorder, width: 1.2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: C.primary, width: 1.5),
            ),
          ),
        ),
      ],
    ),
  );
}

class AppChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback? onTap;
  final Color? color;
  final IconData? icon;
  const AppChip(
    this.label, {
    super.key,
    this.selected = false,
    this.onTap,
    this.color,
    this.icon,
  });
  @override
  Widget build(BuildContext context) {
    final c = color ?? C.primary;
    return Padding(
      padding: const EdgeInsets.only(right: 8, bottom: 8),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
          decoration: BoxDecoration(
            gradient: selected ? fillGradient(c) : null,
            color: selected ? null : glassFill,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: selected ? Colors.transparent : glassBorder,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: c.withValues(alpha: 0.35),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 15, color: selected ? Colors.white : c),
                const SizedBox(width: 5),
              ],
              Text(
                label,
                style: ts(
                  13,
                  w: selected ? w7 : w6,
                  c: selected ? Colors.white : C.text,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ChipScroll extends StatelessWidget {
  final List<Widget> children;
  const ChipScroll({super.key, required this.children});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: children),
    ),
  );
}

class Segmented<T> extends StatelessWidget {
  final List<(T, String, Color?)> options;
  final T value;
  final ValueChanged<T> onChanged;
  const Segmented({
    super.key,
    required this.options,
    required this.value,
    required this.onChanged,
  });
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 16),
    padding: const EdgeInsets.all(4),
    decoration: BoxDecoration(
      color: C.card,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: C.border),
    ),
    child: Row(
      children: [
        for (final o in options)
          Expanded(
            child: GestureDetector(
              onTap: () => onChanged(o.$1),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: o.$1 == value
                      ? (o.$3 ?? C.primary)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(
                  o.$2,
                  style: ts(
                    13,
                    w: w8,
                    c: o.$1 == value ? Colors.white : C.muted,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),
      ],
    ),
  );
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color, bg;
  const RoundIconButton(
    this.icon, {
    super.key,
    required this.onTap,
    this.color,
    this.bg,
  });
  @override
  Widget build(BuildContext context) => Material(
    color: bg ?? C.card,
    shape: CircleBorder(side: BorderSide(color: C.border)),
    child: InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: SizedBox(
        width: 42,
        height: 42,
        child: Icon(icon, size: 20, color: color ?? C.text),
      ),
    ),
  );
}

class MonthSwitcher extends StatelessWidget {
  final String month;
  final ValueChanged<String> onChanged;
  const MonthSwitcher({
    super.key,
    required this.month,
    required this.onChanged,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Row(
      children: [
        RoundIconButton(
          Icons.chevron_left_rounded,
          onTap: () => onChanged(shiftMonth(month, -1)),
        ),
        Expanded(
          child: Text(
            monthLabel(month),
            textAlign: TextAlign.center,
            style: ts(17, w: w8),
          ),
        ),
        RoundIconButton(
          Icons.chevron_right_rounded,
          onTap: () => onChanged(shiftMonth(month, 1)),
        ),
      ],
    ),
  );
}

/// Pastille d'icône : fond clair de la couleur, icône de la couleur.
class IconBubble extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  const IconBubble(this.icon, this.color, {super.key, this.size = 42});
  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: color.withValues(alpha: store.dark ? 0.22 : 0.12),
      borderRadius: BorderRadius.circular(size * 0.24),
    ),
    child: Icon(icon, size: size * 0.5, color: color),
  );
}

/// Logo du compte (Coris, Nita, Amana…) ou, à défaut, son icône.
class AccountBadge extends StatelessWidget {
  final Account account;
  final double size;
  const AccountBadge(this.account, {super.key, this.size = 44});
  @override
  Widget build(BuildContext context) {
    final logo = accountLogo(account.name);
    if (logo == null)
      return IconBubble(
        accountIcon(account.type),
        Color(account.color),
        size: size,
      );
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(size * 0.24),
        border: Border.all(color: C.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(logo, fit: BoxFit.cover),
    );
  }
}

const _avatarColors = [
  Color(0xFF5B4CF5),
  Color(0xFFF04461),
  Color(0xFF12B76A),
  Color(0xFFF59E0B),
  Color(0xFF3B82F6),
  Color(0xFFEC4899),
  Color(0xFF06B6D4),
  Color(0xFF8B5CF6),
];

class Avatar extends StatelessWidget {
  final String name;
  final double size;
  const Avatar(this.name, {super.key, this.size = 42});
  @override
  Widget build(BuildContext context) {
    final words = name
        .replaceAll(RegExp(r'[^\p{L}\s]', unicode: true), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .take(2);
    final initials = words.map((w) => w[0].toUpperCase()).join();
    final c =
        _avatarColors[name.codeUnits.fold<int>(
              0,
              (h, x) => (h * 31 + x) & 0x7fffffff,
            ) %
            _avatarColors.length];
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: c.withValues(alpha: 0.15),
      ),
      child: Text(
        initials.isEmpty ? '?' : initials,
        style: ts(size * 0.36, w: w8, c: c),
      ),
    );
  }
}

class ProgressBar extends StatelessWidget {
  final num value, max;
  final Color color;
  final double height;
  const ProgressBar({
    super.key,
    required this.value,
    required this.max,
    required this.color,
    this.height = 8,
  });
  @override
  Widget build(BuildContext context) {
    final p = max > 0 ? (value / max).clamp(0.0, 1.0).toDouble() : 0.0;
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: Stack(
        children: [
          Container(height: height, color: C.border),
          FractionallySizedBox(
            widthFactor: p,
            child: Container(
              height: height,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(height),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Graphique en anneau
class Donut extends StatelessWidget {
  final List<(num, Color)> data;
  final double size, stroke;
  final Widget? center;
  const Donut({
    super.key,
    required this.data,
    this.size = 170,
    this.stroke = 22,
    this.center,
  });
  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(
      painter: _DonutPainter(data, stroke, C.border),
      child: Center(child: center),
    ),
  );
}

class _DonutPainter extends CustomPainter {
  final List<(num, Color)> data;
  final double stroke;
  final Color track;
  _DonutPainter(this.data, this.stroke, this.track);
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(
      stroke / 2,
      stroke / 2,
      size.width - stroke,
      size.height - stroke,
    );
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    canvas.drawArc(rect, 0, math.pi * 2, false, p..color = track);
    final total = data.fold<num>(0, (x, d) => x + d.$1);
    if (total <= 0) return;
    var start = -math.pi / 2;
    final gap = data.length > 1 ? 0.025 : 0.0;
    for (final d in data) {
      final sweep = d.$1 / total * math.pi * 2;
      if (sweep > gap)
        canvas.drawArc(rect, start, sweep - gap, false, p..color = d.$2);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter old) => true;
}

class EmptyState extends StatelessWidget {
  final String text;
  final IconData icon;
  const EmptyState(this.text, {super.key, this.icon = Icons.inbox_rounded});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(28),
    child: Column(
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            color: C.primarySoft,
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 30, color: C.primary),
        ),
        const SizedBox(height: 10),
        Text(
          text,
          textAlign: TextAlign.center,
          style: ts(14, w: w6, c: C.muted),
        ),
      ],
    ),
  );
}

class Hr extends StatelessWidget {
  const Hr({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: Container(height: 1, color: C.border),
  );
}

/// Page standard : grand titre + contenu défilant
class PageScaffold extends StatelessWidget {
  final String? title, subtitle;
  final List<Widget> children;
  final Widget? trailing;
  const PageScaffold({
    super.key,
    this.title,
    this.subtitle,
    required this.children,
    this.trailing,
  });
  @override
  Widget build(BuildContext context) => SafeArea(
    bottom: false,
    child: ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 120),
      children: [
        if (title != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (subtitle != null)
                        Text(
                          subtitle!,
                          style: ts(13, w: w6, c: C.muted),
                        ),
                      Text(title!, style: ts(22, w: w8, ls: -0.4)),
                    ],
                  ),
                ),
                ?trailing,
              ],
            ),
          ),
        ...children,
      ],
    ),
  );
}

Future<bool> confirmDialog(
  BuildContext context,
  String title,
  String message, {
  String ok = 'Confirmer',
  bool danger = false,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      backgroundColor: C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      title: Text(title, style: ts(18, w: w8)),
      content: Text(message, style: ts(14, c: C.muted, h: 1.4)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(c, false),
          child: Text(
            'Annuler',
            style: ts(14, w: w7, c: C.muted),
          ),
        ),
        TextButton(
          onPressed: () => Navigator.pop(c, true),
          child: Text(
            ok,
            style: ts(14, w: w8, c: danger ? C.expense : C.primary),
          ),
        ),
      ],
    ),
  );
  return r ?? false;
}

/// Confirmation forte : il faut taper [word] pour activer le bouton.
Future<bool> typedConfirmDialog(
  BuildContext context,
  String title,
  String message, {
  required String word,
  String ok = 'Confirmer',
}) async {
  final ctrl = TextEditingController();
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setD) {
        final good = ctrl.text.trim().toUpperCase() == word;
        return AlertDialog(
          backgroundColor: C.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            title,
            style: ts(18, w: w8, c: C.expense),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(message, style: ts(14, c: C.muted, h: 1.4)),
              const SizedBox(height: 16),
              Text.rich(
                TextSpan(
                  children: [
                    const TextSpan(text: 'Pour confirmer, tape '),
                    TextSpan(
                      text: word,
                      style: ts(13, w: w8, c: C.expense),
                    ),
                  ],
                ),
                style: ts(13, w: w7),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: ctrl,
                autofocus: true,
                textCapitalization: TextCapitalization.characters,
                onChanged: (_) => setD(() {}),
                style: ts(15, w: w8),
                decoration: InputDecoration(
                  hintText: word,
                  isDense: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: C.expense, width: 1.5),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: Text(
                'Annuler',
                style: ts(14, w: w7, c: C.muted),
              ),
            ),
            TextButton(
              onPressed: good ? () => Navigator.pop(c, true) : null,
              child: Text(
                ok,
                style: ts(
                  14,
                  w: w8,
                  c: good ? C.expense : C.expense.withValues(alpha: 0.35),
                ),
              ),
            ),
          ],
        );
      },
    ),
  );
  return r ?? false;
}

void toast(BuildContext context, String msg, {SnackBarAction? action}) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(
    SnackBar(
      content: Text(
        msg,
        style: ts(15, w: w6, c: Colors.white),
      ),
      behavior: SnackBarBehavior.floating,
      backgroundColor: const Color(0xFF221C4A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: Duration(seconds: action == null ? 3 : 6),
      action: action,
    ),
  );
}

/// Confirmation après un enregistrement, avec une petite vibration.
void savedToast(BuildContext context, [String msg = 'Enregistré ✅']) {
  HapticFeedback.lightImpact();
  toast(context, msg);
}

/// Supprime tout de suite, et propose « Annuler » pendant quelques secondes
/// (au lieu de demander « Êtes-vous sûr ? »).
void deleteWithUndo(BuildContext context, String msg, void Function() delete) {
  final before = store.exportJson();
  HapticFeedback.mediumImpact();
  delete();
  toast(
    context,
    msg,
    action: SnackBarAction(
      label: 'ANNULER',
      textColor: const Color(0xFF8DF0E4),
      onPressed: () {
        store.restoreBackup(before);
      },
    ),
  );
}

Widget dot(Color c, [double s = 9]) => Container(
  width: s,
  height: s,
  decoration: BoxDecoration(color: c, shape: BoxShape.circle),
);

/// Petite courbe avec zone remplie (évolution d'un solde).
class Sparkline extends StatelessWidget {
  final List<num> values;
  final Color color;
  final double height;
  const Sparkline(
    this.values, {
    super.key,
    this.color = Colors.white,
    this.height = 64,
  });
  @override
  Widget build(BuildContext context) => SizedBox(
    height: height,
    width: double.infinity,
    child: CustomPaint(painter: _SparkPainter(values, color)),
  );
}

class _SparkPainter extends CustomPainter {
  final List<num> v;
  final Color c;
  _SparkPainter(this.v, this.c);
  @override
  void paint(Canvas canvas, Size s) {
    if (v.length < 2) return;
    final d = v.map((e) => e.toDouble()).toList();
    final lo = d.reduce(math.min), hi = d.reduce(math.max);
    final span = (hi - lo).abs() < 1 ? 1.0 : hi - lo;
    Offset at(int i) => Offset(
      s.width * i / (v.length - 1),
      s.height - 6 - (v[i] - lo) / span * (s.height - 12),
    );
    final line = Path()..moveTo(at(0).dx, at(0).dy);
    for (var i = 1; i < v.length; i++) {
      final p0 = at(i - 1), p1 = at(i);
      final mx = (p0.dx + p1.dx) / 2;
      line.cubicTo(mx, p0.dy, mx, p1.dy, p1.dx, p1.dy);
    }
    final area = Path.from(line)
      ..lineTo(s.width, s.height)
      ..lineTo(0, s.height)
      ..close();
    canvas.drawPath(
      area,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [c.withValues(alpha: 0.28), c.withValues(alpha: 0)],
        ).createShader(Offset.zero & s),
    );
    canvas.drawPath(
      line,
      Paint()
        ..color = c
        ..strokeWidth = 2.4
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawCircle(at(v.length - 1), 4, Paint()..color = c);
    canvas.drawCircle(
      at(v.length - 1),
      7,
      Paint()..color = c.withValues(alpha: 0.25),
    );
  }

  @override
  bool shouldRepaint(_SparkPainter o) => o.v != v || o.c != c;
}

/// Histogramme simple : une barre par période, la dernière mise en avant.
class BarChart extends StatelessWidget {
  final List<(String, num)> data;
  final Color color;
  final double height;
  const BarChart(
    this.data, {
    super.key,
    required this.color,
    this.height = 150,
  });
  @override
  Widget build(BuildContext context) {
    final maxV = data.isEmpty
        ? 1.0
        : data.map((e) => e.$2.toDouble()).reduce(math.max);
    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < data.length; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      store.hidden ? '•' : '${(data[i].$2 / 1000).round()}k',
                      style: ts(11, w: w7, c: C.muted),
                    ),
                    const SizedBox(height: 4),
                    Flexible(
                      child: FractionallySizedBox(
                        heightFactor: maxV <= 0
                            ? 0.02
                            : math.max(0.02, data[i].$2 / maxV),
                        child: Container(
                          decoration: BoxDecoration(
                            color: data[i].$2 == maxV
                                ? color
                                : color.withValues(alpha: 0.35),
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      data[i].$1,
                      style: ts(11, w: w6, c: C.muted),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
