/// Composants visuels réutilisables de MY FINN.
library;

import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../format.dart';
import '../theme.dart';

TextStyle ts(double size, {FontWeight w = FontWeight.w500, Color? c, double? ls, double? h}) =>
    TextStyle(fontFamily: 'Manrope', fontSize: size, fontWeight: w, color: c ?? C.text, letterSpacing: ls, height: h);

const w6 = FontWeight.w600, w7 = FontWeight.w700, w8 = FontWeight.w800;

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final EdgeInsets margin;
  final VoidCallback? onTap;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.color,
      this.margin = const EdgeInsets.only(bottom: 14), this.onTap});
  @override
  Widget build(BuildContext context) {
    final box = Container(
      margin: margin,
      decoration: BoxDecoration(color: color ?? C.card, borderRadius: BorderRadius.circular(22), boxShadow: color == null ? softShadow : null),
      child: Padding(padding: padding, child: child),
    );
    if (onTap == null) return box;
    return GestureDetector(onTap: onTap, behavior: HitTestBehavior.opaque, child: box);
  }
}

class GradientBox extends StatelessWidget {
  final Gradient gradient;
  final Widget child;
  final double radius;
  final EdgeInsets padding;
  final bool glow;
  const GradientBox({super.key, required this.gradient, required this.child, this.radius = 26,
      this.padding = const EdgeInsets.all(20), this.glow = true});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          gradient: gradient, borderRadius: BorderRadius.circular(radius),
          boxShadow: glow ? [BoxShadow(color: gradient.colors.first.withValues(alpha: 0.35), blurRadius: 24, offset: const Offset(0, 10))] : null,
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(children: [
          Positioned(right: -60, top: -80, child: _bubble(220, 0.08)),
          Positioned(left: -40, bottom: -60, child: _bubble(140, 0.06)),
          Padding(padding: padding, child: child),
        ]),
      );
  Widget _bubble(double s, double a) => Container(width: s, height: s,
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: a)));
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 10),
        child: Row(children: [Expanded(child: Text(text, style: ts(17, w: w8, ls: -0.2))), ?trailing]),
      );
}

class LinkText extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const LinkText(this.text, {super.key, required this.onTap});
  @override
  Widget build(BuildContext context) =>
      GestureDetector(onTap: onTap, child: Text(text, style: ts(13, w: w8, c: C.primary)));
}

enum MoneyFlow { income, expense, transfer, neutral }

class MoneyText extends StatelessWidget {
  final num value;
  final MoneyFlow flow;
  final double size;
  final Color? color;
  final FontWeight weight;
  const MoneyText(this.value, {super.key, this.flow = MoneyFlow.neutral, this.size = 16, this.color, this.weight = w8});
  @override
  Widget build(BuildContext context) {
    final c = color ?? switch (flow) {
      MoneyFlow.income => C.income, MoneyFlow.expense => C.expense, MoneyFlow.transfer => C.transfer,
      MoneyFlow.neutral => value < 0 ? C.expense : C.text,
    };
    final prefix = flow == MoneyFlow.income ? '+' : flow == MoneyFlow.expense ? '−' : '';
    return Text('$prefix${money(value)}', style: ts(size, w: weight, c: c, ls: -0.3), maxLines: 1, overflow: TextOverflow.ellipsis);
  }
}

enum BtnKind { primary, secondary, danger, ghost }

class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final IconData? icon;
  final BtnKind kind;
  const AppButton(this.label, {super.key, required this.onTap, this.icon, this.kind = BtnKind.primary});
  @override
  Widget build(BuildContext context) {
    final fg = switch (kind) { BtnKind.primary => Colors.white, BtnKind.danger => C.expense, BtnKind.ghost => C.primary, _ => C.text };
    final bg = switch (kind) { BtnKind.danger => C.expenseSoft, BtnKind.ghost => C.primarySoft, BtnKind.secondary => C.card, _ => null };
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 18),
          decoration: BoxDecoration(
            gradient: kind == BtnKind.primary ? primaryGradient : null, color: bg,
            borderRadius: BorderRadius.circular(16),
            border: kind == BtnKind.secondary ? Border.all(color: C.border) : null,
            boxShadow: kind == BtnKind.primary ? [BoxShadow(color: C.primary.withValues(alpha: 0.35), blurRadius: 14, offset: const Offset(0, 6))] : null,
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (icon != null) ...[Icon(icon, color: fg, size: 19), const SizedBox(width: 8)],
            Flexible(child: Text(label, style: ts(15, w: w7, c: fg), textAlign: TextAlign.center)),
          ]),
        ),
      ),
    );
  }
}

class FieldLabel extends StatelessWidget {
  final String text;
  const FieldLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(text, style: ts(13, w: w7, c: C.muted)));
}

class AppField extends StatelessWidget {
  final String? label;
  final TextEditingController controller;
  final String? hint;
  final TextInputType? keyboard;
  final int maxLines;
  final ValueChanged<String>? onChanged;
  final TextStyle? style;
  final bool obscure;
  const AppField({super.key, this.label, required this.controller, this.hint, this.keyboard, this.maxLines = 1, this.onChanged, this.style,
      this.obscure = false});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (label != null) FieldLabel(label!),
          TextField(
            controller: controller, keyboardType: keyboard, maxLines: maxLines, onChanged: onChanged, obscureText: obscure,
            autocorrect: !obscure, enableSuggestions: !obscure,
            style: style ?? ts(16, w: FontWeight.w500),
            decoration: InputDecoration(
              hintText: hint, hintStyle: ts(15, c: C.faint), filled: true, fillColor: C.card, isDense: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: C.border)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: C.primary, width: 1.5)),
            ),
          ),
        ]),
      );
}

class AppChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback? onTap;
  final Color? color;
  final IconData? icon;
  const AppChip(this.label, {super.key, this.selected = false, this.onTap, this.color, this.icon});
  @override
  Widget build(BuildContext context) {
    final c = color ?? C.primary;
    return Padding(
      padding: const EdgeInsets.only(right: 8, bottom: 8),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
          decoration: BoxDecoration(color: selected ? c : C.card, borderRadius: BorderRadius.circular(999),
              border: Border.all(color: selected ? c : C.border)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, size: 15, color: selected ? Colors.white : c), const SizedBox(width: 5)],
            Text(label, style: ts(13, w: selected ? w7 : w6, c: selected ? Colors.white : C.text)),
          ]),
        ),
      ),
    );
  }
}

class ChipScroll extends StatelessWidget {
  final List<Widget> children;
  const ChipScroll({super.key, required this.children});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: children)),
      );
}

class Segmented<T> extends StatelessWidget {
  final List<(T, String, Color?)> options;
  final T value;
  final ValueChanged<T> onChanged;
  const Segmented({super.key, required this.options, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(color: C.border, borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          for (final o in options)
            Expanded(
              child: GestureDetector(
                onTap: () => onChanged(o.$1),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(color: o.$1 == value ? C.card : Colors.transparent, borderRadius: BorderRadius.circular(12),
                      boxShadow: o.$1 == value ? softShadow : null),
                  alignment: Alignment.center,
                  child: Text(o.$2, style: ts(13, w: w8, c: o.$1 == value ? (o.$3 ?? C.primary) : C.muted)),
                ),
              ),
            ),
        ]),
      );
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color, bg;
  const RoundIconButton(this.icon, {super.key, required this.onTap, this.color, this.bg});
  @override
  Widget build(BuildContext context) => Material(
        color: bg ?? C.card, shape: const CircleBorder(),
        child: InkWell(customBorder: const CircleBorder(), onTap: onTap,
            child: SizedBox(width: 42, height: 42, child: Icon(icon, size: 21, color: color ?? C.text))),
      );
}

class MonthSwitcher extends StatelessWidget {
  final String month;
  final ValueChanged<String> onChanged;
  const MonthSwitcher({super.key, required this.month, required this.onChanged});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Row(children: [
          RoundIconButton(Icons.chevron_left_rounded, onTap: () => onChanged(shiftMonth(month, -1))),
          Expanded(child: Text(monthLabel(month), textAlign: TextAlign.center, style: ts(17, w: w8))),
          RoundIconButton(Icons.chevron_right_rounded, onTap: () => onChanged(shiftMonth(month, 1))),
        ]),
      );
}

class IconBubble extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  const IconBubble(this.icon, this.color, {super.key, this.size = 42});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.13), borderRadius: BorderRadius.circular(size * 0.34)),
        child: Icon(icon, size: size * 0.5, color: color),
      );
}

const _avatarColors = [Color(0xFF5B4CF5), Color(0xFFF04461), Color(0xFF12B76A), Color(0xFFF59E0B),
  Color(0xFF3B82F6), Color(0xFFEC4899), Color(0xFF06B6D4), Color(0xFF8B5CF6)];

class Avatar extends StatelessWidget {
  final String name;
  final double size;
  const Avatar(this.name, {super.key, this.size = 42});
  @override
  Widget build(BuildContext context) {
    final words = name.replaceAll(RegExp(r'[^\p{L}\s]', unicode: true), ' ').split(RegExp(r'\s+')).where((w) => w.isNotEmpty).take(2);
    final initials = words.map((w) => w[0].toUpperCase()).join();
    final c = _avatarColors[name.codeUnits.fold<int>(0, (h, x) => (h * 31 + x) & 0x7fffffff) % _avatarColors.length];
    return Container(
      width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle, color: c.withValues(alpha: 0.15)),
      child: Text(initials.isEmpty ? '?' : initials, style: ts(size * 0.36, w: w8, c: c)),
    );
  }
}

class ProgressBar extends StatelessWidget {
  final num value, max;
  final Color color;
  final double height;
  const ProgressBar({super.key, required this.value, required this.max, required this.color, this.height = 8});
  @override
  Widget build(BuildContext context) {
    final p = max > 0 ? (value / max).clamp(0.0, 1.0).toDouble() : 0.0;
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: Stack(children: [
        Container(height: height, color: C.border),
        FractionallySizedBox(widthFactor: p, child: Container(height: height,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(height)))),
      ]),
    );
  }
}

/// Graphique en anneau
class Donut extends StatelessWidget {
  final List<(num, Color)> data;
  final double size, stroke;
  final Widget? center;
  const Donut({super.key, required this.data, this.size = 170, this.stroke = 22, this.center});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: size, height: size,
        child: CustomPaint(painter: _DonutPainter(data, stroke, C.border), child: Center(child: center)),
      );
}

class _DonutPainter extends CustomPainter {
  final List<(num, Color)> data;
  final double stroke;
  final Color track;
  _DonutPainter(this.data, this.stroke, this.track);
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(stroke / 2, stroke / 2, size.width - stroke, size.height - stroke);
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = stroke;
    canvas.drawArc(rect, 0, math.pi * 2, false, p..color = track);
    final total = data.fold<num>(0, (x, d) => x + d.$1);
    if (total <= 0) return;
    var start = -math.pi / 2;
    final gap = data.length > 1 ? 0.025 : 0.0;
    for (final d in data) {
      final sweep = d.$1 / total * math.pi * 2;
      if (sweep > gap) canvas.drawArc(rect, start, sweep - gap, false, p..color = d.$2);
      start += sweep;
    }
  }
  @override
  bool shouldRepaint(covariant _DonutPainter old) => true;
}

class EmptyState extends StatelessWidget {
  final String text;
  final IconData icon;
  const EmptyState(this.text, {super.key, this.icon = Icons.inbox_rounded});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(28),
        child: Column(children: [
          Container(width: 64, height: 64, decoration: BoxDecoration(color: C.primarySoft, shape: BoxShape.circle),
              child: Icon(icon, size: 30, color: C.primary)),
          const SizedBox(height: 10),
          Text(text, textAlign: TextAlign.center, style: ts(14, w: w6, c: C.muted)),
        ]),
      );
}

class Hr extends StatelessWidget {
  const Hr({super.key});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Container(height: 1, color: C.border));
}

/// Page standard : grand titre + contenu défilant
class PageScaffold extends StatelessWidget {
  final String? title, subtitle;
  final List<Widget> children;
  final Widget? trailing;
  const PageScaffold({super.key, this.title, this.subtitle, required this.children, this.trailing});
  @override
  Widget build(BuildContext context) => SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 120),
          children: [
            if (title != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (subtitle != null) Text(subtitle!, style: ts(13, w: w6, c: C.muted)),
                    Text(title!, style: ts(28, w: w8, ls: -0.6)),
                  ])),
                  ?trailing,
                ]),
              ),
            ...children,
          ],
        ),
      );
}

Future<bool> confirmDialog(BuildContext context, String title, String message, {String ok = 'Confirmer', bool danger = false}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      backgroundColor: C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      title: Text(title, style: ts(18, w: w8)),
      content: Text(message, style: ts(14, c: C.muted, h: 1.4)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text('Annuler', style: ts(14, w: w7, c: C.muted))),
        TextButton(onPressed: () => Navigator.pop(c, true), child: Text(ok, style: ts(14, w: w8, c: danger ? C.expense : C.primary))),
      ],
    ),
  );
  return r ?? false;
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: ts(14, w: w6, c: Colors.white)),
    behavior: SnackBarBehavior.floating, backgroundColor: const Color(0xFF221C4A),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
  ));
}

Widget dot(Color c, [double s = 9]) => Container(width: s, height: s, decoration: BoxDecoration(color: c, shape: BoxShape.circle));
