/// Cadre « Frais » : frais d'envoi, de dépôt, de retrait ou de transaction.
/// Fermé par défaut, on l'ouvre seulement quand il y a des frais.
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../format.dart';
import '../theme.dart';
import 'ui.dart';

/// Formate le montant pendant la saisie : 1479050 -> 1.479.050
class ThousandsFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    final t = digits.isEmpty ? '' : num0(int.parse(digits));
    return TextEditingValue(
      text: t,
      selection: TextSelection.collapsed(offset: t.length),
    );
  }
}

/// Champ de montant (FCFA) avec les points des milliers.
class MoneyField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final ValueChanged<String>? onChanged;
  final String hint;
  const MoneyField({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
    this.hint = '0',
  });
  @override
  Widget build(BuildContext context) => AppField(
    label: label,
    controller: controller,
    keyboard: TextInputType.number,
    hint: hint,
    formatters: [ThousandsFormatter()],
    onChanged: onChanged,
    style: ts(18, w: w8),
  );
}

class FeeBox extends StatelessWidget {
  final bool open;
  final String title;
  final String closedLabel;
  final VoidCallback onOpen;

  /// Ferme le cadre et efface les frais.
  final VoidCallback onClose;
  final List<Widget> children;

  /// Phrase qui explique l'effet sur le solde.
  final InlineSpan? result;
  const FeeBox({
    super.key,
    required this.open,
    required this.title,
    required this.onOpen,
    required this.onClose,
    required this.children,
    this.closedLabel = 'Ajouter des frais (envoi, dépôt, retrait)',
    this.result,
  });

  @override
  Widget build(BuildContext context) {
    final c = C.warn;
    if (!open) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: InkWell(
          onTap: onOpen,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: glassFill,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: glassBorder, width: 1.2),
            ),
            child: Row(
              children: [
                Icon(Icons.add_circle_outline_rounded, color: c, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(closedLabel, style: ts(14, w: w7)),
                ),
              ],
            ),
          ),
        ),
      );
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.fromLTRB(14, 8, 8, 14),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.withValues(alpha: 0.35), width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.receipt_long_rounded, color: c, size: 19),
              const SizedBox(width: 8),
              Expanded(
                child: Text(title, style: ts(15, w: w8)),
              ),
              IconButton(
                tooltip: 'Pas de frais',
                icon: Icon(Icons.close_rounded, color: C.muted, size: 20),
                onPressed: onClose,
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ...children,
                if (result != null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: glassFill,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text.rich(
                      result!,
                      style: ts(12.5, w: w6, c: C.muted, h: 1.45),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Texte en gras pour les phrases d'explication.
TextSpan boldSpan(String s) => TextSpan(
  text: s,
  style: TextStyle(fontWeight: FontWeight.w800, color: C.text),
);
