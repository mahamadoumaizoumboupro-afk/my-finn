/// Formats : montants en FCFA avec le point comme séparateur de milliers (1.479.050).
library;

String currency = 'FCFA';
bool amountsHidden = false;
String? fixedToday; // aperçu web : on se place au 30/09/2026

String num0(num n) {
  final neg = n < 0;
  final s = n.abs().round().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('.');
    b.write(s[i]);
  }
  return '${neg ? '-' : ''}$b';
}

String money(num n) =>
    amountsHidden ? '••••• $currency' : '${num0(n)} $currency';

int? parseAmount(String s) {
  final clean = s.replaceAll(RegExp(r'[\s.]'), '').replaceAll(',', '.');
  final v = double.tryParse(clean);
  return v == null ? null : v.round();
}

String pad2(int n) => n.toString().padLeft(2, '0');
String toISO(DateTime d) => '${d.year}-${pad2(d.month)}-${pad2(d.day)}';
String today() => fixedToday ?? toISO(DateTime.now());
String currentMonth() => today().substring(0, 7);
String yesterday() =>
    toISO(DateTime.parse(today()).subtract(const Duration(days: 1)));

const _months = [
  'janvier',
  'février',
  'mars',
  'avril',
  'mai',
  'juin',
  'juillet',
  'août',
  'septembre',
  'octobre',
  'novembre',
  'décembre',
];
const _days = [
  'lundi',
  'mardi',
  'mercredi',
  'jeudi',
  'vendredi',
  'samedi',
  'dimanche',
];

String monthLabel(String ym) {
  final p = ym.split('-');
  final l = _months[int.parse(p[1]) - 1];
  return '${l[0].toUpperCase()}${l.substring(1)} ${p[0]}';
}

String shiftMonth(String ym, int delta) {
  final p = ym.split('-');
  final d = DateTime(int.parse(p[0]), int.parse(p[1]) + delta, 1);
  return '${d.year}-${pad2(d.month)}';
}

String dayLabel(String iso) {
  final d = DateTime.parse(iso);
  final s = '${_days[d.weekday - 1]} ${d.day} ${_months[d.month - 1]}';
  return '${s[0].toUpperCase()}${s.substring(1)}';
}

String shortDate(String iso) =>
    '${iso.substring(8, 10)}/${iso.substring(5, 7)}/${iso.substring(0, 4)}';
bool isValidISO(String s) =>
    RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(s) && DateTime.tryParse(s) != null;
String pct(num v, num total) => total > 0
    ? '${(v / total * 100).toStringAsFixed(1).replaceAll('.', ',')} %'
    : '0 %';
