/// Toutes les données de l'app et les calculs (soldes, bilans, prêts…).
library;

import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart' show ChangeNotifier;
import 'package:flutter/services.dart' show rootBundle;
import 'format.dart';
import 'models.dart';
import 'storage/storage.dart';

class CatTotal {
  final Cat cat;
  final int total;
  CatTotal(this.cat, this.total);
}

class MonthSummary {
  int income = 0, expense = 0, fees = 0, count = 0;
  int lentOut = 0, borrowedIn = 0, repaidToMe = 0, repaidByMe = 0;
  List<CatTotal> byCategory = [];
  Map<String, int> byBeneficiary = {}; // moi, maison, personne:pour, personne:donation, personne:cadeau
  List<MapEntry<String, int>> byPerson = [];
  Map<String, Set<Nature>> personNatures = {};
  int get netOut => expense + fees + lentOut - repaidToMe + repaidByMe - borrowedIn;
}

class Template {
  final Tx tx;
  final int count;
  Template(this.tx, this.count);
}

const beneficiaryLabels = {
  'moi': 'Pour moi',
  'maison': 'Chez moi (maison)',
  'personne:pour': 'Dépenses pour d\'autres',
  'personne:donation': 'Donations',
  'personne:cadeau': 'Cadeaux',
};

class AppStore extends ChangeNotifier {
  List<Account> accounts = [];
  List<Cat> categories = [];
  List<Tx> txs = [];
  List<Debt> debts = [];
  List<Payment> payments = [];
  List<Recurring> recurring = [];
  Map<String, String> settings = {};
  bool loaded = false;
  /// false dans les tests : pas de lecture/écriture sur le disque
  bool persist = true;
  Timer? _saveTimer;

  bool get dark => settings['theme'] == 'dark';
  bool get hidden => settings['hide_amounts'] == '1';
  String? get pinHash => (settings['pin_hash'] ?? '').isEmpty ? null : settings['pin_hash'];

  int _nextId(Iterable<int> ids) => ids.isEmpty ? 1 : ids.reduce((a, b) => a > b ? a : b) + 1;

  /* ---------- Chargement / sauvegarde ---------- */
  Future<void> load({bool demo = false}) async {
    final raw = persist ? await loadData() : null;
    if (raw != null) {
      _fromJson(jsonDecode(raw));
    } else {
      _defaults();
    }
    currency = settings['currency'] ?? 'FCFA';
    amountsHidden = hidden;
    if (demo && settings['demo_imported'] != '1') {
      try {
        await importSeptember2026();
      } catch (_) {}
      settings['demo_imported'] = '1';
    }
    runRecurring();
    loaded = true;
    _save(immediate: true);
    notifyListeners();
  }

  void changed() {
    _save();
    notifyListeners();
  }

  void _save({bool immediate = false}) {
    if (!persist) return;
    _saveTimer?.cancel();
    if (immediate) {
      saveData(exportJson());
    } else {
      _saveTimer = Timer(const Duration(milliseconds: 300), () => saveData(exportJson()));
    }
  }

  String exportJson() => jsonEncode({
        'app': 'MY FINN', 'version': 1, 'date': DateTime.now().toIso8601String(),
        'accounts': accounts.map((e) => e.toJson()).toList(),
        'categories': categories.map((e) => e.toJson()).toList(),
        'transactions': txs.map((e) => e.toJson()).toList(),
        'debts': debts.map((e) => e.toJson()).toList(),
        'payments': payments.map((e) => e.toJson()).toList(),
        'recurring': recurring.map((e) => e.toJson()).toList(),
        'settings': settings,
      });

  void _fromJson(Map<String, dynamic> j) {
    List<Map<String, dynamic>> l(String k) => ((j[k] ?? []) as List).cast<Map<String, dynamic>>();
    accounts = l('accounts').map(Account.fromJson).toList();
    categories = l('categories').map(Cat.fromJson).toList();
    txs = l('transactions').map(Tx.fromJson).toList();
    debts = l('debts').map(Debt.fromJson).toList();
    payments = l('payments').map(Payment.fromJson).toList();
    recurring = l('recurring').map(Recurring.fromJson).toList();
    settings = Map<String, String>.from(j['settings'] ?? {});
  }

  void restoreBackup(String text) {
    final j = jsonDecode(text);
    if (j is! Map<String, dynamic> || j['app'] != 'MY FINN') throw const FormatException('Ce texte n\'est pas une sauvegarde MY FINN.');
    final keepPin = settings['pin_hash'];
    _fromJson(j);
    if (keepPin != null) settings['pin_hash'] = keepPin;
    currency = settings['currency'] ?? 'FCFA';
    changed();
  }

  void _defaults() {
    const cats = <(String, bool, String, int)>[
      ('Alimentation', false, 'food', 0xFFF97316), ('Recharge & téléphone', false, 'phone', 0xFF06B6D4),
      ('Habits', false, 'shirt', 0xFF8B5CF6), ('Soins & produits', false, 'sparkles', 0xFFEC4899),
      ('Entretien & lessive', false, 'water', 0xFF3B82F6), ('Transport', false, 'car', 0xFFF59E0B),
      ('Maison & équipement', false, 'home', 0xFF84CC16), ('Divertissement', false, 'game', 0xFFA855F7),
      ('Santé', false, 'health', 0xFFE11D48), ('Éducation', false, 'school', 0xFF2563EB),
      ('Abonnements', false, 'repeat', 0xFF14B8A6), ('Dons & donations', false, 'heart', 0xFFF04461),
      ('Cadeaux', false, 'gift', 0xFFD946EF), ('Épargne & tontine', false, 'savings', 0xFF10B981),
      ('Remboursement d\'emprunt', false, 'undo', 0xFF64748B), ('Frais bancaires', false, 'card', 0xFF94A3B8),
      ('Taxes & frais pro', false, 'doc', 0xFF78716C), ('Factures (eau, électricité)', false, 'bolt', 0xFFEAB308),
      ('Loyer', false, 'key', 0xFFB45309), ('Divers', false, 'more', 0xFF9CA3AF),
      ('Salaire', true, 'work', 0xFF12B76A), ('Prestations & gombo', true, 'build', 0xFF0D9488),
      ('Business & ventes', true, 'store', 0xFF16A34A), ('Cadeaux reçus', true, 'gift', 0xFF65A30D),
      ('Autres entrées', true, 'add', 0xFF84CC16),
    ];
    categories = [
      for (var i = 0; i < cats.length; i++)
        Cat(id: i + 1, name: cats[i].$1, isIncome: cats[i].$2, icon: cats[i].$3, color: cats[i].$4)
    ];
    const accs = <(String, String, bool, int)>[
      ('Compte Coris', 'banque', true, 0xFF3B82F6), ('Nita', 'mobile', true, 0xFFF59E0B),
      ('Visa Nita', 'carte', true, 0xFF8B5CF6), ('Amana', 'mobile', true, 0xFF06B6D4),
      ('Cash', 'cash', true, 0xFF12B76A), ('Bons d\'essence', 'bon', false, 0xFF64748B),
    ];
    accounts = [
      for (var i = 0; i < accs.length; i++)
        Account(id: i + 1, name: accs[i].$1, type: accs[i].$2, includeInTotal: accs[i].$3, color: accs[i].$4)
    ];
    settings = {'currency': 'FCFA'};
  }

  void setSetting(String k, String v) {
    settings[k] = v;
    if (k == 'currency') currency = v;
    if (k == 'hide_amounts') amountsHidden = v == '1';
    changed();
  }

  /* ---------- Comptes ---------- */
  List<Account> get activeAccounts => accounts.where((a) => !a.archived).toList();
  Account? account(int? id) => id == null ? null : accounts.where((a) => a.id == id).firstOrNull;

  int balance(Account a, {String? until}) {
    bool ok(String d) => until == null || d.compareTo(until) <= 0;
    var b = a.initialBalance;
    for (final t in txs) {
      if (!ok(t.date)) continue;
      if (t.accountId == a.id) {
        if (t.type == TxType.income) b += t.amount;
        if (t.type == TxType.expense || t.type == TxType.transfer) b -= t.amount + t.fee;
      }
      if (t.type == TxType.transfer && t.toAccountId == a.id) b += t.amount;
    }
    for (final d in debts) {
      if (d.accountId != a.id || !ok(d.date)) continue;
      b += d.direction == DebtDirection.lent ? -d.amount : d.amount;
    }
    for (final p in payments) {
      if (p.accountId != a.id || !ok(p.date)) continue;
      final d = debts.where((x) => x.id == p.debtId).firstOrNull;
      if (d == null) continue;
      b += d.direction == DebtDirection.lent ? p.amount : -p.amount;
    }
    return b;
  }

  int available({String? until}) =>
      activeAccounts.where((a) => a.includeInTotal).fold(0, (x, a) => x + balance(a, until: until));

  void saveAccount(Account a) {
    if (a.id == 0) {
      a.id = _nextId(accounts.map((e) => e.id));
      accounts.add(a);
    }
    changed();
  }

  /// Supprime le compte, ou l'archive s'il a déjà servi. Renvoie true si archivé.
  bool deleteAccount(int id) {
    final used = txs.any((t) => t.accountId == id || t.toAccountId == id) ||
        debts.any((d) => d.accountId == id) || payments.any((p) => p.accountId == id);
    if (used) {
      account(id)!.archived = true;
    } else {
      accounts.removeWhere((a) => a.id == id);
    }
    changed();
    return used;
  }

  /* ---------- Catégories ---------- */
  List<Cat> cats({bool? income}) =>
      categories.where((c) => !c.archived && (income == null || c.isIncome == income)).toList();
  Cat? category(int? id) => id == null ? null : categories.where((c) => c.id == id).firstOrNull;

  void saveCategory(Cat c) {
    if (c.id == 0) {
      c.id = _nextId(categories.map((e) => e.id));
      categories.add(c);
    }
    changed();
  }

  /* ---------- Opérations ---------- */
  List<Tx> transactions({String? month, TxType? type, String? search, int? accountId, int? limit}) {
    final s = search?.trim().toLowerCase();
    var l = txs.where((t) {
      if (month != null && !t.date.startsWith(month)) return false;
      if (type != null && t.type != type) return false;
      if (accountId != null && t.accountId != accountId && t.toAccountId != accountId) return false;
      if (s != null && s.isNotEmpty) {
        final hay = '${t.label} ${t.person ?? ''} ${t.note ?? ''} ${category(t.categoryId)?.name ?? ''}'.toLowerCase();
        if (!hay.contains(s)) return false;
      }
      return true;
    }).toList()
      ..sort((a, b) => b.date != a.date ? b.date.compareTo(a.date) : b.id.compareTo(a.id));
    if (limit != null && l.length > limit) l = l.sublist(0, limit);
    return l;
  }

  Tx? tx(int id) => txs.where((t) => t.id == id).firstOrNull;

  void saveTx(Tx t, {bool notify = true}) {
    if (t.id == 0) {
      t.id = _nextId(txs.map((e) => e.id));
      txs.add(t);
    }
    if (notify) changed();
  }

  void deleteTx(int id) {
    txs.removeWhere((t) => t.id == id);
    changed();
  }

  List<String> people() {
    final last = <String, String>{};
    void add(String? p, String d) {
      if (p == null || p.isEmpty) return;
      if ((last[p] ?? '').compareTo(d) < 0) last[p] = d;
    }
    for (final t in txs) {
      add(t.person, t.date);
    }
    for (final d in debts) {
      add(d.person, d.date);
    }
    final l = last.keys.toList()..sort((a, b) => last[b]!.compareTo(last[a]!));
    return l.take(30).toList();
  }

  /// Opérations fréquentes pour la saisie rapide
  List<Template> templates(TxType type) {
    final groups = <String, List<Tx>>{};
    for (final t in txs.where((t) => t.type == type && t.label.isNotEmpty)) {
      groups.putIfAbsent('${t.label.toLowerCase()}|${t.amount}|${t.categoryId}|${t.accountId}', () => []).add(t);
    }
    final l = groups.values.where((g) => g.length >= 2).map((g) {
      g.sort((a, b) => b.date.compareTo(a.date));
      return Template(g.first, g.length);
    }).toList()
      ..sort((a, b) => b.count != a.count ? b.count.compareTo(a.count) : b.tx.date.compareTo(a.tx.date));
    return l.take(10).toList();
  }

  int? guessCategory(TxType type, String label) {
    final s = label.trim().toLowerCase();
    if (s.length < 3) return null;
    final l = txs.where((t) => t.type == type && t.categoryId != null && t.label.toLowerCase().startsWith(s)).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    return l.firstOrNull?.categoryId;
  }

  /* ---------- Prêts & dettes ---------- */
  int paid(Debt d) => payments.where((p) => p.debtId == d.id).fold(0, (x, p) => x + p.amount);
  int remaining(Debt d) => d.amount - paid(d);
  bool closed(Debt d) => remaining(d) <= 0;
  Debt? debt(int id) => debts.where((d) => d.id == id).firstOrNull;

  List<Debt> debtList(DebtDirection dir, {bool showClosed = false}) {
    final l = debts.where((d) => d.direction == dir && (showClosed || !closed(d))).toList()
      ..sort((a, b) {
        final c = (closed(a) ? 1 : 0) - (closed(b) ? 1 : 0);
        return c != 0 ? c : b.date.compareTo(a.date);
      });
    return l;
  }

  int owedToMe() => debts.where((d) => d.direction == DebtDirection.lent).fold(0, (x, d) => x + (remaining(d) > 0 ? remaining(d) : 0));
  int iOwe() => debts.where((d) => d.direction == DebtDirection.borrowed).fold(0, (x, d) => x + (remaining(d) > 0 ? remaining(d) : 0));

  List<Debt> dueDebts({int days = 7}) {
    final limit = toISO(DateTime.parse(today()).add(Duration(days: days)));
    return debts.where((d) => !closed(d) && d.dueDate != null && d.dueDate!.compareTo(limit) <= 0).toList()
      ..sort((a, b) => a.dueDate!.compareTo(b.dueDate!));
  }

  void saveDebt(Debt d) {
    if (d.id == 0) {
      d.id = _nextId(debts.map((e) => e.id));
      debts.add(d);
    }
    changed();
  }

  void deleteDebt(int id) {
    payments.removeWhere((p) => p.debtId == id);
    debts.removeWhere((d) => d.id == id);
    changed();
  }

  void addPayment(Payment p, {bool notify = true}) {
    p.id = _nextId(payments.map((e) => e.id));
    payments.add(p);
    if (notify) changed();
  }

  void deletePayment(int id) {
    payments.removeWhere((p) => p.id == id);
    changed();
  }

  List<Payment> paymentsOf(int debtId) =>
      payments.where((p) => p.debtId == debtId).toList()..sort((a, b) => b.date.compareTo(a.date));

  /* ---------- Bilans ---------- */
  MonthSummary summary(String month) {
    final s = MonthSummary();
    final totals = <int, int>{};
    final persons = <String, int>{};
    for (final t in txs.where((t) => t.date.startsWith(month))) {
      final a = account(t.accountId);
      if (a == null || !a.includeInTotal) continue;
      s.count++;
      s.fees += t.fee;
      if (t.type == TxType.income) s.income += t.amount;
      if (t.type == TxType.expense) {
        s.expense += t.amount;
        final k = t.beneficiary == Beneficiary.personne ? 'personne:${t.nature.name}' : t.beneficiary.name;
        s.byBeneficiary[k] = (s.byBeneficiary[k] ?? 0) + t.amount;
        if (t.beneficiary == Beneficiary.personne && t.person != null) {
          persons[t.person!] = (persons[t.person!] ?? 0) + t.amount;
          s.personNatures.putIfAbsent(t.person!, () => {}).add(t.nature);
        }
      }
      if (t.type != TxType.transfer && t.categoryId != null) totals[t.categoryId!] = (totals[t.categoryId!] ?? 0) + t.amount;
    }
    for (final d in debts.where((d) => d.date.startsWith(month) && d.accountId != null)) {
      if (d.direction == DebtDirection.lent) {
        s.lentOut += d.amount;
      } else {
        s.borrowedIn += d.amount;
      }
    }
    for (final p in payments.where((p) => p.date.startsWith(month))) {
      final d = debt(p.debtId);
      if (d == null) continue;
      if (d.direction == DebtDirection.lent) {
        s.repaidToMe += p.amount;
      } else {
        s.repaidByMe += p.amount;
      }
    }
    s.byCategory = totals.entries.where((e) => category(e.key) != null).map((e) => CatTotal(category(e.key)!, e.value)).toList()
      ..sort((a, b) => b.total.compareTo(a.total));
    s.byPerson = persons.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return s;
  }

  /* ---------- Récurrences ---------- */
  void addRecurring(Recurring r) {
    r.id = _nextId(recurring.map((e) => e.id));
    recurring.add(r);
    changed();
  }

  /// Ajoute les opérations récurrentes dues jusqu'à aujourd'hui
  int runRecurring() {
    var added = 0;
    final now = today();
    final thisMonth = now.substring(0, 7);
    for (final r in recurring.where((r) => r.active)) {
      var m = r.lastMonth;
      while (m.compareTo(thisMonth) < 0) {
        final next = shiftMonth(m, 1);
        final p = next.split('-');
        final lastDay = DateTime(int.parse(p[0]), int.parse(p[1]) + 1, 0).day;
        final date = '$next-${pad2(r.day < lastDay ? r.day : lastDay)}';
        if (date.compareTo(now) > 0) break;
        saveTx(Tx(id: 0, type: r.type, amount: r.amount, accountId: r.accountId, categoryId: r.categoryId,
            beneficiary: r.beneficiary, person: r.person, nature: r.nature, label: r.label, note: 'Opération récurrente', date: date),
            notify: false);
        r.lastMonth = next;
        m = next;
        added++;
      }
    }
    if (added > 0) _save();
    return added;
  }

  /* ---------- Import de septembre 2026 ---------- */
  Future<void> importSeptember2026() async {
    if (txs.any((t) => t.date.startsWith('2026-09'))) throw StateError('Septembre 2026 contient déjà des opérations.');
    final seed = jsonDecode(await rootBundle.loadString('assets/seed/september2026.json')) as Map<String, dynamic>;
    int acc(String name) {
      final a = accounts.where((x) => x.name == name).firstOrNull;
      if (a != null) return a.id;
      final n = Account(id: 0, name: name);
      saveAccount(n);
      return n.id;
    }
    int? cat(String name) => categories.where((c) => c.name == name).firstOrNull?.id;
    (seed['initial'] as Map<String, dynamic>).forEach((name, v) => account(acc(name))!.initialBalance = v as int);
    for (final t in seed['transactions'] as List) {
      saveTx(Tx(id: 0, type: TxType.expense, amount: t['amount'], accountId: acc(t['account']), categoryId: cat(t['category']),
          beneficiary: Beneficiary.values.byName(t['beneficiary']), person: t['person'], nature: Nature.values.byName(t['nature']),
          label: t['label'], date: t['date']), notify: false);
    }
    for (final i in seed['incomes'] as List) {
      saveTx(Tx(id: 0, type: TxType.income, amount: i['amount'], accountId: acc(i['account']), categoryId: cat(i['category']),
          label: i['label'], date: i['date']), notify: false);
    }
    for (final t in seed['transfers'] as List) {
      saveTx(Tx(id: 0, type: TxType.transfer, amount: t['amount'], fee: t['fee'], accountId: acc(t['frm']),
          toAccountId: acc(t['to']), label: t['label'], date: t['date']), notify: false);
    }
    final ids = <String, int>{};
    for (final d in seed['debts'] as List) {
      final debt = Debt(id: _nextId(debts.map((e) => e.id)), direction: DebtDirection.lent, person: d['person'],
          amount: d['amount'], date: d['date'], accountId: acc(d['account']), label: d['label']);
      debts.add(debt);
      ids[d['person']] = debt.id;
    }
    for (final d in seed['extraDebts'] as List) {
      debts.add(Debt(id: _nextId(debts.map((e) => e.id)), direction: DebtDirection.lent, person: d['person'],
          amount: d['amount'], date: d['date'], label: d['label']));
    }
    for (final p in seed['payments'] as List) {
      final id = ids[p['person']];
      if (id != null) addPayment(Payment(id: 0, debtId: id, amount: p['amount'], date: p['date'], accountId: acc(p['account'])), notify: false);
    }
    changed();
  }

  void resetAll() {
    txs.clear();
    debts.clear();
    payments.clear();
    recurring.clear();
    for (final a in accounts) {
      a.initialBalance = 0;
    }
    changed();
  }

  /* ---------- Rapport du mois au format "Trésorerie" ---------- */
  String monthReport(String month) {
    final p = month.split('-');
    final lastDay = DateTime(int.parse(p[0]), int.parse(p[1]) + 1, 0).day;
    final end = '$month-${pad2(lastDay)}';
    String dm(String d) => '${d.substring(8, 10)}/${d.substring(5, 7)}';
    final s = summary(month);
    final b = StringBuffer();
    final avail = available(until: end);
    b.writeln('# Trésorerie - ${monthLabel(month).toLowerCase()}\n');
    b.writeln('Montants en $currency, séparateur de milliers = point. Généré par MY FINN.\n');
    b.writeln('## Soldes au ${dm(end)}\n\n| Compte | Montant |\n|---|---|');
    for (final a in activeAccounts.where((a) => a.includeInTotal)) {
      b.writeln('| ${a.name} | ${num0(balance(a, until: end))} |');
    }
    b.writeln('| **Disponible** | **${num0(avail)}** |');
    for (final a in activeAccounts.where((a) => !a.includeInTotal)) {
      b.writeln('| ${a.name} (hors disponible) | ${num0(balance(a, until: end))} |');
    }
    final rows = <(String, String, String, int)>[];
    for (final t in txs.where((t) => t.date.startsWith(month))) {
      final a = account(t.accountId)?.name ?? '';
      if (t.type == TxType.transfer) {
        rows.add((t.date, 'Transfert $a vers ${account(t.toAccountId)?.name}', '', t.fee));
      } else {
        final who = t.type == TxType.income ? '' : t.beneficiary == Beneficiary.moi ? 'Moi'
            : t.beneficiary == Beneficiary.maison ? 'Chez moi'
            : '${t.person}${t.nature == Nature.pour ? '' : ' ${t.nature.name}'}';
        final label = t.label.isNotEmpty ? t.label : category(t.categoryId)?.name ?? 'Opération';
        rows.add((t.date, '$label · $a', who, t.type == TxType.income ? -t.amount : t.amount));
      }
    }
    for (final d in debts.where((d) => d.direction == DebtDirection.lent && d.accountId != null && d.date.startsWith(month))) {
      rows.add((d.date, 'Prêt ${d.person} · ${account(d.accountId)?.name}', '${d.person} prêt', d.amount));
    }
    for (final pm in payments.where((p) => p.date.startsWith(month))) {
      final d = debt(pm.debtId);
      if (d == null || d.direction != DebtDirection.lent) continue;
      rows.add((pm.date, 'Remboursement prêt ${d.person} · ${account(pm.accountId)?.name ?? ''}', d.person, -pm.amount));
    }
    rows.sort((a, b) => a.$1.compareTo(b.$1));
    b.writeln('\n## Mouvements\n\n| Date | Mouvement | Pour qui | Montant |\n|---|---|---|---|');
    for (final r in rows) {
      b.writeln('| ${dm(r.$1)} | ${r.$2} | ${r.$3} | ${r.$4 < 0 ? '+ ${num0(-r.$4)}' : num0(r.$4)} |');
    }
    b.writeln('| Total | ${rows.length} lignes | | |');
    b.writeln('\n## Entrées\n\n| Date | Entrée | Compte | Montant |\n|---|---|---|---|');
    for (final t in transactions(month: month, type: TxType.income).reversed) {
      b.writeln('| ${dm(t.date)} | ${t.label} | ${account(t.accountId)?.name} | ${num0(t.amount)} |');
    }
    b.writeln('| **Total** | | | **${num0(s.income)}** |');
    b.writeln('\n## Répartition des dépenses\n\n| Pour qui | Montant | Part |\n|---|---|---|');
    for (final k in beneficiaryLabels.keys.where(s.byBeneficiary.containsKey)) {
      b.writeln('| ${beneficiaryLabels[k]} | ${num0(s.byBeneficiary[k]!)} | ${pct(s.byBeneficiary[k]!, s.expense)} |');
    }
    b.writeln('\n| Catégorie | Montant |\n|---|---|');
    for (final c in s.byCategory.where((c) => !c.cat.isIncome)) {
      b.writeln('| ${c.cat.name} | ${num0(c.total)} |');
    }
    b.writeln('\n## Totaux\n');
    b.writeln('- Entrées : ${num0(s.income)}');
    b.writeln('- Dépenses : ${num0(s.expense + s.fees)}');
    b.writeln('- Prêts accordés : ${num0(s.lentOut)} · remboursements reçus : ${num0(s.repaidToMe)}');
    b.writeln('- Sorties nettes (dépenses + prêts − remboursements) : ${num0(s.netOut)}');
    b.writeln('- Disponible au ${dm(end)} : ${num0(avail)}');
    b.writeln('- Créances en cours : ${num0(owedToMe())} · Dettes en cours : ${num0(iOwe())}');
    return b.toString();
  }
}

final store = AppStore();
