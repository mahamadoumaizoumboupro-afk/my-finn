/// Toutes les données de l'app et les calculs (soldes, bilans, prêts…).
library;

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart' show ChangeNotifier;
import 'package:flutter/services.dart' show rootBundle;

import 'format.dart';
import 'models.dart';
import 'storage/storage.dart';

class CatTotal {
  final Cat cat;
  final int total;
  CatTotal(this.cat, this.total);
}

class MonthSummary {
  int income = 0, expense = 0, fees = 0, taxes = 0, count = 0;
  int lentOut = 0, borrowedIn = 0, repaidToMe = 0, repaidByMe = 0;
  List<CatTotal> byCategory = [];
  Map<String, int> byBeneficiary =
      {}; // moi, maison, personne:pour, personne:donation, personne:cadeau
  List<MapEntry<String, int>> byPerson = [];
  Map<String, Set<Nature>> personNatures = {};
  int get netOut =>
      expense + fees + lentOut - repaidToMe + repaidByMe - borrowedIn;
}

/// Revenus d'un mois : historique noté à part, ou calculé à partir des entrées saisies.
class IncomeMonth {
  final String month;
  final bool fromHistory;
  int gross = 0, tax = 0;
  final Map<String, int> bySource = {};
  IncomeMonth(this.month, this.fromHistory);
  int get net => gross - tax;
}

/// Bilan d'une année : entrées (historique compris) et dépenses notées, mois par mois.
class YearSummary {
  final String year;
  final Map<String, int> income = {}; // AAAA-MM -> net
  final Map<String, int> expense =
      {}; // AAAA-MM -> dépenses + frais (mois notés seulement)
  final Map<String, int> bySource = {}; // brut
  String? firstExpenseMonth; // premier mois où des dépenses sont notées
  YearSummary(this.year);
  int get totalIncome => income.values.fold(0, (x, v) => x + v);
  int get totalExpense => expense.values.fold(0, (x, v) => x + v);
  bool get hasExpenses => expense.isNotEmpty;
  List<String> get months => {...income.keys, ...expense.keys}.toList()..sort();
}

/// Tout ce que je possède : disponible + placements + créances − dettes.
class Avoirs {
  int disponible = 0, creances = 0, dettes = 0;
  final List<(Account, int)> horsDisponible = [];
  int get placements => horsDisponible.fold(0, (x, e) => x + e.$2);
  int get total => disponible + placements + creances - dettes;
}

class Template {
  final Tx tx;
  final int count;
  Template(this.tx, this.count);
}

const beneficiaryLabels = {
  'moi': 'Pour moi',
  'maison': 'Chez moi (maison)',
  'personne:pour': 'Dépenses pour d\'autres',
  'personne:donation': 'Donations',
  'personne:cadeau': 'Cadeaux',
};

class AppStore extends ChangeNotifier {
  List<Account> accounts = [];
  List<Cat> categories = [];
  List<Tx> txs = [];
  List<Debt> debts = [];
  List<Payment> payments = [];
  List<Recurring> recurring = [];
  List<HistIncome> history = [];
  Map<String, String> settings = {};
  bool loaded = false;

  /// false dans les tests : pas de lecture/écriture sur le disque
  bool persist = true;
  Timer? _saveTimer;

  /// Appelé après chaque enregistrement sur le téléphone (sauvegarde en ligne).
  void Function()? onSaved;

  bool get dark => settings['theme'] == 'dark';
  bool get hidden => settings['hide_amounts'] == '1';
  String? get pinHash =>
      (settings['pin_hash'] ?? '').isEmpty ? null : settings['pin_hash'];

  int _nextId(Iterable<int> ids) =>
      ids.isEmpty ? 1 : ids.reduce((a, b) => a > b ? a : b) + 1;

  /* ---------- Chargement / sauvegarde ---------- */
  Future<void> load({bool demo = false}) async {
    final raw = persist ? await loadData() : null;
    if (raw != null) {
      _fromJson(jsonDecode(raw));
    } else {
      _defaults();
    }
    currency = settings['currency'] ?? 'FCFA';
    amountsHidden = hidden;
    if (demo && settings['demo_imported'] != '1') {
      try {
        await importHistory();
      } catch (_) {}
      settings['demo_imported'] = '1';
    }
    runRecurring();
    loaded = true;
    _save(immediate: true);
    notifyListeners();
  }

  void changed() {
    _save();
    notifyListeners();
  }

  void _save({bool immediate = false}) {
    if (!persist) return;
    _saveTimer?.cancel();
    Future<void> write() async {
      await saveData(exportJson());
      onSaved?.call();
    }

    if (immediate) {
      write();
    } else {
      _saveTimer = Timer(const Duration(milliseconds: 300), write);
    }
  }

  /* ---------- Sauvegarde en ligne : découpage en documents ---------- */
  /// Réglages propres à ce téléphone, jamais envoyés en ligne.
  static const localOnlySettings = {'pin_hash', 'demo_imported', 'photo_path'};

  bool get isEmpty => txs.isEmpty && debts.isEmpty;

  /// 'core' = comptes, catégories, prêts, réglages ; 'tx-AAAA-MM' = opérations d'un mois.
  /// Chaque document reste petit (limite Firestore : 1 Mo).
  Map<String, String> cloudDocs() {
    final docs = <String, String>{
      'core': jsonEncode({
        'accounts': accounts.map((e) => e.toJson()).toList(),
        'categories': categories.map((e) => e.toJson()).toList(),
        'debts': debts.map((e) => e.toJson()).toList(),
        'payments': payments.map((e) => e.toJson()).toList(),
        'recurring': recurring.map((e) => e.toJson()).toList(),
        'history': history.map((e) => e.toJson()).toList(),
        'settings': {
          for (final e in settings.entries)
            if (!localOnlySettings.contains(e.key)) e.key: e.value,
        },
      }),
    };
    final byMonth = <String, List<Tx>>{};
    for (final t in txs) {
      byMonth
          .putIfAbsent(
            t.date.length >= 7 ? t.date.substring(0, 7) : 'autre',
            () => [],
          )
          .add(t);
    }
    for (final e in byMonth.entries) {
      docs['tx-${e.key}'] = jsonEncode(e.value.map((t) => t.toJson()).toList());
    }
    return docs;
  }

  /// Remplace les données du téléphone par celles récupérées en ligne.
  void restoreFromCloud(Map<String, String> docs) {
    final core = docs['core'];
    if (core == null) throw StateError('Aucune donnée trouvée en ligne.');
    final c = jsonDecode(core) as Map<String, dynamic>;
    final keep = {
      for (final k in localOnlySettings)
        if (settings[k] != null) k: settings[k]!,
    };
    final allTx = <dynamic>[];
    for (final e in docs.entries) {
      if (e.key.startsWith('tx-')) allTx.addAll(jsonDecode(e.value) as List);
    }
    _fromJson({...c, 'transactions': allTx});
    settings.addAll(keep);
    currency = settings['currency'] ?? 'FCFA';
    amountsHidden = hidden;
    changed();
  }

  String exportJson() => jsonEncode({
    'app': 'MY FINN',
    'version': 1,
    'date': DateTime.now().toIso8601String(),
    'accounts': accounts.map((e) => e.toJson()).toList(),
    'categories': categories.map((e) => e.toJson()).toList(),
    'transactions': txs.map((e) => e.toJson()).toList(),
    'debts': debts.map((e) => e.toJson()).toList(),
    'payments': payments.map((e) => e.toJson()).toList(),
    'recurring': recurring.map((e) => e.toJson()).toList(),
    'history': history.map((e) => e.toJson()).toList(),
    'settings': settings,
  });

  void _fromJson(Map<String, dynamic> j) {
    List<Map<String, dynamic>> l(String k) =>
        ((j[k] ?? []) as List).cast<Map<String, dynamic>>();
    accounts = l('accounts').map(Account.fromJson).toList();
    categories = l('categories').map(Cat.fromJson).toList();
    txs = l('transactions').map(Tx.fromJson).toList();
    debts = l('debts').map(Debt.fromJson).toList();
    payments = l('payments').map(Payment.fromJson).toList();
    recurring = l('recurring').map(Recurring.fromJson).toList();
    history = l('history').map(HistIncome.fromJson).toList();
    settings = Map<String, String>.from(j['settings'] ?? {});
  }

  void restoreBackup(String text) {
    final j = jsonDecode(text);
    if (j is! Map<String, dynamic> || j['app'] != 'MY FINN')
      throw const FormatException(
        'Ce texte n\'est pas une sauvegarde MY FINN.',
      );
    final keepPin = settings['pin_hash'];
    _fromJson(j);
    if (keepPin != null) settings['pin_hash'] = keepPin;
    currency = settings['currency'] ?? 'FCFA';
    changed();
  }

  void _defaults() {
    const cats = <(String, bool, String, int)>[
      ('Alimentation', false, 'food', 0xFFF97316),
      ('Recharge & téléphone', false, 'phone', 0xFF06B6D4),
      ('Habits', false, 'shirt', 0xFF8B5CF6),
      ('Soins & produits', false, 'sparkles', 0xFFEC4899),
      ('Entretien & lessive', false, 'water', 0xFF3B82F6),
      ('Transport', false, 'car', 0xFFF59E0B),
      ('Maison & équipement', false, 'home', 0xFF84CC16),
      ('Divertissement', false, 'game', 0xFFA855F7),
      ('Santé', false, 'health', 0xFFE11D48),
      ('Éducation', false, 'school', 0xFF2563EB),
      ('Abonnements', false, 'repeat', 0xFF14B8A6),
      ('Dons & donations', false, 'heart', 0xFFF04461),
      ('Cadeaux', false, 'gift', 0xFFD946EF),
      ('Épargne & tontine', false, 'savings', 0xFF10B981),
      ('Remboursement d\'emprunt', false, 'undo', 0xFF64748B),
      ('Frais bancaires', false, 'card', 0xFF94A3B8),
      ('Taxes & frais pro', false, 'doc', 0xFF78716C),
      ('Factures (eau, électricité)', false, 'bolt', 0xFFEAB308),
      ('Loyer', false, 'key', 0xFFB45309),
      ('Divers', false, 'more', 0xFF9CA3AF),
      ('Salaire', true, 'work', 0xFF12B76A),
      ('Prestations & gombo', true, 'build', 0xFF0D9488),
      ('Business & ventes', true, 'store', 0xFF16A34A),
      ('Cadeaux reçus', true, 'gift', 0xFF65A30D),
      ('Autres entrées', true, 'add', 0xFF84CC16),
    ];
    categories = [
      for (var i = 0; i < cats.length; i++)
        Cat(
          id: i + 1,
          name: cats[i].$1,
          isIncome: cats[i].$2,
          icon: cats[i].$3,
          color: cats[i].$4,
        ),
    ];
    const accs = <(String, String, bool, int)>[
      ('Compte Coris', 'banque', true, 0xFF3B82F6),
      ('Nita', 'mobile', true, 0xFFF59E0B),
      ('Visa Nita', 'carte', true, 0xFF8B5CF6),
      ('Amana', 'mobile', true, 0xFF06B6D4),
      ('Cash', 'cash', true, 0xFF12B76A),
      ('Bons d\'essence', 'bon', false, 0xFF64748B),
    ];
    accounts = [
      for (var i = 0; i < accs.length; i++)
        Account(
          id: i + 1,
          name: accs[i].$1,
          type: accs[i].$2,
          includeInTotal: accs[i].$3,
          color: accs[i].$4,
        ),
    ];
    settings = {'currency': 'FCFA'};
  }

  void setSetting(String k, String v) {
    settings[k] = v;
    if (k == 'currency') currency = v;
    if (k == 'hide_amounts') amountsHidden = v == '1';
    changed();
  }

  /* ---------- Comptes ---------- */
  List<Account> get activeAccounts =>
      accounts.where((a) => !a.archived).toList();
  Account? account(int? id) =>
      id == null ? null : accounts.where((a) => a.id == id).firstOrNull;

  int balance(Account a, {String? until}) {
    bool ok(String d) => until == null || d.compareTo(until) <= 0;
    var b = a.initialBalance;
    for (final t in txs) {
      if (!ok(t.date)) continue;
      if (t.accountId == a.id) {
        if (t.type == TxType.income) b += t.amount;
        if (t.type == TxType.expense || t.type == TxType.transfer)
          b -= t.amount + t.fee;
      }
      if (t.type == TxType.transfer && t.toAccountId == a.id) b += t.amount;
    }
    for (final d in debts) {
      if (d.accountId != a.id || !ok(d.date)) continue;
      b += d.direction == DebtDirection.lent ? -d.amount : d.amount;
    }
    for (final p in payments) {
      if (p.accountId != a.id || !ok(p.date)) continue;
      final d = debts.where((x) => x.id == p.debtId).firstOrNull;
      if (d == null) continue;
      b += d.direction == DebtDirection.lent ? p.amount : -p.amount;
    }
    return b;
  }

  int available({String? until}) => activeAccounts
      .where((a) => a.includeInTotal)
      .fold(0, (x, a) => x + balance(a, until: until));

  void saveAccount(Account a) {
    if (a.id == 0) {
      a.id = _nextId(accounts.map((e) => e.id));
      accounts.add(a);
    }
    changed();
  }

  /// Supprime le compte, ou l'archive s'il a déjà servi. Renvoie true si archivé.
  bool deleteAccount(int id) {
    final used =
        txs.any((t) => t.accountId == id || t.toAccountId == id) ||
        debts.any((d) => d.accountId == id) ||
        payments.any((p) => p.accountId == id);
    if (used) {
      account(id)!.archived = true;
    } else {
      accounts.removeWhere((a) => a.id == id);
    }
    changed();
    return used;
  }

  /* ---------- Catégories ---------- */
  List<Cat> cats({bool? income}) => categories
      .where((c) => !c.archived && (income == null || c.isIncome == income))
      .toList();
  Cat? category(int? id) =>
      id == null ? null : categories.where((c) => c.id == id).firstOrNull;

  void saveCategory(Cat c) {
    if (c.id == 0) {
      c.id = _nextId(categories.map((e) => e.id));
      categories.add(c);
    }
    changed();
  }

  /* ---------- Opérations ---------- */
  List<Tx> transactions({
    String? month,
    TxType? type,
    String? search,
    int? accountId,
    int? limit,

    /// true : filtre sur le mois choisi (« Pour quel mois ? ») au lieu de la date.
    bool byPeriod = false,
  }) {
    final s = search?.trim().toLowerCase();
    var l =
        txs.where((t) {
          if (month != null &&
              !(byPeriod ? t.period == month : t.date.startsWith(month)))
            return false;
          if (type != null && t.type != type) return false;
          if (accountId != null &&
              t.accountId != accountId &&
              t.toAccountId != accountId)
            return false;
          if (s != null && s.isNotEmpty) {
            final hay =
                '${t.label} ${t.person ?? ''} ${t.note ?? ''} ${category(t.categoryId)?.name ?? ''}'
                    .toLowerCase();
            if (!hay.contains(s)) return false;
          }
          return true;
        }).toList()..sort(
          (a, b) => b.date != a.date
              ? b.date.compareTo(a.date)
              : b.id.compareTo(a.id),
        );
    if (limit != null && l.length > limit) l = l.sublist(0, limit);
    return l;
  }

  Tx? tx(int id) => txs.where((t) => t.id == id).firstOrNull;

  void saveTx(Tx t, {bool notify = true}) {
    if (t.id == 0) {
      t.id = _nextId(txs.map((e) => e.id));
      txs.add(t);
    }
    if (notify) changed();
  }

  /* ---------- Réajustement de solde (écarts) ---------- */
  static const ecartCatName = 'Écart non noté';

  /// Catégorie « Écart non noté », créée la première fois qu'on en a besoin.
  Cat ecartCategory() {
    final c = categories
        .where((c) => !c.isIncome && c.name == ecartCatName)
        .firstOrNull;
    if (c != null) {
      c.archived = false;
      return c;
    }
    final n = Cat(
      id: _nextId(categories.map((e) => e.id)),
      name: ecartCatName,
      isIncome: false,
      icon: 'help',
      color: 0xFFE5A23B,
    );
    categories.add(n);
    return n;
  }

  /// Enregistre l'écart entre le solde de l'app et l'argent réel [real].
  /// Renvoie l'opération créée (null s'il n'y a pas d'écart).
  Tx? adjustBalance(
    Account a,
    int real, {
    int? categoryId,
    String? date,
    String? note,
  }) {
    final d = date ?? today();
    final diff = real - balance(a, until: d);
    if (diff == 0) return null;
    final expense = diff < 0;
    final t = Tx(
      id: 0,
      type: expense ? TxType.expense : TxType.income,
      amount: diff.abs(),
      accountId: a.id,
      categoryId: expense
          ? (categoryId ?? ecartCategory().id)
          : cats(income: true)
                .where((c) => c.name == 'Autres entrées')
                .firstOrNull
                ?.id,
      label: expense ? 'Écart · non noté' : 'Écart · argent en plus',
      note: (note ?? '').trim().isEmpty ? null : note!.trim(),
      date: d,
      adjust: true,
    );
    saveTx(t);
    return t;
  }

  /// Écarts du mois par compte : (compte, total signé, nombre de réajustements).
  List<(Account, int, int)> ecarts(String month) {
    final m = <int, (int, int)>{};
    for (final t in txs) {
      if (!t.adjust || !t.date.startsWith(month)) continue;
      final v = t.type == TxType.income ? t.amount : -t.amount;
      final o = m[t.accountId] ?? (0, 0);
      m[t.accountId] = (o.$1 + v, o.$2 + 1);
    }
    final l = [
      for (final e in m.entries)
        if (account(e.key) != null) (account(e.key)!, e.value.$1, e.value.$2),
    ]..sort((x, y) => x.$2.compareTo(y.$2));
    return l;
  }

  void deleteTx(int id) {
    txs.removeWhere((t) => t.id == id);
    changed();
  }

  /// Noms déjà utilisés, du plus récent au plus ancien.
  /// [spentOnly] : seulement les personnes pour qui j'ai dépensé (« Pour qui ? »).
  List<String> people({bool spentOnly = false}) {
    final last = <String, (String, int)>{};
    void add(String? p, String d, int id) {
      final n = p?.trim() ?? '';
      if (n.isEmpty) return;
      final cur = last[n];
      final c = cur == null
          ? 1
          : d != cur.$1
          ? d.compareTo(cur.$1)
          : id.compareTo(cur.$2);
      if (c > 0) last[n] = (d, id);
    }

    for (final t in txs) {
      if (spentOnly &&
          (t.type != TxType.expense || t.beneficiary != Beneficiary.personne))
        continue;
      add(t.person, t.date, t.id);
    }
    if (!spentOnly) {
      for (final d in debts) {
        add(d.person, d.date, d.id);
      }
    }
    final l = last.keys.toList()
      ..sort((a, b) {
        final x = last[a]!, y = last[b]!;
        return x.$1 != y.$1 ? y.$1.compareTo(x.$1) : y.$2.compareTo(x.$2);
      });
    return l.take(30).toList();
  }

  /// Saisie rapide : les dernières opérations différentes, la plus récente d'abord.
  List<Template> templates(TxType type) {
    final groups = <String, List<Tx>>{};
    for (final t in txs.where(
      (t) => t.type == type && t.label.isNotEmpty && !t.adjust,
    )) {
      groups
          .putIfAbsent(
            '${t.label.toLowerCase()}|${t.amount}|${t.categoryId}|${t.accountId}|${t.person ?? ''}',
            () => [],
          )
          .add(t);
    }
    int recent(Tx a, Tx b) =>
        b.date != a.date ? b.date.compareTo(a.date) : b.id.compareTo(a.id);
    final l = groups.values.map((g) {
      g.sort(recent);
      return Template(g.first, g.length);
    }).toList()..sort((a, b) => recent(a.tx, b.tx));
    return l.take(10).toList();
  }

  int? guessCategory(TxType type, String label) {
    final s = label.trim().toLowerCase();
    if (s.length < 3) return null;
    final l =
        txs
            .where(
              (t) =>
                  t.type == type &&
                  t.categoryId != null &&
                  t.label.toLowerCase().startsWith(s),
            )
            .toList()
          ..sort((a, b) => b.date.compareTo(a.date));
    return l.firstOrNull?.categoryId;
  }

  /* ---------- Prêts & dettes ---------- */
  int paid(Debt d) =>
      payments.where((p) => p.debtId == d.id).fold(0, (x, p) => x + p.amount);
  int remaining(Debt d) => d.amount - paid(d);
  bool closed(Debt d) => remaining(d) <= 0;
  Debt? debt(int id) => debts.where((d) => d.id == id).firstOrNull;

  List<Debt> debtList(DebtDirection dir, {bool showClosed = false}) {
    final l =
        debts
            .where((d) => d.direction == dir && (showClosed || !closed(d)))
            .toList()
          ..sort((a, b) {
            final c = (closed(a) ? 1 : 0) - (closed(b) ? 1 : 0);
            return c != 0 ? c : b.date.compareTo(a.date);
          });
    return l;
  }

  int owedToMe() => debts
      .where((d) => d.direction == DebtDirection.lent)
      .fold(0, (x, d) => x + (remaining(d) > 0 ? remaining(d) : 0));
  int iOwe() => debts
      .where((d) => d.direction == DebtDirection.borrowed)
      .fold(0, (x, d) => x + (remaining(d) > 0 ? remaining(d) : 0));

  List<Debt> dueDebts({int days = 7}) {
    final limit = toISO(DateTime.parse(today()).add(Duration(days: days)));
    return debts
        .where(
          (d) =>
              !closed(d) &&
              d.dueDate != null &&
              d.dueDate!.compareTo(limit) <= 0,
        )
        .toList()
      ..sort((a, b) => a.dueDate!.compareTo(b.dueDate!));
  }

  void saveDebt(Debt d) {
    if (d.id == 0) {
      d.id = _nextId(debts.map((e) => e.id));
      debts.add(d);
    }
    changed();
  }

  void deleteDebt(int id) {
    payments.removeWhere((p) => p.debtId == id);
    debts.removeWhere((d) => d.id == id);
    changed();
  }

  void addPayment(Payment p, {bool notify = true}) {
    p.id = _nextId(payments.map((e) => e.id));
    payments.add(p);
    if (notify) changed();
  }

  void deletePayment(int id) {
    payments.removeWhere((p) => p.id == id);
    changed();
  }

  List<Payment> paymentsOf(int debtId) =>
      payments.where((p) => p.debtId == debtId).toList()
        ..sort((a, b) => b.date.compareTo(a.date));

  /* ---------- Opérations rangées dans un autre mois ---------- */
  /// Opérations d'autres mois qui comptent pour [month] (ex. salaire d'octobre reçu en novembre).
  List<Tx> countedInto(String month) =>
      txs.where((t) => t.shifted && t.forMonth == month).toList()
        ..sort((a, b) => a.date.compareTo(b.date));

  /// Opérations datées dans [month] mais comptées pour un autre mois.
  List<Tx> countedElsewhere(String month) =>
      txs.where((t) => t.shifted && t.date.startsWith(month)).toList()
        ..sort((a, b) => a.date.compareTo(b.date));

  /* ---------- Bilans ---------- */
  MonthSummary summary(String month) {
    final s = MonthSummary();
    final totals = <int, int>{};
    final persons = <String, int>{};
    for (final t in txs.where((t) => t.period == month)) {
      final a = account(t.accountId);
      if (a == null || !a.includeInTotal) continue;
      s.count++;
      s.fees += t.fee;
      if (t.type == TxType.income) {
        s.income += t.amount;
        s.taxes += t.tax;
      }
      if (t.type == TxType.expense) {
        s.expense += t.amount;
        final k = t.beneficiary == Beneficiary.personne
            ? 'personne:${t.nature.name}'
            : t.beneficiary.name;
        s.byBeneficiary[k] = (s.byBeneficiary[k] ?? 0) + t.amount;
        if (t.beneficiary == Beneficiary.personne && t.person != null) {
          persons[t.person!] = (persons[t.person!] ?? 0) + t.amount;
          s.personNatures.putIfAbsent(t.person!, () => {}).add(t.nature);
        }
      }
      if (t.type != TxType.transfer && t.categoryId != null)
        totals[t.categoryId!] = (totals[t.categoryId!] ?? 0) + t.amount;
    }
    for (final d in debts.where(
      (d) => d.date.startsWith(month) && d.accountId != null,
    )) {
      if (d.direction == DebtDirection.lent) {
        s.lentOut += d.amount;
      } else {
        s.borrowedIn += d.amount;
      }
    }
    for (final p in payments.where((p) => p.date.startsWith(month))) {
      final d = debt(p.debtId);
      if (d == null) continue;
      if (d.direction == DebtDirection.lent) {
        s.repaidToMe += p.amount;
      } else {
        s.repaidByMe += p.amount;
      }
    }
    s.byCategory =
        totals.entries
            .where((e) => category(e.key) != null)
            .map((e) => CatTotal(category(e.key)!, e.value))
            .toList()
          ..sort((a, b) => b.total.compareTo(a.total));
    s.byPerson = persons.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return s;
  }

  /* ---------- Récurrences ---------- */
  void addRecurring(Recurring r) {
    r.id = _nextId(recurring.map((e) => e.id));
    recurring.add(r);
    changed();
  }

  /// Ajoute les opérations récurrentes dues jusqu'à aujourd'hui
  int runRecurring() {
    var added = 0;
    final now = today();
    final thisMonth = now.substring(0, 7);
    for (final r in recurring.where((r) => r.active)) {
      var m = r.lastMonth;
      while (m.compareTo(thisMonth) < 0) {
        final next = shiftMonth(m, 1);
        final p = next.split('-');
        final lastDay = DateTime(int.parse(p[0]), int.parse(p[1]) + 1, 0).day;
        final date = '$next-${pad2(r.day < lastDay ? r.day : lastDay)}';
        if (date.compareTo(now) > 0) break;
        saveTx(
          Tx(
            id: 0,
            type: r.type,
            amount: r.amount,
            accountId: r.accountId,
            categoryId: r.categoryId,
            beneficiary: r.beneficiary,
            person: r.person,
            nature: r.nature,
            label: r.label,
            note: 'Opération récurrente',
            date: date,
          ),
          notify: false,
        );
        r.lastMonth = next;
        m = next;
        added++;
      }
    }
    if (added > 0) _save();
    return added;
  }

  /* ---------- Revenus mois par mois ---------- */
  String incomeSource(Tx t) {
    final l = t.label.toLowerCase();
    if (l.contains('bcr') && l.contains('salaire')) return 'Salaire BCR';
    if (l.contains('abib') && l.contains('salaire'))
      return 'Salaire Abib Digit';
    return category(t.categoryId)?.name ?? 'Autres entrées';
  }

  /// Du plus ancien au plus récent : l'historique noté, puis les mois calculés à partir des entrées.
  List<IncomeMonth> incomeMonths() {
    final m = <String, IncomeMonth>{};
    for (final h in history) {
      final e = m.putIfAbsent(h.month, () => IncomeMonth(h.month, true));
      e.gross += h.amount;
      e.tax += h.tax;
      e.bySource[h.source] = (e.bySource[h.source] ?? 0) + h.amount;
    }
    final histMonths = m.keys.toSet();
    for (final t in txs.where(
      (t) => t.type == TxType.income && t.date.length >= 7,
    )) {
      final k = t.period;
      if (histMonths.contains(k)) continue;
      if (!(account(t.accountId)?.includeInTotal ?? false)) continue;
      final e = m.putIfAbsent(k, () => IncomeMonth(k, false));
      e.gross += t.amount + t.tax;
      e.tax += t.tax;
      final src = incomeSource(t);
      e.bySource[src] = (e.bySource[src] ?? 0) + t.amount + t.tax;
    }
    return m.values.toList()..sort((a, b) => a.month.compareTo(b.month));
  }

  /// Tout ce qu'une source a versé, du plus récent au plus ancien (montants bruts).
  /// Chaque ligne vient soit d'une entrée notée (tx), soit de l'historique importé (h).
  List<({String month, Tx? tx, HistIncome? h, int gross})> incomeOfSource(
    String source,
  ) {
    final out = <({String month, Tx? tx, HistIncome? h, int gross})>[];
    final histMonths = history.map((h) => h.month).toSet();
    for (final h in history.where((h) => h.source == source)) {
      out.add((month: h.month, tx: null, h: h, gross: h.amount));
    }
    for (final t in txs.where(
      (t) => t.type == TxType.income && t.date.length >= 7,
    )) {
      if (histMonths.contains(t.period)) continue;
      if (!(account(t.accountId)?.includeInTotal ?? false)) continue;
      if (incomeSource(t) != source) continue;
      out.add((month: t.period, tx: t, h: null, gross: t.amount + t.tax));
    }
    out.sort(
      (a, b) => a.month != b.month
          ? b.month.compareTo(a.month)
          : (b.tx?.date ?? '').compareTo(a.tx?.date ?? ''),
    );
    return out;
  }

  /// Entrées ou dépenses comptées dans le Bilan de [month] (mêmes règles que summary).
  List<Tx> bilanTxs(String month, TxType type) => transactions(
    month: month,
    type: type,
    byPeriod: true,
  ).where((t) => account(t.accountId)?.includeInTotal ?? false).toList();

  /// Années disponibles, de la plus ancienne à l'année en cours.
  List<String> years() {
    final now = int.parse(currentMonth().substring(0, 4));
    var first = now;
    for (final m in incomeMonths()) {
      final y = int.tryParse(m.month.substring(0, 4));
      if (y != null && y < first) first = y;
    }
    for (final t in txs) {
      final y = int.tryParse(t.date.length >= 4 ? t.date.substring(0, 4) : '');
      if (y != null && y < first) first = y;
    }
    return [for (var y = first; y <= now; y++) '$y'];
  }

  /// Bilan d'une période (mois de [from] à [to] compris, AAAA-MM).
  YearSummary rangeSummary(String from, String to, {String title = ''}) {
    final y = YearSummary(title);
    bool inRange(String m) => m.compareTo(from) >= 0 && m.compareTo(to) <= 0;
    for (final m in incomeMonths().where((m) => inRange(m.month))) {
      if (m.net != 0) y.income[m.month] = m.net;
      m.bySource.forEach((k, v) => y.bySource[k] = (y.bySource[k] ?? 0) + v);
    }
    final firstExp =
        (txs
                .where((t) => t.type == TxType.expense && t.date.length >= 7)
                .map((t) => t.period)
                .toList()
              ..sort())
            .firstOrNull;
    y.firstExpenseMonth = firstExp;
    if (firstExp != null) {
      final end = to.compareTo(currentMonth()) < 0 ? to : currentMonth();
      for (
        var m = from.compareTo(firstExp) > 0 ? from : firstExp;
        m.compareTo(end) <= 0;
        m = shiftMonth(m, 1)
      ) {
        final sm = summary(m);
        y.expense[m] = sm.expense + sm.fees;
      }
    }
    return y;
  }

  YearSummary yearSummary(String year) =>
      rangeSummary('$year-01', '$year-12', title: year);

  /// Toutes les années ensemble : les clés sont les années (AAAA).
  YearSummary allYearsSummary() {
    final all = YearSummary('Tout');
    for (final y in years()) {
      final ys = yearSummary(y);
      all.firstExpenseMonth ??= ys.firstExpenseMonth;
      if (ys.totalIncome != 0) all.income[y] = ys.totalIncome;
      if (ys.hasExpenses) all.expense[y] = ys.totalExpense;
      ys.bySource.forEach(
        (k, v) => all.bySource[k] = (all.bySource[k] ?? 0) + v,
      );
    }
    return all;
  }

  /* ---------- Avoirs ---------- */
  Avoirs avoirs() {
    final a = Avoirs()..disponible = available();
    for (final acc in activeAccounts.where((x) => !x.includeInTotal)) {
      final b = balance(acc);
      if (b != 0) a.horsDisponible.add((acc, b));
    }
    a.horsDisponible.sort((x, y) => y.$2.compareTo(x.$2));
    a.creances = owedToMe();
    a.dettes = iOwe();
    return a;
  }

  /* ---------- Import du suivi complet (export du 03/11/2026) ---------- */
  static const historyImportKey = 'suivi_2026_11_03';
  bool get historyImported => settings[historyImportKey] == 'done';

  /// Remplace toutes les opérations, prêts et dettes par ceux du fichier de suivi.
  Future<void> importHistory() async {
    final seed = jsonDecode(
      await rootBundle.loadString('assets/seed/history.json'),
    ) as Map<String, dynamic>;
    txs.clear();
    debts.clear();
    payments.clear();
    recurring.clear();
    for (final a in accounts) {
      a.initialBalance = 0;
    }
    final off = (seed['offBalance'] as List).cast<String>().toSet();
    int acc(String name) {
      final a = accounts.where((x) => x.name == name).firstOrNull;
      if (a != null) {
        a.archived = false;
        return a.id;
      }
      final placement = off.contains(name);
      final n = Account(
        id: _nextId(accounts.map((e) => e.id)),
        name: name,
        type: placement ? 'epargne' : 'autre',
        includeInTotal: !placement,
        color: placement ? 0xFF0E9F6E : 0xFF5B4CF5,
      );
      accounts.add(n);
      return n.id;
    }

    int? cat(String? name) =>
        categories.where((c) => c.name == name).firstOrNull?.id;
    (seed['initial'] as Map<String, dynamic>).forEach(
      (name, v) => account(acc(name))!.initialBalance = v as int,
    );
    var id = 1;
    for (final t in seed['transactions'] as List) {
      final income = t['type'] == 'income';
      txs.add(
        Tx(
          id: id++,
          type: income ? TxType.income : TxType.expense,
          amount: t['amount'],
          tax: t['tax'] ?? 0,
          accountId: acc(t['account']),
          categoryId: cat(t['category']),
          beneficiary: income
              ? Beneficiary.moi
              : Beneficiary.values.byName(t['beneficiary']),
          person: t['person'],
          nature: income ? Nature.pour : Nature.values.byName(t['nature']),
          label: t['label'],
          note: t['note'],
          date: t['date'],
        ),
      );
    }
    for (final t in seed['transfers'] as List) {
      txs.add(
        Tx(
          id: id++,
          type: TxType.transfer,
          amount: t['amount'],
          fee: t['fee'],
          accountId: acc(t['frm']),
          toAccountId: acc(t['to']),
          label: t['label'],
          note: t['note'],
          date: t['date'],
        ),
      );
    }
    final keys = <String, int>{};
    var did = 1;
    for (final d in seed['debts'] as List) {
      final debt = Debt(
        id: did++,
        direction: DebtDirection.values.byName(d['direction']),
        person: d['person'],
        amount: d['amount'],
        date: d['date'],
        accountId: d['account'] == null ? null : acc(d['account']),
        label: d['label'],
      );
      debts.add(debt);
      keys[d['key']] = debt.id;
    }
    var pid = 1;
    for (final p in seed['payments'] as List) {
      payments.add(
        Payment(
          id: pid++,
          debtId: keys[p['key']]!,
          amount: p['amount'],
          date: p['date'],
          accountId: acc(p['account']),
        ),
      );
    }
    history = [
      for (final h in seed['history'] as List)
        HistIncome.fromJson(h as Map<String, dynamic>),
    ];
    settings[historyImportKey] = 'done';
    changed();
  }

  void resetAll() {
    txs.clear();
    debts.clear();
    payments.clear();
    recurring.clear();
    history.clear();
    for (final a in accounts) {
      a.initialBalance = 0;
    }
    changed();
  }

  /* ---------- Rapport du mois au format "Trésorerie" ---------- */
  String monthReport(String month) {
    final p = month.split('-');
    final lastDay = DateTime(int.parse(p[0]), int.parse(p[1]) + 1, 0).day;
    final end = '$month-${pad2(lastDay)}';
    String dm(String d) => '${d.substring(8, 10)}/${d.substring(5, 7)}';
    final s = summary(month);
    final b = StringBuffer();
    final avail = available(until: end);
    b.writeln('# Trésorerie - ${monthLabel(month).toLowerCase()}\n');
    b.writeln(
      'Montants en $currency, séparateur de milliers = point. Généré par MY FINN.\n',
    );
    b.writeln('## Soldes au ${dm(end)}\n\n| Compte | Montant |\n|---|---|');
    for (final a in activeAccounts.where((a) => a.includeInTotal)) {
      b.writeln('| ${a.name} | ${num0(balance(a, until: end))} |');
    }
    b.writeln('| **Disponible** | **${num0(avail)}** |');
    for (final a in activeAccounts.where((a) => !a.includeInTotal)) {
      b.writeln(
        '| ${a.name} (hors disponible) | ${num0(balance(a, until: end))} |',
      );
    }
    final rows = <(String, String, String, int)>[];
    for (final t in txs.where((t) => t.date.startsWith(month))) {
      final a = account(t.accountId)?.name ?? '';
      if (t.type == TxType.transfer) {
        rows.add((
          t.date,
          'Transfert $a vers ${account(t.toAccountId)?.name}',
          '',
          t.fee,
        ));
      } else {
        final who = t.type == TxType.income
            ? ''
            : t.beneficiary == Beneficiary.moi
            ? 'Moi'
            : t.beneficiary == Beneficiary.maison
            ? 'Chez moi'
            : '${t.person}${t.nature == Nature.pour ? '' : ' ${t.nature.name}'}';
        final label = t.label.isNotEmpty
            ? t.label
            : category(t.categoryId)?.name ?? 'Opération';
        rows.add((
          t.date,
          '$label · $a',
          who,
          t.type == TxType.income ? -t.amount : t.amount,
        ));
      }
    }
    for (final d in debts.where(
      (d) =>
          d.direction == DebtDirection.lent &&
          d.accountId != null &&
          d.date.startsWith(month),
    )) {
      rows.add((
        d.date,
        'Prêt ${d.person} · ${account(d.accountId)?.name}',
        '${d.person} prêt',
        d.amount,
      ));
    }
    for (final pm in payments.where((p) => p.date.startsWith(month))) {
      final d = debt(pm.debtId);
      if (d == null || d.direction != DebtDirection.lent) continue;
      rows.add((
        pm.date,
        'Remboursement prêt ${d.person} · ${account(pm.accountId)?.name ?? ''}',
        d.person,
        -pm.amount,
      ));
    }
    rows.sort((a, b) => a.$1.compareTo(b.$1));
    b.writeln(
      '\n## Mouvements\n\n| Date | Mouvement | Pour qui | Montant |\n|---|---|---|---|',
    );
    for (final r in rows) {
      b.writeln(
        '| ${dm(r.$1)} | ${r.$2} | ${r.$3} | ${r.$4 < 0 ? '+ ${num0(-r.$4)}' : num0(r.$4)} |',
      );
    }
    b.writeln('| Total | ${rows.length} lignes | | |');
    b.writeln(
      '\n## Entrées\n\n| Date | Entrée | Compte | Montant |\n|---|---|---|---|',
    );
    for (final t in transactions(
      month: month,
      type: TxType.income,
      byPeriod: true,
    ).reversed) {
      b.writeln(
        '| ${dm(t.date)} | ${t.label}${t.date.startsWith(month) ? '' : ' (reçu plus tard)'} | ${account(t.accountId)?.name} | ${num0(t.amount)} |',
      );
    }
    b.writeln('| **Total** | | | **${num0(s.income)}** |');
    b.writeln(
      '\n## Répartition des dépenses\n\n| Pour qui | Montant | Part |\n|---|---|---|',
    );
    for (final k in beneficiaryLabels.keys.where(s.byBeneficiary.containsKey)) {
      b.writeln(
        '| ${beneficiaryLabels[k]} | ${num0(s.byBeneficiary[k]!)} | ${pct(s.byBeneficiary[k]!, s.expense)} |',
      );
    }
    b.writeln('\n| Catégorie | Montant |\n|---|---|');
    for (final c in s.byCategory.where((c) => !c.cat.isIncome)) {
      b.writeln('| ${c.cat.name} | ${num0(c.total)} |');
    }
    b.writeln('\n## Totaux\n');
    b.writeln(
      '- Entrées : ${num0(s.income)}${s.taxes > 0 ? ' (nettes, après ${num0(s.taxes)} de taxes)' : ''}',
    );
    b.writeln('- Dépenses : ${num0(s.expense + s.fees)}');
    b.writeln(
      '- Prêts accordés : ${num0(s.lentOut)} · remboursements reçus : ${num0(s.repaidToMe)}',
    );
    b.writeln(
      '- Sorties nettes (dépenses + prêts − remboursements) : ${num0(s.netOut)}',
    );
    b.writeln('- Disponible au ${dm(end)} : ${num0(avail)}');
    b.writeln(
      '- Créances en cours : ${num0(owedToMe())} · Dettes en cours : ${num0(iOwe())}',
    );
    return b.toString();
  }
}

final store = AppStore();
