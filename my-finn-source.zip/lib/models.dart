/// Modèle de données de MY FINN.
library;

enum TxType { income, expense, transfer }

enum Beneficiary { moi, maison, personne }

enum Nature { pour, donation, cadeau }

enum DebtDirection { lent, borrowed }

T _enum<T extends Enum>(List<T> values, Object? v, T def) =>
    values.firstWhere((e) => e.name == v, orElse: () => def);

class Account {
  int id;
  String name;
  String type; // banque, mobile, carte, cash, epargne, bon, autre
  int initialBalance;
  bool includeInTotal;
  bool archived;
  int color;

  /// Tontine touchée : date (AAAA-MM-JJ) où l'argent a été récupéré.
  String? closed;
  Account({
    required this.id,
    required this.name,
    this.type = 'autre',
    this.initialBalance = 0,
    this.includeInTotal = true,
    this.archived = false,
    this.color = 0xFF5B4CF5,
    this.closed,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type,
    'initial_balance': initialBalance,
    'include_in_total': includeInTotal,
    'archived': archived,
    'color': color,
    if (closed != null) 'closed': closed,
  };
  factory Account.fromJson(Map<String, dynamic> j) => Account(
    id: j['id'],
    name: j['name'],
    type: j['type'] ?? 'autre',
    initialBalance: j['initial_balance'] ?? 0,
    includeInTotal: j['include_in_total'] ?? true,
    archived: j['archived'] ?? false,
    closed: j['closed'],
    color: j['color'] ?? 0xFF5B4CF5,
  );
}

class Cat {
  int id;
  String name;
  bool isIncome;
  String icon;
  int color;
  int budget;
  bool archived;
  Cat({
    required this.id,
    required this.name,
    required this.isIncome,
    this.icon = 'tag',
    this.color = 0xFF7A7F99,
    this.budget = 0,
    this.archived = false,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'income': isIncome,
    'icon': icon,
    'color': color,
    'budget': budget,
    'archived': archived,
  };
  factory Cat.fromJson(Map<String, dynamic> j) => Cat(
    id: j['id'],
    name: j['name'],
    isIncome: j['income'] ?? false,
    icon: j['icon'] ?? 'tag',
    color: j['color'] ?? 0xFF7A7F99,
    budget: j['budget'] ?? 0,
    archived: j['archived'] ?? false,
  );
}

class Tx {
  int id;
  TxType type;
  int amount;

  /// Frais (envoi, dépôt, retrait, transaction). Payés par moi, ils font baisser
  /// le solde et comptent dans les dépenses (ligne « Frais »).
  int fee;

  /// Vrai si c'est l'autre personne qui a payé les frais : simple note, sans effet.
  bool feeOther;

  /// Entrée : somme ajoutée par la personne pour couvrir les frais de retrait.
  int feeExtra;

  /// Entrée : taxe ou retenue déjà déduite (le montant reçu est net). Brut = amount + tax.
  int tax;
  int accountId;
  int? toAccountId;
  int? categoryId;
  Beneficiary beneficiary;
  String? person;
  Nature nature;
  String label;
  String? note;
  String date; // AAAA-MM-JJ

  /// Réajustement de solde : écart entre le solde de l'app et l'argent réel.
  bool adjust;

  /// Trace : dépense notée après coup (mai, juin 2026), sans jour précis.
  /// Elle compte dans le Bilan de son mois, jamais dans les soldes des comptes.
  bool trace;

  /// Mois auquel l'opération se rapporte (AAAA-MM), s'il diffère du mois de la date.
  /// Ex. : salaire d'octobre reçu le 9 novembre. Le solde suit la date, le Bilan suit ce mois.
  String? forMonth;

  /// Mois utilisé par le Bilan et les analyses.
  String get period =>
      forMonth ?? (date.length >= 7 ? date.substring(0, 7) : '');

  /// Vrai si l'opération compte pour un autre mois que celui de sa date.
  bool get shifted =>
      forMonth != null && date.length >= 7 && forMonth != date.substring(0, 7);

  /// Frais réellement payés par moi (0 si c'est l'autre qui paie).
  int get myFee => feeOther ? 0 : fee;

  /// Effet sur le solde du compte de départ (+ ou −), frais compris.
  int get delta => switch (type) {
    TxType.income => amount + feeExtra - myFee,
    _ => -(amount + myFee),
  };
  Tx({
    required this.id,
    required this.type,
    required this.amount,
    this.fee = 0,
    this.feeOther = false,
    this.feeExtra = 0,
    this.tax = 0,
    required this.accountId,
    this.toAccountId,
    this.categoryId,
    this.beneficiary = Beneficiary.moi,
    this.person,
    this.nature = Nature.pour,
    this.label = '',
    this.note,
    required this.date,
    this.adjust = false,
    this.forMonth,
    this.trace = false,
    this.rKind,
    this.rOp,
    this.parts,
  });

  /// Payée (ou reçue) sur plusieurs comptes : une part par compte.
  /// amount = total des parts, fee = total des frais, accountId = 1er compte.
  List<TxPart>? parts;

  /// Recharge : genre (wifi, internet, appel) et opérateur (Airtel, Moov…).
  String? rKind, rOp;
  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type.name,
    'amount': amount,
    'fee': fee,
    if (feeOther) 'fee_other': true,
    if (feeExtra > 0) 'fee_extra': feeExtra,
    'tax': tax,
    'account_id': accountId,
    'to_account_id': toAccountId,
    'category_id': categoryId,
    'beneficiary': beneficiary.name,
    'person': person,
    'nature': nature.name,
    'label': label,
    'note': note,
    'date': date,
    if (adjust) 'adjust': true,
    if (shifted) 'for_month': forMonth,
    if (trace) 'trace': true,
    if (rKind != null) 'rkind': rKind,
    if (rOp != null) 'rop': rOp,
    if (parts != null) 'parts': [for (final p in parts!) p.toJson()],
  };
  factory Tx.fromJson(Map<String, dynamic> j) => Tx(
    id: j['id'],
    type: _enum(TxType.values, j['type'], TxType.expense),
    amount: j['amount'],
    fee: j['fee'] ?? 0,
    feeOther: j['fee_other'] == true,
    feeExtra: j['fee_extra'] ?? 0,
    tax: j['tax'] ?? 0,
    accountId: j['account_id'],
    toAccountId: j['to_account_id'],
    categoryId: j['category_id'],
    beneficiary: _enum(Beneficiary.values, j['beneficiary'], Beneficiary.moi),
    person: j['person'],
    nature: _enum(Nature.values, j['nature'], Nature.pour),
    label: j['label'] ?? '',
    note: j['note'],
    date: j['date'],
    adjust: j['adjust'] == true,
    forMonth: j['for_month'],
    trace: j['trace'] == true,
    rKind: j['rkind'],
    rOp: j['rop'],
    parts: (j['parts'] as List?)
        ?.map((e) => TxPart.fromJson(Map<String, dynamic>.from(e)))
        .toList(),
  );
}

/// Une part d'une opération payée (ou reçue) sur plusieurs comptes.
class TxPart {
  int accountId, amount, fee;
  TxPart(this.accountId, this.amount, [this.fee = 0]);
  Map<String, dynamic> toJson() => {
    'a': accountId,
    'm': amount,
    if (fee > 0) 'f': fee,
  };
  factory TxPart.fromJson(Map<String, dynamic> j) =>
      TxPart(j['a'], j['m'], j['f'] ?? 0);
}

class Debt {
  int id;
  DebtDirection direction;
  String person;
  int amount;
  String date;
  String? dueDate;
  int? accountId;
  String? label;

  /// Frais d'envoi / de retrait payés par moi (font baisser le solde).
  int fee;
  Debt({
    required this.id,
    required this.direction,
    required this.person,
    required this.amount,
    required this.date,
    this.dueDate,
    this.accountId,
    this.label,
    this.fee = 0,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    if (fee > 0) 'fee': fee,
    'direction': direction.name,
    'person': person,
    'amount': amount,
    'date': date,
    'due_date': dueDate,
    'account_id': accountId,
    'label': label,
  };
  factory Debt.fromJson(Map<String, dynamic> j) => Debt(
    id: j['id'],
    direction: _enum(DebtDirection.values, j['direction'], DebtDirection.lent),
    person: j['person'],
    amount: j['amount'],
    date: j['date'],
    dueDate: j['due_date'],
    accountId: j['account_id'],
    label: j['label'],
    fee: j['fee'] ?? 0,
  );
}

class Payment {
  int id;
  int debtId;
  int amount;
  String date;
  int? accountId;

  /// Frais d'envoi / de retrait payés par moi.
  int fee;
  Payment({
    required this.id,
    required this.debtId,
    required this.amount,
    required this.date,
    this.accountId,
    this.fee = 0,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    if (fee > 0) 'fee': fee,
    'debt_id': debtId,
    'amount': amount,
    'date': date,
    'account_id': accountId,
  };
  factory Payment.fromJson(Map<String, dynamic> j) => Payment(
    id: j['id'],
    debtId: j['debt_id'],
    amount: j['amount'],
    date: j['date'],
    accountId: j['account_id'],
    fee: j['fee'] ?? 0,
  );
}

class Recurring {
  int id;
  TxType type;
  int amount;
  int accountId;
  int? categoryId;
  String label;
  int day;
  Beneficiary beneficiary;
  String? person;
  Nature nature;
  String lastMonth;
  bool active;
  Recurring({
    required this.id,
    required this.type,
    required this.amount,
    required this.accountId,
    this.categoryId,
    this.label = '',
    required this.day,
    this.beneficiary = Beneficiary.moi,
    this.person,
    this.nature = Nature.pour,
    required this.lastMonth,
    this.active = true,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type.name,
    'amount': amount,
    'account_id': accountId,
    'category_id': categoryId,
    'label': label,
    'day': day,
    'beneficiary': beneficiary.name,
    'person': person,
    'nature': nature.name,
    'last_month': lastMonth,
    'active': active,
  };
  factory Recurring.fromJson(Map<String, dynamic> j) => Recurring(
    id: j['id'],
    type: _enum(TxType.values, j['type'], TxType.expense),
    amount: j['amount'],
    accountId: j['account_id'],
    categoryId: j['category_id'],
    label: j['label'] ?? '',
    day: j['day'] ?? 1,
    beneficiary: _enum(Beneficiary.values, j['beneficiary'], Beneficiary.moi),
    person: j['person'],
    nature: _enum(Nature.values, j['nature'], Nature.pour),
    lastMonth: j['last_month'],
    active: j['active'] ?? true,
  );
}

/// Revenu d'un mois passé, noté seulement pour l'historique (sans effet sur les soldes).
class HistIncome {
  String month; // AAAA-MM
  String source;
  String label;
  int amount; // brut
  int tax;
  bool est; // montant estimé (approché)
  HistIncome({
    required this.month,
    required this.source,
    required this.label,
    required this.amount,
    this.tax = 0,
    this.est = false,
  });
  Map<String, dynamic> toJson() => {
    'month': month,
    'source': source,
    'label': label,
    'amount': amount,
    'tax': tax,
    if (est) 'est': true,
  };
  factory HistIncome.fromJson(Map<String, dynamic> j) => HistIncome(
    month: j['month'],
    source: j['source'] ?? 'Autres',
    label: j['label'] ?? '',
    amount: j['amount'] ?? 0,
    tax: j['tax'] ?? 0,
    est: j['est'] == true,
  );
}
