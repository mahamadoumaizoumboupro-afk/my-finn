/// Modèle de données de MY FINN.
library;

enum TxType { income, expense, transfer }

enum Beneficiary { moi, maison, personne }

enum Nature { pour, donation, cadeau }

enum DebtDirection { lent, borrowed }

T _enum<T extends Enum>(List<T> values, Object? v, T def) =>
    values.firstWhere((e) => e.name == v, orElse: () => def);

class Account {
  int id;
  String name;
  String type; // banque, mobile, carte, cash, epargne, bon, autre
  int initialBalance;
  bool includeInTotal;
  bool archived;
  int color;
  Account({required this.id, required this.name, this.type = 'autre', this.initialBalance = 0,
      this.includeInTotal = true, this.archived = false, this.color = 0xFF5B4CF5});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'type': type, 'initial_balance': initialBalance,
        'include_in_total': includeInTotal, 'archived': archived, 'color': color};
  factory Account.fromJson(Map<String, dynamic> j) => Account(id: j['id'], name: j['name'], type: j['type'] ?? 'autre',
      initialBalance: j['initial_balance'] ?? 0, includeInTotal: j['include_in_total'] ?? true,
      archived: j['archived'] ?? false, color: j['color'] ?? 0xFF5B4CF5);
}

class Cat {
  int id;
  String name;
  bool isIncome;
  String icon;
  int color;
  int budget;
  bool archived;
  Cat({required this.id, required this.name, required this.isIncome, this.icon = 'tag',
      this.color = 0xFF7A7F99, this.budget = 0, this.archived = false});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'income': isIncome, 'icon': icon, 'color': color,
        'budget': budget, 'archived': archived};
  factory Cat.fromJson(Map<String, dynamic> j) => Cat(id: j['id'], name: j['name'], isIncome: j['income'] ?? false,
      icon: j['icon'] ?? 'tag', color: j['color'] ?? 0xFF7A7F99, budget: j['budget'] ?? 0, archived: j['archived'] ?? false);
}

class Tx {
  int id;
  TxType type;
  int amount;
  int fee;
  int accountId;
  int? toAccountId;
  int? categoryId;
  Beneficiary beneficiary;
  String? person;
  Nature nature;
  String label;
  String? note;
  String date; // AAAA-MM-JJ
  Tx({required this.id, required this.type, required this.amount, this.fee = 0, required this.accountId,
      this.toAccountId, this.categoryId, this.beneficiary = Beneficiary.moi, this.person, this.nature = Nature.pour,
      this.label = '', this.note, required this.date});
  Map<String, dynamic> toJson() => {'id': id, 'type': type.name, 'amount': amount, 'fee': fee, 'account_id': accountId,
        'to_account_id': toAccountId, 'category_id': categoryId, 'beneficiary': beneficiary.name, 'person': person,
        'nature': nature.name, 'label': label, 'note': note, 'date': date};
  factory Tx.fromJson(Map<String, dynamic> j) => Tx(id: j['id'], type: _enum(TxType.values, j['type'], TxType.expense),
      amount: j['amount'], fee: j['fee'] ?? 0, accountId: j['account_id'], toAccountId: j['to_account_id'],
      categoryId: j['category_id'], beneficiary: _enum(Beneficiary.values, j['beneficiary'], Beneficiary.moi),
      person: j['person'], nature: _enum(Nature.values, j['nature'], Nature.pour), label: j['label'] ?? '',
      note: j['note'], date: j['date']);
}

class Debt {
  int id;
  DebtDirection direction;
  String person;
  int amount;
  String date;
  String? dueDate;
  int? accountId;
  String? label;
  Debt({required this.id, required this.direction, required this.person, required this.amount, required this.date,
      this.dueDate, this.accountId, this.label});
  Map<String, dynamic> toJson() => {'id': id, 'direction': direction.name, 'person': person, 'amount': amount,
        'date': date, 'due_date': dueDate, 'account_id': accountId, 'label': label};
  factory Debt.fromJson(Map<String, dynamic> j) => Debt(id: j['id'],
      direction: _enum(DebtDirection.values, j['direction'], DebtDirection.lent), person: j['person'],
      amount: j['amount'], date: j['date'], dueDate: j['due_date'], accountId: j['account_id'], label: j['label']);
}

class Payment {
  int id;
  int debtId;
  int amount;
  String date;
  int? accountId;
  Payment({required this.id, required this.debtId, required this.amount, required this.date, this.accountId});
  Map<String, dynamic> toJson() => {'id': id, 'debt_id': debtId, 'amount': amount, 'date': date, 'account_id': accountId};
  factory Payment.fromJson(Map<String, dynamic> j) =>
      Payment(id: j['id'], debtId: j['debt_id'], amount: j['amount'], date: j['date'], accountId: j['account_id']);
}

class Recurring {
  int id;
  TxType type;
  int amount;
  int accountId;
  int? categoryId;
  String label;
  int day;
  Beneficiary beneficiary;
  String? person;
  Nature nature;
  String lastMonth;
  bool active;
  Recurring({required this.id, required this.type, required this.amount, required this.accountId, this.categoryId,
      this.label = '', required this.day, this.beneficiary = Beneficiary.moi, this.person, this.nature = Nature.pour,
      required this.lastMonth, this.active = true});
  Map<String, dynamic> toJson() => {'id': id, 'type': type.name, 'amount': amount, 'account_id': accountId,
        'category_id': categoryId, 'label': label, 'day': day, 'beneficiary': beneficiary.name, 'person': person,
        'nature': nature.name, 'last_month': lastMonth, 'active': active};
  factory Recurring.fromJson(Map<String, dynamic> j) => Recurring(id: j['id'],
      type: _enum(TxType.values, j['type'], TxType.expense), amount: j['amount'], accountId: j['account_id'],
      categoryId: j['category_id'], label: j['label'] ?? '', day: j['day'] ?? 1,
      beneficiary: _enum(Beneficiary.values, j['beneficiary'], Beneficiary.moi), person: j['person'],
      nature: _enum(Nature.values, j['nature'], Nature.pour), lastMonth: j['last_month'], active: j['active'] ?? true);
}
