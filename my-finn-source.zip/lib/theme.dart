/// Identité visuelle MY FINN : indigo électrique + turquoise, corail / menthe pour les flux.
library;

import 'package:flutter/material.dart';

import 'store.dart';

class Palette {
  final Color bg,
      card,
      text,
      muted,
      faint,
      border,
      primary,
      primarySoft,
      accent;
  final Color income,
      incomeSoft,
      expense,
      expenseSoft,
      transfer,
      transferSoft,
      warn,
      warnSoft,
      tabBar;
  const Palette({
    required this.bg,
    required this.card,
    required this.text,
    required this.muted,
    required this.faint,
    required this.border,
    required this.primary,
    required this.primarySoft,
    required this.accent,
    required this.income,
    required this.incomeSoft,
    required this.expense,
    required this.expenseSoft,
    required this.transfer,
    required this.transferSoft,
    required this.warn,
    required this.warnSoft,
    required this.tabBar,
  });
}

// Base bleu marine, fond uni ; couleurs « finance » : vert = entrées, rouge = dépenses,
// bleu = transferts, ambre = prêts / alertes, or = accent.
const lightPalette = Palette(
  bg: Color(0xFFF3F5F9),
  card: Colors.white,
  text: Color(0xFF0F1B2D),
  muted: Color(0xFF66748A),
  faint: Color(0xFFA9B4C4),
  border: Color(0xFFE2E7EF),
  primary: Color(0xFF0F2747),
  primarySoft: Color(0xFFE4EAF3),
  accent: Color(0xFFD9A21B),
  income: Color(0xFF0E9F6E),
  incomeSoft: Color(0xFFE2F5EC),
  expense: Color(0xFFE5484D),
  expenseSoft: Color(0xFFFCE7E7),
  transfer: Color(0xFF2F6FED),
  transferSoft: Color(0xFFE6EEFD),
  warn: Color(0xFFF59E0B),
  warnSoft: Color(0xFFFEF3DC),
  tabBar: Colors.white,
);

const darkPalette = Palette(
  bg: Color(0xFF081428),
  card: Color(0xFF10223F),
  text: Color(0xFFEEF2F8),
  muted: Color(0xFF8A9BB5),
  faint: Color(0xFF4A5D7C),
  border: Color(0xFF1C3357),
  primary: Color(0xFF6E9BF2),
  primarySoft: Color(0xFF15305A),
  accent: Color(0xFFF2C14E),
  income: Color(0xFF34D399),
  incomeSoft: Color(0xFF0D2E2A),
  expense: Color(0xFFF87171),
  expenseSoft: Color(0xFF3A1A24),
  transfer: Color(0xFF60A5FA),
  transferSoft: Color(0xFF132B4D),
  warn: Color(0xFFFBBF24),
  warnSoft: Color(0xFF33290F),
  tabBar: Color(0xFF0D1D37),
);

/// Couleurs actives
Palette get C => store.dark ? darkPalette : lightPalette;

/// Bleu marine plein (très léger dégradé de la même couleur, sans mélange).
const heroGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF173560), Color(0xFF0D2343)],
);
const primaryGradient = heroGradient;
const incomeGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF12AB78), Color(0xFF0B9264)],
);
const expenseGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFFEC5257), Color(0xFFD93D43)],
);
const inkGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF0F2747), Color(0xFF0A1C36)],
);

const paletteChoices = [
  0xFF5B4CF5,
  0xFFF04461,
  0xFF3B82F6,
  0xFFF59E0B,
  0xFF8B5CF6,
  0xFFEC4899,
  0xFF12B76A,
  0xFFF97316,
  0xFF06B6D4,
  0xFF84CC16,
  0xFFA855F7,
  0xFFE11D48,
  0xFF0EA5E9,
  0xFF64748B,
];

List<BoxShadow> get softShadow => store.dark
    ? []
    : [
        BoxShadow(
          color: const Color(0xFF2A2470).withValues(alpha: 0.07),
          blurRadius: 18,
          offset: const Offset(0, 6),
        ),
      ];

ThemeData buildTheme() {
  final p = C;
  final base = ThemeData(
    useMaterial3: true,
    brightness: store.dark ? Brightness.dark : Brightness.light,
    fontFamily: 'Manrope',
    colorScheme: ColorScheme.fromSeed(
      seedColor: p.primary,
      brightness: store.dark ? Brightness.dark : Brightness.light,
      primary: p.primary,
      surface: p.card,
    ),
    scaffoldBackgroundColor: p.bg,
  );
  return base.copyWith(
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      foregroundColor: p.text,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: 'Manrope',
        fontWeight: FontWeight.w800,
        fontSize: 18,
        color: p.text,
      ),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: const WidgetStatePropertyAll(Colors.white),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? p.primary : p.border,
      ),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    textSelectionTheme: TextSelectionThemeData(cursorColor: p.primary),
    // Transitions douces entre les écrans
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {TargetPlatform.android: FadeForwardsPageTransitionsBuilder()},
    ),
  );
}

/// Icônes disponibles pour les catégories
const iconMap = <String, IconData>{
  'food': Icons.fastfood_rounded,
  'phone': Icons.smartphone_rounded,
  'shirt': Icons.checkroom_rounded,
  'sparkles': Icons.auto_awesome_rounded,
  'water': Icons.water_drop_rounded,
  'car': Icons.directions_car_rounded,
  'home': Icons.home_rounded,
  'game': Icons.sports_esports_rounded,
  'health': Icons.medical_services_rounded,
  'school': Icons.school_rounded,
  'repeat': Icons.autorenew_rounded,
  'heart': Icons.favorite_rounded,
  'gift': Icons.card_giftcard_rounded,
  'savings': Icons.savings_rounded,
  'undo': Icons.undo_rounded,
  'card': Icons.credit_card_rounded,
  'doc': Icons.description_rounded,
  'bolt': Icons.bolt_rounded,
  'key': Icons.key_rounded,
  'more': Icons.more_horiz_rounded,
  'work': Icons.work_rounded,
  'build': Icons.handyman_rounded,
  'store': Icons.storefront_rounded,
  'add': Icons.add_circle_rounded,
  'tag': Icons.sell_rounded,
  'cafe': Icons.local_cafe_rounded,
  'restaurant': Icons.restaurant_rounded,
  'bike': Icons.two_wheeler_rounded,
  'music': Icons.music_note_rounded,
  'flight': Icons.flight_rounded,
  'sport': Icons.sports_soccer_rounded,
  'book': Icons.menu_book_rounded,
  'people': Icons.people_rounded,
  'pet': Icons.pets_rounded,
  'church': Icons.mosque_rounded,
  'baby': Icons.child_care_rounded,
};
IconData iconFor(String key) => iconMap[key] ?? Icons.sell_rounded;

const accountTypes = <(String, String, IconData)>[
  ('banque', 'Banque', Icons.account_balance_rounded),
  ('mobile', 'Mobile money', Icons.phone_android_rounded),
  ('carte', 'Carte', Icons.credit_card_rounded),
  ('cash', 'Cash', Icons.payments_rounded),
  ('epargne', 'Épargne', Icons.savings_rounded),
  ('bon', 'Bons / tickets', Icons.confirmation_number_rounded),
  ('autre', 'Autre', Icons.account_balance_wallet_rounded),
];
IconData accountIcon(String t) => accountTypes
    .firstWhere((x) => x.$1 == t, orElse: () => accountTypes.last)
    .$3;
String accountTypeLabel(String t) => accountTypes
    .firstWhere((x) => x.$1 == t, orElse: () => accountTypes.last)
    .$2;

/* ---------- Effet verre (glassmorphism) ---------- */

/// Remplissage et bordure des cartes en verre dépoli.
Color get glassFill => C.card;
Color get glassBorder => C.border;

/// Dégradé plein à partir d'une couleur : un peu plus clair en haut à gauche, plus profond en bas à droite.
LinearGradient fillGradient(Color c) {
  final h = HSLColor.fromColor(c);
  return LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      h.withLightness((h.lightness + 0.04).clamp(0.0, 0.9)).toColor(),
      h.withLightness((h.lightness - 0.03).clamp(0.08, 1.0)).toColor(),
    ],
  );
}

/// Fond de l'app : couleur unie.
class Aurora extends StatelessWidget {
  const Aurora({super.key});
  @override
  Widget build(BuildContext context) => ColoredBox(color: C.bg);
}
