/// Identité visuelle MY FINN : indigo électrique + turquoise, corail / menthe pour les flux.
library;

import 'package:flutter/material.dart';
import 'store.dart';

class Palette {
  final Color bg, card, text, muted, faint, border, primary, primarySoft, accent;
  final Color income, incomeSoft, expense, expenseSoft, transfer, transferSoft, warn, warnSoft, tabBar;
  const Palette({required this.bg, required this.card, required this.text, required this.muted, required this.faint,
      required this.border, required this.primary, required this.primarySoft, required this.accent, required this.income,
      required this.incomeSoft, required this.expense, required this.expenseSoft, required this.transfer,
      required this.transferSoft, required this.warn, required this.warnSoft, required this.tabBar});
}

const lightPalette = Palette(
  bg: Color(0xFFF2F3FA), card: Colors.white, text: Color(0xFF0F1222), muted: Color(0xFF7A7F99), faint: Color(0xFFB4B8CC),
  border: Color(0xFFE6E8F2), primary: Color(0xFF5B4CF5), primarySoft: Color(0xFFECEAFF), accent: Color(0xFF14C8B4),
  income: Color(0xFF12B76A), incomeSoft: Color(0xFFE3F8EE), expense: Color(0xFFF04461), expenseSoft: Color(0xFFFDE8EC),
  transfer: Color(0xFF3B82F6), transferSoft: Color(0xFFE6F0FF), warn: Color(0xFFF59E0B), warnSoft: Color(0xFFFEF3DC),
  tabBar: Colors.white,
);

const darkPalette = Palette(
  bg: Color(0xFF0B0D1A), card: Color(0xFF161A2E), text: Color(0xFFF2F3FA), muted: Color(0xFF9096B4), faint: Color(0xFF4A5070),
  border: Color(0xFF262B45), primary: Color(0xFF7C6CFF), primarySoft: Color(0xFF251F55), accent: Color(0xFF2DD4BF),
  income: Color(0xFF34D399), incomeSoft: Color(0xFF0F2E24), expense: Color(0xFFFF6B81), expenseSoft: Color(0xFF3A1520),
  transfer: Color(0xFF60A5FA), transferSoft: Color(0xFF132743), warn: Color(0xFFFBBF24), warnSoft: Color(0xFF3A2C0C),
  tabBar: Color(0xFF12152A),
);

/// Couleurs actives
Palette get C => store.dark ? darkPalette : lightPalette;

const heroGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFF5B4CF5), Color(0xFF7B3FE4), Color(0xFF0EA5B7)]);
const primaryGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFF6A5CFF), Color(0xFF4B3BEA)]);
const incomeGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFF19C37D), Color(0xFF0E9F6E)]);
const expenseGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFFFF6B81), Color(0xFFE23A57)]);
const inkGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFF221C4A), Color(0xFF14112E)]);

const paletteChoices = [
  0xFF5B4CF5, 0xFFF04461, 0xFF3B82F6, 0xFFF59E0B, 0xFF8B5CF6, 0xFFEC4899, 0xFF12B76A,
  0xFFF97316, 0xFF06B6D4, 0xFF84CC16, 0xFFA855F7, 0xFFE11D48, 0xFF0EA5E9, 0xFF64748B,
];

List<BoxShadow> get softShadow => store.dark
    ? []
    : [BoxShadow(color: const Color(0xFF2A2470).withValues(alpha: 0.07), blurRadius: 18, offset: const Offset(0, 6))];

ThemeData buildTheme() {
  final p = C;
  final base = ThemeData(
    useMaterial3: true,
    brightness: store.dark ? Brightness.dark : Brightness.light,
    fontFamily: 'Manrope',
    colorScheme: ColorScheme.fromSeed(seedColor: p.primary, brightness: store.dark ? Brightness.dark : Brightness.light,
        primary: p.primary, surface: p.card),
    scaffoldBackgroundColor: p.bg,
  );
  return base.copyWith(
    appBarTheme: AppBarTheme(backgroundColor: p.bg, surfaceTintColor: Colors.transparent, elevation: 0, foregroundColor: p.text,
        centerTitle: false, titleTextStyle: TextStyle(fontFamily: 'Manrope', fontWeight: FontWeight.w800, fontSize: 18, color: p.text)),
    switchTheme: SwitchThemeData(
      thumbColor: const WidgetStatePropertyAll(Colors.white),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? p.primary : p.border),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    textSelectionTheme: TextSelectionThemeData(cursorColor: p.primary),
    // Transitions douces entre les écrans
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: FadeForwardsPageTransitionsBuilder(),
    }),
  );
}

/// Icônes disponibles pour les catégories
const iconMap = <String, IconData>{
  'food': Icons.fastfood_rounded, 'phone': Icons.smartphone_rounded, 'shirt': Icons.checkroom_rounded,
  'sparkles': Icons.auto_awesome_rounded, 'water': Icons.water_drop_rounded, 'car': Icons.directions_car_rounded,
  'home': Icons.home_rounded, 'game': Icons.sports_esports_rounded, 'health': Icons.medical_services_rounded,
  'school': Icons.school_rounded, 'repeat': Icons.autorenew_rounded, 'heart': Icons.favorite_rounded,
  'gift': Icons.card_giftcard_rounded, 'savings': Icons.savings_rounded, 'undo': Icons.undo_rounded,
  'card': Icons.credit_card_rounded, 'doc': Icons.description_rounded, 'bolt': Icons.bolt_rounded,
  'key': Icons.key_rounded, 'more': Icons.more_horiz_rounded, 'work': Icons.work_rounded,
  'build': Icons.handyman_rounded, 'store': Icons.storefront_rounded, 'add': Icons.add_circle_rounded,
  'tag': Icons.sell_rounded, 'cafe': Icons.local_cafe_rounded, 'restaurant': Icons.restaurant_rounded,
  'bike': Icons.two_wheeler_rounded, 'music': Icons.music_note_rounded, 'flight': Icons.flight_rounded,
  'sport': Icons.sports_soccer_rounded, 'book': Icons.menu_book_rounded, 'people': Icons.people_rounded,
  'pet': Icons.pets_rounded, 'church': Icons.mosque_rounded, 'baby': Icons.child_care_rounded,
};
IconData iconFor(String key) => iconMap[key] ?? Icons.sell_rounded;

const accountTypes = <(String, String, IconData)>[
  ('banque', 'Banque', Icons.account_balance_rounded), ('mobile', 'Mobile money', Icons.phone_android_rounded),
  ('carte', 'Carte', Icons.credit_card_rounded), ('cash', 'Cash', Icons.payments_rounded),
  ('epargne', 'Épargne', Icons.savings_rounded), ('bon', 'Bons / tickets', Icons.confirmation_number_rounded),
  ('autre', 'Autre', Icons.account_balance_wallet_rounded),
];
IconData accountIcon(String t) => accountTypes.firstWhere((x) => x.$1 == t, orElse: () => accountTypes.last).$3;
String accountTypeLabel(String t) => accountTypes.firstWhere((x) => x.$1 == t, orElse: () => accountTypes.last).$2;
