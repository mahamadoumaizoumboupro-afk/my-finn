/// Identité visuelle MY FINN : bleu royal, bleu ardoise, vert / rouge pour l'argent.
library;

import 'package:flutter/material.dart';

import 'store.dart';

class Palette {
  final Color bg,
      card,
      text,
      muted,
      faint,
      border,
      primary,
      primarySoft,
      accent;
  final Color income,
      incomeSoft,
      expense,
      expenseSoft,
      transfer,
      transferSoft,
      warn,
      warnSoft,
      tabBar;
  const Palette({
    required this.bg,
    required this.card,
    required this.text,
    required this.muted,
    required this.faint,
    required this.border,
    required this.primary,
    required this.primarySoft,
    required this.accent,
    required this.income,
    required this.incomeSoft,
    required this.expense,
    required this.expenseSoft,
    required this.transfer,
    required this.transferSoft,
    required this.warn,
    required this.warnSoft,
    required this.tabBar,
  });
}

// Couleurs de l'affiche : bleu royal, bleu ardoise, bleu clair. Une seule couleur d'accent (bleu),
// vert = entrées, rouge = dépenses ; transferts et prêts en bleu-gris neutre.
const lightPalette = Palette(
  bg: Color(0xFFEEF2FB),
  card: Colors.white,
  text: Color(0xFF0B1A33),
  muted: Color(0xFF56658A),
  faint: Color(0xFFA3B0CC),
  border: Color(0xFFE1E7F5),
  primary: Color(0xFF1650F0),
  primarySoft: Color(0xFFE3EBFF),
  accent: Color(0xFF0356F6),
  income: Color(0xFF0E9F6E),
  incomeSoft: Color(0xFFE3F6EE),
  expense: Color(0xFFE5484D),
  expenseSoft: Color(0xFFFDECEC),
  transfer: Color(0xFF3958AC),
  transferSoft: Color(0xFFE8EEFC),
  warn: Color(0xFFE5A23B),
  warnSoft: Color(0xFFFDF3E2),
  tabBar: Color(0xFF0D33D9),
);

const darkPalette = Palette(
  bg: Color(0xFF04103F),
  card: Color(0xFF0A1B57),
  text: Color(0xFFEEF3FF),
  muted: Color(0xFF9DB0E0),
  faint: Color(0xFF4E64A8),
  border: Color(0xFF16297A),
  primary: Color(0xFF5B8CFF),
  primarySoft: Color(0xFF14287A),
  accent: Color(0xFF0356F6),
  income: Color(0xFF2BCB86),
  incomeSoft: Color(0xFF0E3A4A),
  expense: Color(0xFFFF6B70),
  expenseSoft: Color(0xFF3A1A45),
  transfer: Color(0xFF9DBDF4),
  transferSoft: Color(0xFF14287A),
  warn: Color(0xFFF2B84B),
  warnSoft: Color(0xFF3A2F1A),
  tabBar: Color(0xFF022649),
);

/// Couleurs actives
Palette get C => store.dark ? darkPalette : lightPalette;

/// Carte principale : bleu ardoise (le seul léger effet de l'app).
const heroGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF0D2F4E), Color(0xFF022649)],
);

/// Bleu royal plein.
const primaryGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF1650F0), Color(0xFF0D33D9)],
);

/// Bleu clair de la courbe du solde.
const curveBlue = Color(0xFF9DBDF4);
const electricBlue = Color(0xFF0356F6);
const cardRadius = 12.0;
const incomeGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF12AB78), Color(0xFF0B9264)],
);
const expenseGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFFEC5257), Color(0xFFD93D43)],
);
const inkGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF0F2747), Color(0xFF0A1C36)],
);

const paletteChoices = [
  0xFF5B4CF5,
  0xFFF04461,
  0xFF3B82F6,
  0xFFF59E0B,
  0xFF8B5CF6,
  0xFFEC4899,
  0xFF12B76A,
  0xFFF97316,
  0xFF06B6D4,
  0xFF84CC16,
  0xFFA855F7,
  0xFFE11D48,
  0xFF0EA5E9,
  0xFF64748B,
];

List<BoxShadow> get softShadow => store.dark
    ? []
    : [
        BoxShadow(
          color: const Color(0xFF0D33D9).withValues(alpha: 0.07),
          blurRadius: 18,
          offset: const Offset(0, 6),
        ),
      ];

ThemeData buildTheme() {
  final p = C;
  final base = ThemeData(
    useMaterial3: true,
    brightness: store.dark ? Brightness.dark : Brightness.light,
    fontFamily: 'Manrope',
    colorScheme: ColorScheme.fromSeed(
      seedColor: p.primary,
      brightness: store.dark ? Brightness.dark : Brightness.light,
      primary: p.primary,
      surface: p.card,
    ),
    scaffoldBackgroundColor: p.bg,
  );
  return base.copyWith(
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      foregroundColor: p.text,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: 'Manrope',
        fontWeight: FontWeight.w800,
        fontSize: 18,
        color: p.text,
      ),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: const WidgetStatePropertyAll(Colors.white),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? p.primary : p.border,
      ),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    textSelectionTheme: TextSelectionThemeData(cursorColor: p.primary),
    // Transitions douces entre les écrans
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {TargetPlatform.android: FadeForwardsPageTransitionsBuilder()},
    ),
  );
}

/// Icônes disponibles pour les catégories
const iconMap = <String, IconData>{
  'food': Icons.fastfood_rounded,
  'phone': Icons.smartphone_rounded,
  'shirt': Icons.checkroom_rounded,
  'sparkles': Icons.auto_awesome_rounded,
  'water': Icons.water_drop_rounded,
  'car': Icons.directions_car_rounded,
  'home': Icons.home_rounded,
  'game': Icons.sports_esports_rounded,
  'health': Icons.medical_services_rounded,
  'school': Icons.school_rounded,
  'repeat': Icons.autorenew_rounded,
  'heart': Icons.favorite_rounded,
  'gift': Icons.card_giftcard_rounded,
  'savings': Icons.savings_rounded,
  'undo': Icons.undo_rounded,
  'card': Icons.credit_card_rounded,
  'doc': Icons.description_rounded,
  'bolt': Icons.bolt_rounded,
  'key': Icons.key_rounded,
  'more': Icons.more_horiz_rounded,
  'help': Icons.help_outline_rounded,
  'work': Icons.work_rounded,
  'build': Icons.handyman_rounded,
  'store': Icons.storefront_rounded,
  'add': Icons.add_circle_rounded,
  'tag': Icons.sell_rounded,
  'cafe': Icons.local_cafe_rounded,
  'restaurant': Icons.restaurant_rounded,
  'bike': Icons.two_wheeler_rounded,
  'music': Icons.music_note_rounded,
  'flight': Icons.flight_rounded,
  'sport': Icons.sports_soccer_rounded,
  'book': Icons.menu_book_rounded,
  'people': Icons.people_rounded,
  'pet': Icons.pets_rounded,
  'church': Icons.mosque_rounded,
  'baby': Icons.child_care_rounded,
};
IconData iconFor(String key) => iconMap[key] ?? Icons.sell_rounded;

const accountTypes = <(String, String, IconData)>[
  ('banque', 'Banque', Icons.account_balance_rounded),
  ('mobile', 'Mobile money', Icons.phone_android_rounded),
  ('carte', 'Carte', Icons.credit_card_rounded),
  ('cash', 'Cash', Icons.payments_rounded),
  ('epargne', 'Épargne', Icons.savings_rounded),
  ('bon', 'Bons / tickets', Icons.confirmation_number_rounded),
  ('autre', 'Autre', Icons.account_balance_wallet_rounded),
];
IconData accountIcon(String t) => accountTypes
    .firstWhere((x) => x.$1 == t, orElse: () => accountTypes.last)
    .$3;
String accountTypeLabel(String t) => accountTypes
    .firstWhere((x) => x.$1 == t, orElse: () => accountTypes.last)
    .$2;

/* ---------- Effet verre (glassmorphism) ---------- */

/// Remplissage et bordure des cartes en verre dépoli.
Color get glassFill => C.card;
Color get glassBorder => C.border;

/// Dégradé plein à partir d'une couleur : un peu plus clair en haut à gauche, plus profond en bas à droite.
LinearGradient fillGradient(Color c) {
  final h = HSLColor.fromColor(c);
  return LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      h.withLightness((h.lightness + 0.04).clamp(0.0, 0.9)).toColor(),
      h.withLightness((h.lightness - 0.03).clamp(0.08, 1.0)).toColor(),
    ],
  );
}

/// Fond de l'app : couleur unie.
class Aurora extends StatelessWidget {
  const Aurora({super.key});
  @override
  Widget build(BuildContext context) => ColoredBox(color: C.bg);
}

/* ---------- Logos des comptes ---------- */
String _norm(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z]'), '');

/// Logo d'un compte d'après son nom (Coris, Nita, Visa Nita, Amana, Cash), sinon null.
String? accountLogo(String name) {
  final n = _norm(name);
  if (n.contains('visa')) return 'assets/logos/visa-nita.png';
  if (n.contains('coris')) return 'assets/logos/coris.png';
  if (n.contains('nita')) return 'assets/logos/nita.png';
  if (n.contains('amana')) return 'assets/logos/amana.png';
  if (n == 'cash' || n.contains('especes')) return 'assets/logos/cash.png';
  return null;
}
