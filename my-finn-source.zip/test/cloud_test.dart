import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:my_finn/cloud.dart';
import 'package:my_finn/store.dart';

/// Faux Firebase en mémoire : comptes + documents Firestore.
MockClient fakeFirebase(Map<String, String> db, {List<String>? log}) => MockClient((req) async {
      log?.add('${req.method} ${req.url.path.split('/').last}');
      final u = req.url.toString();
      if (u.contains('accounts:signUp') || u.contains('accounts:signInWithPassword')) {
        final b = jsonDecode(req.body);
        if (b['password'] == 'mauvais') return http.Response(jsonEncode({'error': {'message': 'INVALID_LOGIN_CREDENTIALS'}}), 400);
        return http.Response(jsonEncode({'localId': 'u1', 'email': b['email'], 'idToken': 't', 'refreshToken': 'r', 'expiresIn': '3600'}), 200);
      }
      expect(req.headers['Authorization'], 'Bearer t');
      expect(u, contains('/projects/my-finn-f93b5/databases/(default)/documents/users/u1/data'));
      final id = req.url.pathSegments.last;
      switch (req.method) {
        case 'PATCH':
          db[id] = jsonDecode(req.body)['fields']['json']['stringValue'];
          return http.Response('{}', 200);
        case 'DELETE':
          db.remove(id);
          return http.Response('{}', 200);
        default:
          return http.Response.bytes(utf8.encode(jsonEncode({
            'documents': [
              for (final e in db.entries) {'name': 'projects/p/databases/(default)/documents/users/u1/data/${e.key}', 'fields': {'json': {'stringValue': e.value}}}
            ]
          })), 200);
      }
    });

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('envoi en ligne puis récupération sur un « nouveau téléphone »', () async {
    final db = <String, String>{};
    final log = <String>[];
    final phone1 = AppStore()..persist = false;
    await phone1.load();
    await phone1.importSeptember2026();
    phone1.settings['pin_hash'] = 'secret-local';
    final c1 = Cloud(phone1, client: fakeFirebase(db, log: log));
    await c1.signUp('moi@gmail.com', 'motdepasse');
    await c1.syncNow();
    expect(c1.lastError, isNull);
    expect(db.keys, containsAll(['core', 'tx-2026-09']));
    expect(db['core'], isNot(contains('secret-local'))); // le code PIN reste sur le téléphone

    // Rien n'a changé : aucun nouvel envoi.
    log.clear();
    await c1.syncNow();
    expect(log.where((l) => l.startsWith('PATCH')), isEmpty);

    final phone2 = AppStore()..persist = false;
    await phone2.load();
    expect(phone2.isEmpty, isTrue);
    final c2 = Cloud(phone2, client: fakeFirebase(db));
    await c2.signIn('moi@gmail.com', 'motdepasse');
    expect(await c2.hasRemoteData(), isTrue);
    await c2.restore();
    expect(phone2.txs.length, phone1.txs.length);
    expect(phone2.available(), 1479050);
    expect(phone2.owedToMe(), phone1.owedToMe());
    expect(phone2.settings['pin_hash'], isNull);

    // Un mois vidé est effacé en ligne.
    phone2.txs.removeWhere((t) => t.date.startsWith('2026-09'));
    await c2.syncNow();
    expect(db.containsKey('tx-2026-09'), isFalse);
  });

  test('mauvais mot de passe : message en français', () async {
    final s = AppStore()..persist = false;
    await s.load();
    final c = Cloud(s, client: fakeFirebase({}));
    expect(() => c.signIn('moi@gmail.com', 'mauvais'), throwsA(predicate((e) => '$e' == 'E-mail ou mot de passe incorrect.')));
  });
}
