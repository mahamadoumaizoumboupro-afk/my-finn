import 'package:flutter_test/flutter_test.dart';
import 'package:my_finn/format.dart';
import 'package:my_finn/models.dart';
import 'package:my_finn/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test("l'import de septembre retombe sur les soldes du 30/09", () async {
    final s = AppStore()..persist = false;
    await s.load(); // pas de fichier en test : valeurs par défaut
    await s.importSeptember2026();
    int bal(String n) => s.balance(s.accounts.firstWhere((a) => a.name == n));
    expect(bal('Compte Coris'), 1356750);
    expect(bal('Nita'), 72400);
    expect(bal('Cash'), 48200);
    expect(s.available(), 1479050);
    final sm = s.summary('2026-09');
    expect(sm.income, 905550);
    expect(sm.byBeneficiary['maison'], 71300);
    expect(s.owedToMe(), 1450500);
    expect(s.monthReport('2026-09'), contains('| **Disponible** | **1.479.050** |'));
  });

  test('opération récurrente ajoutée chaque mois', () async {
    final s = AppStore()..persist = false;
    await s.load();
    fixedToday = '2026-11-03';
    s.addRecurring(Recurring(id: 0, type: TxType.income, amount: 479750, accountId: 1, day: 23, lastMonth: '2026-09', label: 'Salaire'));
    expect(s.runRecurring(), 1); // octobre seulement (le 23 novembre n'est pas encore passé)
    expect(s.runRecurring(), 0);
    fixedToday = null;
  });

  test('format des montants', () {
    expect(num0(1479050), '1.479.050');
    expect(parseAmount('1.479.050'), 1479050);
  });
}
