import 'package:flutter_test/flutter_test.dart';
import 'package:my_finn/format.dart';
import 'package:my_finn/models.dart';
import 'package:my_finn/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    "l'import du suivi complet retombe sur tous les soldes du fichier",
    () async {
      final s = AppStore()..persist = false;
      await s.load(); // pas de fichier en test : valeurs par défaut
      // une ancienne opération doit disparaître (l'import remplace tout)
      s.saveTx(
        Tx(
          id: 0,
          type: TxType.expense,
          amount: 999,
          accountId: 1,
          date: '2026-09-02',
          label: 'ancien',
        ),
      );
      await s.importHistory();
      await s.importHistory(); // réimporter ne double rien
      int bal(String n, [String? until]) =>
          s.balance(s.accounts.firstWhere((a) => a.name == n), until: until);
      expect(s.txs.where((t) => t.label == 'ancien'), isEmpty);
      // 30/09
      expect(bal('Compte Coris', '2026-09-30'), 1356750);
      expect(bal('Nita', '2026-09-30'), 72400);
      expect(bal('Cash', '2026-09-30'), 48200);
      expect(s.available(until: '2026-09-30'), 1479050);
      // 31/10
      expect(bal('Compte Coris', '2026-10-31'), 387500);
      expect(bal('Nita', '2026-10-31'), 18100);
      expect(bal('Visa Nita', '2026-10-31'), 1500);
      expect(bal('Amana', '2026-10-31'), 0);
      expect(bal('Cash', '2026-10-31'), 115400);
      expect(bal("Bons d'essence", '2026-10-31'), 45000);
      expect(s.available(until: '2026-10-31'), 522500);
      // 03/11
      expect(s.available(), 521500);
      expect(bal('Nita'), 17100);
      // avoirs
      final a = s.avoirs();
      expect(a.creances, 2930500);
      expect(a.dettes, 246500);
      expect(a.placements, 4220000);
      expect(a.total, 7425500);
      // revenus : 12 mois notés (sept. 2025 → août 2026) puis les mois saisis
      final months = s.incomeMonths();
      expect(
        months.where((m) => m.fromHistory).length,
        58,
      ); // 2022 → oct. 2026 (dont 44 mois ajoutés : 2022 → août 2025)
      final hist = months
          .where(
            (m) =>
                m.month.compareTo('2025-09') >= 0 &&
                m.month.compareTo('2026-08') <= 0,
          )
          .toList();
      expect(hist.length, 12);
      expect(hist.first.month, '2025-09');
      expect(hist.fold(0, (x, m) => x + m.gross), 10230700);
      expect(hist.fold(0, (x, m) => x + m.net), 9919500);
      expect(months.firstWhere((m) => m.month == '2026-10').net, 885750);
      final sm = s.summary('2026-09');
      expect(sm.income, 905550);
      expect(sm.taxes, 33450);
      expect(sm.byBeneficiary['maison'], 71300);
      expect(s.summary('2026-10').taxes, 25250);
      expect(
        s.monthReport('2026-10'),
        contains('| **Disponible** | **522.500** |'),
      );
    },
  );

  test('opération récurrente ajoutée chaque mois', () async {
    final s = AppStore()..persist = false;
    await s.load();
    fixedToday = '2026-11-03';
    s.addRecurring(
      Recurring(
        id: 0,
        type: TxType.income,
        amount: 479750,
        accountId: 1,
        day: 23,
        lastMonth: '2026-09',
        label: 'Salaire',
      ),
    );
    expect(
      s.runRecurring(),
      1,
    ); // octobre seulement (le 23 novembre n'est pas encore passé)
    expect(s.runRecurring(), 0);
    fixedToday = null;
  });

  test('format des montants', () {
    expect(num0(1479050), '1.479.050');
    expect(parseAmount('1.479.050'), 1479050);
  });

  test("réajuster le solde note l'écart, sur n'importe quel compte", () async {
    final s = AppStore()..persist = false;
    await s.load();
    final cash = s.accounts.firstWhere((a) => a.name == 'Cash');
    final nita = s.accounts.firstWhere((a) => a.name == 'Nita');
    cash.initialBalance = 20000;
    nita.initialBalance = 10000;
    // il manque 5.000 en cash : dépense « Écart »
    final t1 = s.adjustBalance(cash, 15000, date: '2026-11-05')!;
    expect(t1.type, TxType.expense);
    expect(t1.amount, 5000);
    expect(t1.adjust, isTrue);
    expect(s.category(t1.categoryId)!.name, AppStore.ecartCatName);
    expect(s.balance(cash), 15000);
    // Nita : on choisit « Nourriture »
    final food = s
        .cats(income: false)
        .firstWhere((c) => c.name == 'Alimentation');
    s.adjustBalance(nita, 5500, categoryId: food.id, date: '2026-11-02');
    expect(s.balance(nita), 5500);
    // argent en plus : entrée
    final t3 = s.adjustBalance(cash, 16000, date: '2026-11-06')!;
    expect(t3.type, TxType.income);
    expect(s.balance(cash), 16000);
    // pas d'écart : rien n'est créé
    expect(s.adjustBalance(cash, 16000, date: '2026-11-06'), isNull);
    final e = s.ecarts('2026-11');
    expect(e.first.$1.name, 'Nita');
    expect(e.first.$2, -4500);
    expect(e.last.$2, -4000);
    expect(e.last.$3, 2);
    // le marqueur survit à l'enregistrement en ligne
    final back = Tx.fromJson(t1.toJson());
    expect(back.adjust, isTrue);
    expect(Tx.fromJson({...t1.toJson()}..remove('adjust')).adjust, isFalse);
  });

  test(
    "salaire d'octobre reçu en novembre : Bilan en octobre, solde en novembre",
    () async {
      final s = AppStore()..persist = false;
      await s.load();
      final acc = s.accounts.first;
      final before = s.balance(acc, until: '2026-10-31');
      s.saveTx(
        Tx(
          id: 0,
          type: TxType.income,
          amount: 500000,
          accountId: acc.id,
          date: '2026-11-09',
          label: 'Salaire Abidjan',
          forMonth: '2026-10',
        ),
      );
      final t = s.txs.firstWhere((t) => t.label == 'Salaire Abidjan');
      expect(t.shifted, isTrue);
      expect(t.period, '2026-10');
      // le solde suit la vraie date
      expect(s.balance(acc, until: '2026-10-31'), before);
      expect(s.balance(acc, until: '2026-11-09'), before + 500000);
      // le Bilan suit le mois choisi
      final oct = s.summary('2026-10').income,
          nov = s.summary('2026-11').income;
      expect(oct >= 500000, isTrue);
      expect(s.countedInto('2026-10').map((t) => t.label), ['Salaire Abidjan']);
      expect(s.countedElsewhere('2026-11').map((t) => t.label), [
        'Salaire Abidjan',
      ]);
      expect(s.transactions(month: '2026-11').contains(t), isTrue);
      expect(
        s.transactions(month: '2026-10', byPeriod: true).contains(t),
        isTrue,
      );
      t.forMonth = null;
      expect(s.summary('2026-10').income, oct - 500000);
      expect(s.summary('2026-11').income, nov + 500000);
      // sauvegarde : le champ n'est écrit que s'il sert
      expect(t.toJson().containsKey('for_month'), isFalse);
      t.forMonth = '2026-10';
      final back = Tx.fromJson(t.toJson());
      expect(back.forMonth, '2026-10');
    },
  );

  test("voir tout : listes du Bilan et versements d'une source", () async {
    final s = AppStore()..persist = false;
    await s.load();
    final acc = s.accounts.firstWhere((a) => a.includeInTotal);
    s.saveTx(
      Tx(
        id: 0,
        type: TxType.income,
        amount: 500000,
        accountId: acc.id,
        date: '2026-12-09',
        label: 'Salaire Abib Digit',
        forMonth: '2026-11',
      ),
    );
    final nov = s.bilanTxs('2026-11', TxType.income);
    expect(nov.any((t) => t.label == 'Salaire Abib Digit'), isTrue);
    expect(nov.fold(0, (x, t) => x + t.amount), s.summary('2026-11').income);
    final dec = s.bilanTxs('2026-12', TxType.income);
    expect(dec.any((t) => t.label == 'Salaire Abib Digit'), isFalse);
    final exp = s.bilanTxs('2026-11', TxType.expense);
    final sm = s.summary('2026-11');
    expect(exp.fold(0, (x, t) => x + t.amount), sm.expense);
    final rows = s.incomeOfSource('Salaire Abib Digit');
    expect(rows.first.month, '2026-11');
    expect(rows.first.tx?.date, '2026-12-09');
    final total = rows.fold(0, (x, r) => x + r.gross);
    final fromMonths = s.incomeMonths().fold(
      0,
      (x, m) => x + (m.bySource['Salaire Abib Digit'] ?? 0),
    );
    expect(total, fromMonths);
  });

  test('noms et saisie rapide : les plus récents d\'abord', () async {
    final s = AppStore()..persist = false;
    await s.load();
    final acc = s.accounts.first.id;
    Tx spend(String who, String date, String label) => Tx(
      id: 0,
      type: TxType.expense,
      amount: 2000,
      accountId: acc,
      date: date,
      label: label,
      beneficiary: Beneficiary.personne,
      person: who,
    );
    s.saveTx(spend('Zoé', '2030-01-02', 'Cadeau Zoé'));
    s.saveTx(spend('Yann', '2030-01-03', 'Taxi Yann'));
    s.saveTx(
      spend('Zoé', '2030-01-03', 'Repas Zoé'),
    ); // même jour, ajoutée après
    s.debts.add(
      Debt(
        id: 999,
        direction: DebtDirection.borrowed,
        person: 'Banque X',
        amount: 1,
        date: '2030-02-01',
      ),
    );
    final p = s.people(spentOnly: true);
    expect(p.take(2).toList(), ['Zoé', 'Yann']);
    expect(p.contains('Banque X'), isFalse);
    expect(s.people().first, 'Banque X');
    final tp = s.templates(TxType.expense);
    expect(tp.first.tx.label, 'Repas Zoé');
    expect(tp[1].tx.label, 'Taxi Yann');
  });

  test('bilan par année, par période et toutes les années', () async {
    final s = AppStore()..persist = false;
    await s.load();
    await s.importHistory();
    final ys = s.years();
    expect(ys.first, '2022');
    final y25 = s.yearSummary('2025');
    expect(y25.totalIncome, 4599600); // janv. → août (ajoutés) + sept. → déc.
    expect(y25.hasExpenses, isFalse);
    final y26 = s.yearSummary('2026');
    expect(y26.hasExpenses, isTrue);
    expect(y26.expense.keys.first, y26.firstExpenseMonth);
    final p = s.rangeSummary('2025-11', '2026-02');
    expect(p.income.keys.toList(), [
      '2025-11',
      '2025-12',
      '2026-01',
      '2026-02',
    ]);
    expect(p.totalIncome, 684750 + 609750 + 619750 + 685750);
    final all = s.allYearsSummary();
    expect(all.income['2025'], 4599600);
    expect(
      all.totalIncome,
      ys.fold(0, (x, y) => x + s.yearSummary(y).totalIncome),
    );
  });

  test(
    'revenus 2022 → août 2025 ajoutés une seule fois, totaux justes',
    () async {
      final s = AppStore()..persist = false;
      await s.load();
      await s.importHistory();
      s.addOldIncome(); // une deuxième fois : rien ne double
      int y(String yr) => s.yearSummary(yr).totalIncome;
      expect(y('2022'), 430000);
      expect(y('2023'), 773000);
      expect(y('2024'), 2091000);
      expect(s.yearSummary('2023').estimated.length, 11);
      expect(s.years().first, '2022');
      // 2025 : janvier → août ajoutés, septembre et octobre inchangés
      final m25 = s.incomeMonths().where((m) => m.month.startsWith('2025-'));
      expect(m25.length, 12);
      expect(
        s.incomeMonths().firstWhere((m) => m.month == '2025-02').gross,
        272400,
      );
      expect(
        s.incomeMonths().firstWhere((m) => m.month == '2025-06').gross,
        325000,
      );
    },
  );

  test(
    'dépenses de mai et juin 2026 : trace dans le Bilan, soldes intacts',
    () async {
      final s = AppStore()..persist = false;
      await s.load();
      await s.importHistory();
      final avail = s.available();
      s.addOldExpenses(); // une deuxième fois : rien ne double
      expect(s.available(), avail);
      expect(s.summary('2026-05').expense, 633750);
      expect(s.summary('2026-06').expense, 116800);
      expect(
        s.txs.where((t) => t.trace && t.type == TxType.expense).length,
        83 + 34,
      );
      final cash = s.accounts.firstWhere((a) => a.name == 'Cash');
      expect(
        s
            .transactions(accountId: cash.id, month: '2026-05')
            .any((t) => t.trace),
        isFalse,
      );
      expect(s.yearSummary('2026').firstExpenseMonth, '2026-05');
    },
  );

  test('tontine : depuis juin 2024, puis la toucher', () async {
    final s = AppStore()..persist = false;
    await s.load();
    await s.importHistory();
    final avail = s.available();
    final t = s.accounts.firstWhere((a) => a.name == 'Tontine');
    final bal = s.balance(t);
    expect(bal, 725000);
    s.addOldTontine(); // une deuxième fois : rien ne double
    final i = s.savingsInfo(t);
    expect(i.count, 29);
    expect(i.since, '2024-06');
    expect(i.monthly, 25000);
    expect(i.years['2024']!.$2, 175000);
    expect(i.years['2025']!.$2, 300000);
    expect(i.years['2026']!.$2, 250000);
    expect(s.available(), avail);
    final m = s.accounts.firstWhere((a) => a.name == 'Tontine avec Mariam BCR');
    expect(s.savingsInfo(m).since, '2026-10');
    final nita = s.accounts.firstWhere((a) => a.name == 'Nita');
    s.cashOut(t, received: 750000, toId: nita.id, date: '2026-11-12');
    expect(s.available(), avail + 750000);
    expect(s.balance(t), 0);
    expect(t.closed, '2026-11-12');
    expect(s.closedSavings().single.$2!.amount, 725000);
    expect(s.avoirs().horsDisponible.any((e) => e.$1.id == t.id), isFalse);
  });
}
