import 'package:flutter_test/flutter_test.dart';
import 'package:my_finn/format.dart';
import 'package:my_finn/models.dart';
import 'package:my_finn/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    "l'import du suivi complet retombe sur tous les soldes du fichier",
    () async {
      final s = AppStore()..persist = false;
      await s.load(); // pas de fichier en test : valeurs par défaut
      // une ancienne opération doit disparaître (l'import remplace tout)
      s.saveTx(
        Tx(
          id: 0,
          type: TxType.expense,
          amount: 999,
          accountId: 1,
          date: '2026-09-02',
          label: 'ancien',
        ),
      );
      await s.importHistory();
      await s.importHistory(); // réimporter ne double rien
      int bal(String n, [String? until]) =>
          s.balance(s.accounts.firstWhere((a) => a.name == n), until: until);
      expect(s.txs.where((t) => t.label == 'ancien'), isEmpty);
      // 30/09
      expect(bal('Compte Coris', '2026-09-30'), 1356750);
      expect(bal('Nita', '2026-09-30'), 72400);
      expect(bal('Cash', '2026-09-30'), 48200);
      expect(s.available(until: '2026-09-30'), 1479050);
      // 31/10
      expect(bal('Compte Coris', '2026-10-31'), 387500);
      expect(bal('Nita', '2026-10-31'), 18100);
      expect(bal('Visa Nita', '2026-10-31'), 1500);
      expect(bal('Amana', '2026-10-31'), 0);
      expect(bal('Cash', '2026-10-31'), 115400);
      expect(bal("Bons d'essence", '2026-10-31'), 45000);
      expect(s.available(until: '2026-10-31'), 522500);
      // 03/11
      expect(s.available(), 521500);
      expect(bal('Nita'), 17100);
      // avoirs
      final a = s.avoirs();
      expect(a.creances, 2930500);
      expect(a.dettes, 246500);
      expect(a.placements, 4220000);
      expect(a.total, 7425500);
      // revenus : 12 mois notés (sept. 2025 → août 2026) puis les mois saisis
      final months = s.incomeMonths();
      expect(
        months.where((m) => m.fromHistory).length,
        14,
      ); // sept. 2025 → oct. 2026
      final hist = months
          .where((m) => m.month.compareTo('2026-08') <= 0)
          .toList();
      expect(hist.length, 12);
      expect(hist.first.month, '2025-09');
      expect(hist.fold(0, (x, m) => x + m.gross), 10230700);
      expect(hist.fold(0, (x, m) => x + m.net), 9919500);
      expect(months.firstWhere((m) => m.month == '2026-10').net, 885750);
      final sm = s.summary('2026-09');
      expect(sm.income, 905550);
      expect(sm.taxes, 33450);
      expect(sm.byBeneficiary['maison'], 71300);
      expect(s.summary('2026-10').taxes, 25250);
      expect(
        s.monthReport('2026-10'),
        contains('| **Disponible** | **522.500** |'),
      );
    },
  );

  test('opération récurrente ajoutée chaque mois', () async {
    final s = AppStore()..persist = false;
    await s.load();
    fixedToday = '2026-11-03';
    s.addRecurring(
      Recurring(
        id: 0,
        type: TxType.income,
        amount: 479750,
        accountId: 1,
        day: 23,
        lastMonth: '2026-09',
        label: 'Salaire',
      ),
    );
    expect(
      s.runRecurring(),
      1,
    ); // octobre seulement (le 23 novembre n'est pas encore passé)
    expect(s.runRecurring(), 0);
    fixedToday = null;
  });

  test('format des montants', () {
    expect(num0(1479050), '1.479.050');
    expect(parseAmount('1.479.050'), 1479050);
  });
}
