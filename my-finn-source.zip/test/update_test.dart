import 'package:flutter_test/flutter_test.dart';
import 'package:my_finn/update.dart';

void main() {
  test('numéro de version lu dans le tag GitHub', () {
    expect(releaseNumber('v1.0.1'), 1);
    expect(releaseNumber('v1.0.12'), 12);
    expect(releaseNumber('nimporte'), null);
  });
}
