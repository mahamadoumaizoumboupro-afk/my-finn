import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_finn/format.dart';
import 'package:my_finn/screens/accounts.dart';
import 'package:my_finn/screens/debts.dart';
import 'package:my_finn/screens/home.dart';
import 'package:my_finn/screens/report.dart';
import 'package:my_finn/screens/settings.dart';
import 'package:my_finn/screens/transactions.dart';
import 'package:my_finn/screens/tx_form.dart';
import 'package:my_finn/models.dart';
import 'package:my_finn/store.dart';
import 'package:my_finn/theme.dart';

/// Vérifie qu'aucun écran ne déborde sur un petit téléphone, avec le texte agrandi.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    final loader = FontLoader('Manrope');
    for (final f in Directory('assets/fonts').listSync().whereType<File>()) {
      loader.addFont(Future.value(ByteData.sublistView(f.readAsBytesSync())));
    }
    await loader.load();
    store.persist = false;
    await store.load();
    fixedToday = '2026-09-30';
    await store.importSeptember2026();
  });

  final screens = <String, Widget Function()>{
    'accueil': () => Scaffold(body: HomeScreen(goTab: (_) {})),
    'opérations': () => const Scaffold(body: TransactionsScreen()),
    'prêts': () => const Scaffold(body: DebtsScreen()),
    'bilan': () => const Scaffold(body: ReportScreen()),
    'comptes': () => const AccountsScreen(),
    'réglages': () => const SettingsScreen(),
    'nouvelle dépense': () => const TxFormScreen(type: TxType.expense),
    'nouveau prêt': () => const DebtFormScreen(direction: DebtDirection.lent),
  };

  for (final scale in [1.0, 1.35]) {
    for (final e in screens.entries) {
      testWidgets('${e.key} (texte x$scale)', (t) async {
        t.view.physicalSize = const Size(360 * 3, 740 * 3);
        t.view.devicePixelRatio = 3;
        t.platformDispatcher.textScaleFactorTestValue = scale;
        addTearDown(t.view.reset);
        addTearDown(t.platformDispatcher.clearAllTestValues);
        await t.pumpWidget(MaterialApp(theme: buildTheme(),
            builder: (c, child) => MediaQuery.withClampedTextScaling(maxScaleFactor: 1.35, child: child!), home: e.value()));
        await t.pump(const Duration(milliseconds: 500));
        expect(t.takeException(), isNull);
      });
    }
  }

  testWidgets('supprimer une opération puis « Annuler » la remet', (t) async {
    t.view.physicalSize = const Size(400 * 3, 900 * 3);
    t.view.devicePixelRatio = 3;
    addTearDown(t.view.reset);
    final before = store.txs.length;
    final id = store.txs.first.id;
    await t.pumpWidget(MaterialApp(theme: buildTheme(), home: Builder(builder: (c) => Scaffold(body: Center(
        child: TextButton(onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => TxFormScreen(id: id))), child: const Text('ouvrir')))))));
    await t.tap(find.text('ouvrir'));
    await t.pumpAndSettle();
    await t.scrollUntilVisible(find.text('Supprimer'), 300,
        scrollable: find.byWidgetPredicate((w) => w is Scrollable && w.axisDirection == AxisDirection.down).first);
    await t.tap(find.text('Supprimer'));
    await t.pumpAndSettle();
    expect(store.txs.length, before - 1);
    expect(find.text('Opération supprimée'), findsOneWidget);
    await t.tap(find.text('ANNULER'));
    await t.pumpAndSettle();
    expect(store.txs.length, before);
    expect(store.tx(id), isNotNull);
  });
}
