"""Convertit « Suivi finances - export » (md) en données de départ : assets/seed/history.json.

Usage : python3 tool/build_history.py <export.md> assets/seed/history.json

- Septembre et octobre 2026, novembre en cours : toutes les opérations, ligne par ligne.
- Septembre 2025 → août 2026 : historique des revenus seulement (sans effet sur les soldes).
- Avoirs : placements, tontines, créances et dettes.
Le script vérifie que les soldes retombent exactement sur ceux du fichier (30/09, 31/10, 03/11).
"""
import json, re, sys, unicodedata

src = open(sys.argv[1], encoding="utf-8").read()


def amt(s):
    s = s.replace("*", "").replace(" ", "").replace("+", "").replace(" ", "")
    if s in ("", "-", "Prêt"):
        return 0
    return int(s.replace(".", ""))


def norm(s):
    s = s.lower().replace("·", "|")
    return unicodedata.normalize("NFD", s).encode("ascii", "ignore").decode()


def section(start, end):
    return src.split(start, 1)[1].split(end, 1)[0]


def rows(text, ncols):
    out = []
    for line in text.splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) == ncols and re.match(r"\d\d/\d\d", cells[0]):
            out.append(cells)
    return out


CORIS, NITA, VISA, AMANA, CASH, BONS = "Compte Coris", "Nita", "Visa Nita", "Amana", "Cash", "Bons d'essence"
TONTINE, MARIAM, IBOU_PF = "Tontine", "Tontine avec Mariam BCR", "Projet futur avec Ibou"
MAIN = [CORIS, NITA, VISA, AMANA, CASH]

TARGETS = {
    "2026-09-30": {CORIS: 1356750, NITA: 72400, VISA: 1500, AMANA: 200, CASH: 48200, BONS: 48000},
    "2026-10-31": {CORIS: 387500, NITA: 18100, VISA: 1500, AMANA: 0, CASH: 115400, BONS: 45000},
    "2026-11-03": {CORIS: 387500, NITA: 17100, VISA: 1500, AMANA: 0, CASH: 115400, BONS: 45000},
}

CATS = [
    ("Frais bancaires", ["frais de retrait", "frais de transfert", "frais de virement", "frais de paiement"]),
    ("Taxes & frais pro", ["arf"]),
    ("Remboursement d'emprunt", ["remboursement emprunt"]),
    ("Abonnements", ["abonnement"]),
    ("Éducation", ["makaranta", "examens", "inscription"]),
    ("Recharge & téléphone", ["recharge", "credit", "greffage", "puce", "wifi"]),
    ("Transport", ["essence", "moto", "gasoil", "parking"]),
    ("Habits", ["polo", "boubou", "claquette", "couture", "habits"]),
    ("Entretien & lessive", ["lessive", "blanchisseur", "lavage", "sirage"]),
    ("Soins & produits", ["produit", "parfum", "coiffure", "coiffeur", "brosse", "cosmetique", "soleil"]),
    ("Maison & équipement", ["ventilateur", "ampoule", "soudure", "charbon", "cable", "chargeur"]),
    ("Alimentation", ["pain", "doukounou", "bouffe", "fritte", "frite", "brochette", "poulet", "sandwich",
                      "degue", "the", "solani", "kakandadi", "massa", "mais", "dejeuner", "diner", "lait", "cake",
                      "crepes", "kilichi", "ananas", "viande", "poisson", "amuse", "eau", "chocolat", "glace",
                      "fruits", "ravitaillement", "vivres", "plat", "awara", "pommes", "mayonnaise", "jus"]),
    ("Divers", ["divers", "non identifiees", "inconnu", "ecart", "bloc"]),
]


def category(label, nature):
    if nature == "donation":
        return "Dons & donations"
    if nature == "cadeau":
        return "Cadeaux"
    n = norm(label)
    for name, keys in CATS:
        if any(re.search(r"\b" + re.escape(k), n) for k in keys):
            return name
    return "Divers"


def account_of(text, default=CASH):
    n = norm(text)
    if "bon d'essence" in n:
        return BONS
    for key, acc in (("visa nita", VISA), ("coris", CORIS), ("nita", NITA), ("amana", AMANA), ("cash", CASH)):
        if re.search(r"\b" + key + r"\b", n):
            return acc
    return default


txs, transfers, debts, payments = [], [], [], []


def expense(date, label, amount, account, who="Moi", nature=None, cat=None, note=None):
    nwho = norm(who)
    if nwho in ("moi", "", "moi + autres", "-") or nwho.startswith("moi +"):
        ben, person = "moi", None
        if nwho.startswith("moi +") and "autres" not in nwho:
            note = note or f"Avec {who[5:].strip()}"
    elif nwho == "chez moi":
        ben, person = "maison", None
    else:
        ben, person = "personne", who
    nat = nature or "pour"
    if ben == "personne" and nature is None:
        nl = norm(label + " " + who)
        if "cadeau" in nl or "habits" in nl or "recompense" in nl:
            nat = "cadeau"
        elif re.search(r"\bdon(ation)?\b", nl) or "cotisation" in nl:
            nat = "donation"
    txs.append(dict(type="expense", date=date, label=label, amount=amount, account=account, beneficiary=ben,
                    person=person, nature=nat, category=cat or category(label, nat), note=note))


def income(date, label, amount, account, cat, tax=0, note=None):
    txs.append(dict(type="income", date=date, label=label, amount=amount, account=account, category=cat, tax=tax,
                    note=note))


def transfer(date, frm, to, amount, fee=0, label=None, note=None):
    transfers.append(dict(date=date, frm=frm, to=to, amount=amount, fee=fee,
                          label=label or f"{frm} vers {to}", note=note))


def lend(date, person, amount, account, label, key=None):
    debts.append(dict(key=key or person, direction="lent", date=date, person=person, amount=amount,
                      account=account, label=label))


def borrow(date, person, amount, account, label, key=None):
    debts.append(dict(key=key or person, direction="borrowed", date=date, person=person, amount=amount,
                      account=account, label=label))


def repay(date, key, amount, account):
    payments.append(dict(date=date, key=key, amount=amount, account=account))


# ------------------------------------------------------------------ Septembre 2026
sept = section("# Septembre 2026", "## Entrées de septembre")
for d, label, who, montant, _ in rows(sept.split("## Mouvements", 1)[1], 5):
    date = f"2026-09-{d[:2]}"
    m = re.match(r"(.*?) · (.+)$", label)
    base, acc_txt = (m.group(1).strip(), m.group(2).strip()) if m else (label, "")
    account = account_of(acc_txt) if acc_txt else CASH
    if acc_txt.startswith("retrait Coris"):
        account = CORIS
    value = amt(montant)
    nl = norm(label)
    if "4.000 nita + 20.000 cash" in nl:
        expense(date, base + " (part Nita)", 4000, NITA)
        expense(date, base + " (part cash)", 20000, CASH)
    elif montant.startswith("+"):
        continue  # entrées : reprises du tableau des entrées
    elif label.startswith("Transfert"):
        transfer(date, CORIS, CASH, 50000, label="Retrait Coris vers cash")
    elif base.startswith("Frais de retrait Nita"):
        transfer(date, NITA, CASH, 30000, fee=value, label="Retrait Nita vers cash")
    elif nl.startswith("tontine mensuelle"):
        transfer(date, CASH, TONTINE, value, label="Tontine mensuelle", note="Placement : sans effet sur le total")
    elif value < 0:
        person = re.sub(r"^Remboursement prêt (gasoil )?", "", base).strip()
        repay(date, person, -value, account)
    elif norm(base).startswith("pret"):
        person = re.sub(r"\s+prêt$", "", who).strip()
        lend(date, person, value, account, base)
    else:
        w = re.sub(r"\s+donation$", "", who).strip()
        nature = "donation" if who.endswith("donation") else None
        if who == "Solani":  # « Thé · cash | Solani » : thé et solani pour moi
            w, base = "Moi", "Thé + solani"
        if "examens" in norm(base):
            nature = "pour"
        expense(date, base, value, account, w, nature=nature)

for d, label, acc, montant in rows(section("## Entrées de septembre", "## Coût"), 4):
    date = f"2026-09-{d[:2]}"
    n = norm(label)
    account = account_of(acc)
    if "bcr" in n:
        income(date, "Salaire BCR de septembre", 479750, account, "Salaire", tax=25250, note="505.000 brut − taxe 25.250")
    elif "bel" in n:
        income(date, "Gombo branding Bel Œuf", 155800, account, "Prestations & gombo", tax=8200,
               note="164.000 brut − ISB 5 %")
    elif "salaire" in n:
        income(date, label, amt(montant), account, "Salaire")
    else:
        income(date, label, amt(montant), account, "Prestations & gombo")

# ------------------------------------------------------------------ Octobre 2026
octo = section("# Octobre 2026", "## Entrées d'octobre")
SKIP_FEES = []  # frais rattachés à un virement : ne pas compter deux fois
for d, label, who, montant, _ in rows(octo, 5):
    date = f"2026-10-{d[:2]}"
    n = norm(label)
    value = amt(montant)
    parts = [p.strip() for p in label.split(" · ")]
    base = parts[0]
    acc_parts = [p for p in parts[1:] if account_of(p, None) is not None and len(p) < 25]
    account = account_of(acc_parts[-1]) if acc_parts else CASH

    # --- mouvements internes (virements, retraits, placements)
    if n.startswith("virement") or n.startswith("retrait coris vers") or n.startswith("retrait nita vers") \
            or n.startswith("retrait amana vers") or n.startswith("depot cash vers"):
        words = re.match(r"\w+ (\w+(?: \w+)?) vers (\w+) \| ([\d.]+)", n)
        frm, to, a = account_of(words.group(1)), account_of(words.group(2)), amt(words.group(3))
        kind = "Retrait" if n.startswith("retrait") else "Dépôt" if n.startswith("depot") else "Virement"
        transfer(date, frm, to, a, label=f"{kind} {frm} vers {to}")
        continue
    if n.startswith("cash vers nita"):
        transfer(date, CASH, NITA, 10000, label="Dépôt Cash vers Nita")
        continue
    if n.startswith("frais de virement") or n.startswith("frais de transfert nita vers") or n.startswith("frais de retrait"):
        # rattaché au dernier virement qui part du même compte, le même jour
        src_acc = CORIS if "coris" in n else AMANA if "amana" in n.split("vers")[0] else NITA
        t = next(t for t in reversed(transfers) if t["date"] == date and t["frm"] == src_acc and t["fee"] == 0)
        t["fee"] = value
        continue
    if n.startswith("argent des travaux"):
        borrow(date, "Argent des travaux", 150000, CASH, "Argent confié pour des travaux · à rendre", key="travaux")
        continue
    if n.startswith("pret a bio"):
        lend(date, "Bio", 1600000, CASH, "Prêt à Bio · cash (dont 150.000 de l'argent des travaux)")
        continue
    if n.startswith("cotisation tontine"):
        transfer(date, CASH, TONTINE, 25000, label="Cotisation tontine du 31", note="Placement : sans effet sur le total")
        continue
    if "tontine avec mariam" in n:
        transfer(date, CORIS, MARIAM, 100000, label="Mise de départ tontine avec Mariam BCR",
                 note="Placement : sans effet sur le total")
        continue
    if n.startswith("investissement projet futur"):
        transfer(date, NITA, IBOU_PF, 50000, label="Projet futur avec Ibou · mise mensuelle",
                 note="Placement : sans effet sur le total")
        continue

    # --- entrées et remboursements reçus
    if montant.startswith("+"):
        if who == "Ibou":
            repay(date, "Ibou", 20000, NITA)
            income(date, "Cadeau d'Ibou (avec son remboursement)", 1000, NITA, "Cadeaux reçus")
        elif who == "Aziz":
            repay(date, "Aziz", value, CASH)
        elif "almou" in n:
            repay(date, "Almou", value, NITA)
        elif "remboursement inconnu" in n:
            income(date, "Remboursement inconnu · écart constaté sur Nita", value, NITA, "Autres entrées")
        elif "salaire bcr" in n:
            income(date, "Salaire BCR d'octobre", 479750, CORIS, "Salaire", tax=25250, note="505.000 brut − taxe 25.250")
        elif "salaire" in n:
            income(date, base, value, account, "Salaire")
        elif "cadeau" in n:
            income(date, "Cadeau de Raïssa (grande sœur)", value, CASH, "Cadeaux reçus")
        else:
            income(date, base, value, account, "Prestations & gombo")
        continue

    # --- dépenses
    if "ecart constate sur nita" in n:
        account = NITA
    elif "ecart constate sur le cash" in n:
        account = CASH
    elif "ecart constate sur coris" in n:
        account = CORIS
    if n.startswith("essence | bon d'essence"):
        account = BONS
    note = None
    if "retrouves en cash" in n:  # écart Nita 48.450 dont 20.000 retrouvés en cash
        expense(date, "Écart de caisse · dépenses inconnues · Nita", 48450, NITA, "Moi + autres",
                note="48.450 manquants sur Nita, dont 20.000 retrouvés en cash")
        income(date, "Argent retrouvé en cash (écart Nita)", 20000, CASH, "Autres entrées")
        continue
    label_out = base if len(parts) == 1 else " · ".join(p for p in parts if p not in acc_parts)
    if "ecart" in n or "inconnu" in n or "bloc" in n:
        label_out = " · ".join(p for p in parts if p not in acc_parts)
    expense(date, label_out, value, account, who if who else "Moi")

# ------------------------------------------------------------------ Novembre 2026
nov = section("# Novembre 2026", "## Mouvements attendus")
for d, label, who, montant, _ in rows(nov, 5):
    expense(f"2026-11-{d[:2]}", "Crédit de recharge · écart constaté sur Nita", amt(montant), NITA, who)

# ------------------------------------------------------------------ Soldes de départ (01/09) recalculés
def flows(until):
    f = {}
    def add(a, v):
        f[a] = f.get(a, 0) + v
    for t in txs:
        if t["date"] <= until:
            add(t["account"], t["amount"] if t["type"] == "income" else -t["amount"])
    for t in transfers:
        if t["date"] <= until:
            add(t["frm"], -t["amount"] - t["fee"])
            add(t["to"], t["amount"])
    for d_ in debts:
        if d_["account"] and d_["date"] <= until:
            add(d_["account"], -d_["amount"] if d_["direction"] == "lent" else d_["amount"])
    for p in payments:
        if p["date"] <= until:
            dd = next(x for x in debts if x["key"] == p["key"])
            add(p["account"], p["amount"] if dd["direction"] == "lent" else -p["amount"])
    return f


f30 = flows("2026-09-30")
initial = {a: TARGETS["2026-09-30"][a] - f30.get(a, 0) for a in TARGETS["2026-09-30"]}

# ------------------------------------------------------------------ Avoirs (placements, tontines, créances, dettes)
# Tontine : 25.000 × 29 mois = 725.000 au 03/11, dont 2 cotisations saisies (19/09 et 16/10)
initial[TONTINE] = 725000 - 50000
initial[MARIAM] = 0
initial[IBOU_PF] = 0
placements = [("Illa · véhicule vendu", 1000000), ("Deuxième placement", 1300000),
              ("Troisième placement", 1000000)]
for name, v in placements:
    initial[name] = v

OLD = "2026-08-31"  # créances et dettes d'avant septembre 2026 (date exacte inconnue)
for person, items in [("Raïssa", [100000, 200000, 350000, 5000]), ("Almou", [100000, 30000, 20000, 20000, 10000]),
                      ("Nadège", [158000]), ("Aziz", [70000, 16000, 10000, 10000]), ("Bollo", [100000]),
                      ("Poutcha", [50000, 10000]), ("Leefa", [10000]), ("Umar", [10000]), ("Leyla", [1500])]:
    for i, v in enumerate(items):
        label = "Créance d'avant septembre 2026"
        if person == "Almou" and i == 3:
            label += " · à vérifier"
        if person == "Aziz" and i == 3:
            label = "Cota · créance d'avant septembre 2026"
        lend(OLD, person, v, None, label, key=f"{person}-old-{i}")
# Remboursement d'Aziz du 18/10 : sur sa créance de 70.000
for p in payments:
    if p["key"] == "Aziz":
        p["key"] = "Aziz-old-0"
# Prêt du 21/09 à Almou : clé propre
for d_ in debts:
    if d_["person"] == "Almou" and d_["date"] == "2026-09-21":
        d_["key"] = "Almou-2109"
for p in payments:
    if p["key"] == "Almou":
        p["key"] = "Almou-2109"

lend("2026-09-10", "Coris · retrait en litige", 10000, None, "Retrait Coris non encaissé : débité, argent non sorti · à réclamer")
lend("2026-08-31", "Reliquats de mission", 20000, None, "Mission Maradi formation DSS · comptable Djibril, INS",
     key="reliquat-maradi")
lend("2026-09-30", "Reliquats de mission", 20000, None, "Mission Ingall · comptable Djibril, INS", key="reliquat-ingall")

for person, motif, v, date in [
    ("Abib Digit", "Abonnement Claude août 2026", 12000, "2026-08-31"),
    ("Abib Digit", "ChatGPT octobre 2025", 11000, "2025-10-31"),
    ("Abib Digit", "Boost pour Nado mars 2026", 7000, "2026-03-31"),
    ("Abib Digit", "Motif oublié", 3500, "2026-08-31"),
    ("Wahab", "Reliquat créatrice de contenu · 2025", 21000, "2025-12-31"),
    ("Bio", "Cotisation mariage Cheikh · août 2023", 20000, "2023-08-31"),
    ("Aziz", "À lui garder, à son mariage · avril 2024", 15000, "2024-04-30"),
    ("Ibou", "Vendredi soir à Abib · janvier 2026", 5000, "2026-01-31"),
    ("Ibou", "Babati · septembre 2025", 2000, "2025-09-30"),
]:
    borrow(date, person, v, None, motif, key=f"dette-{person}-{motif}")

# ------------------------------------------------------------------ Historique des revenus (sept. 2025 → août 2026)
M = {"septembre": 9, "octobre": 10, "novembre": 11, "décembre": 12, "janvier": 1, "février": 2, "mars": 3,
     "avril": 4, "mai": 5, "juin": 6, "juillet": 7, "août": 8}


def ym(mois):
    m = M[mois.lower()]
    return f"{2025 if m >= 9 else 2026}-{m:02d}"


history = []
for mois in M:
    k = ym(mois)
    history.append(dict(month=k, source="Salaire BCR", label="Salaire BCR", amount=505000, tax=25250))
    history.append(dict(month=k, source="Salaire Abib Digit", label="Salaire Abib Digit", amount=130000, tax=0))

var = section("## Détail des revenus variables", "\n---") if "\n---" in src.split("## Détail des revenus variables")[1] \
    else src.split("## Détail des revenus variables", 1)[1]
SOURCES = {"Missions & perdiem": "Missions & perdiem", "Gombo": "Gombo (prestations)",
           "Gratifications": "Gratifications", "Carburant & bons d'essence": "Carburant & bons d'essence",
           "Cadeaux Raïssa": "Cadeaux reçus", "Projet commun (e-book)": "Projet commun (e-book)"}
current = None
for line in var.splitlines():
    line = line.strip()
    mh = re.match(r"\*\*(.+?) · [\d.]+\*\*(.*)", line)
    if mh:
        current = mh.group(1).strip()
        rest = mh.group(2).strip(" ·")
        if current.startswith("Avantages"):
            history.append(dict(month="2026-02", source="Avantages en nature", label="Carton de sucre (BCR)",
                                amount=30000, tax=0))
            history.append(dict(month="2026-07", source="Crédit (Hadjia)", label="Cartes de recharge (Hadjia)",
                                amount=6000, tax=0))
            current = None
        elif rest:  # « Cadeaux Raïssa · 35.000 · Novembre 20.000 · Avril 10.000 · Juin 5.000 »
            for mm, v in re.findall(r"(\w+) ([\d.]+)", rest):
                history.append(dict(month=ym(mm), source=SOURCES[current], label=current, amount=amt(v), tax=0))
            current = None
        continue
    if not current or not line.startswith("-"):
        continue
    body = line[1:].strip()
    if current == "Gratifications":
        for mm, lab, v in re.findall(r"(\w+) · ([^·]+?) ([\d.]+)(?= ·|$)", body):
            history.append(dict(month=ym(mm), source="Gratifications", label=lab.strip(), amount=amt(v), tax=0))
    elif current.startswith("Carburant"):
        for mm, v in re.findall(r"(\w+) ([\d.]+)", body):
            history.append(dict(month=ym(mm), source=SOURCES[current], label="Carburant & bons d'essence",
                                amount=amt(v), tax=0))
    elif current == "Gombo":
        mm, rest = body.split(" · ", 1)
        for lab, v in re.findall(r"([^·]+?) ([\d.]+)(?: \(ISB 5 % déduit\))?(?= ·|$)", rest):
            tax = 8200 if "Bel" in lab else 0
            history.append(dict(month=ym(mm), source="Gombo (prestations)", label=lab.strip(), amount=amt(v), tax=tax))
    else:  # Missions
        mm, rest = body.split(" · ", 1)
        lab, v = re.match(r"(.+) · ([\d.]+)", rest.split(" (")[0]).groups()
        history.append(dict(month=ym(mm), source="Missions & perdiem", label=lab.strip(), amount=amt(v), tax=0))

# Septembre et octobre 2026 : chiffres du « Détail mensuel » (revenus par mois gagné, comme le reste de l'historique)
history += [
    dict(month="2026-09", source="Salaire BCR", label="Salaire BCR", amount=505000, tax=25250),
    dict(month="2026-09", source="Salaire Abib Digit", label="Salaire Abib Digit (reçu le 07/10)", amount=130000, tax=0),
    dict(month="2026-09", source="Gombo (prestations)", label="Ajout pour la production de contenu", amount=20000, tax=0),
    dict(month="2026-10", source="Salaire BCR", label="Salaire BCR", amount=505000, tax=25250),
    dict(month="2026-10", source="Gombo (prestations)", label="Création de contenu", amount=100000, tax=0),
    dict(month="2026-10", source="Gombo (prestations)", label="Création de contenu", amount=160000, tax=0),
    dict(month="2026-10", source="Gombo (prestations)", label="Colab Masterclass de Ibou", amount=65000, tax=0),
    dict(month="2026-10", source="Gombo (prestations)", label="Zaparo", amount=45000, tax=0),
    dict(month="2026-10", source="Gombo (prestations)", label="Gombo", amount=30000, tax=0),
    dict(month="2026-10", source="Cadeaux reçus", label="Cadeau de Raïssa", amount=5000, tax=0),
    dict(month="2026-10", source="Cadeaux reçus", label="Cadeau d'Ibou", amount=1000, tax=0),
]
for m_, expected in (("2026-09", 629750), ("2026-10", 885750)):
    got = sum(h["amount"] - h["tax"] for h in history if h["month"] == m_)
    assert got == expected, (m_, got)

# ------------------------------------------------------------------ Vérifications
ok = True
for date, target in TARGETS.items():
    f = flows(date)
    for a, v in target.items():
        got = initial[a] + f.get(a, 0)
        if got != v:
            ok = False
            print(f"ÉCART {date} {a}: calculé {got:,} attendu {v:,}")
    dispo = sum(initial[a] + f.get(a, 0) for a in MAIN)
    print(date, "disponible", f"{dispo:,}")

d01 = sum(initial[a] + flows("2026-09-01").get(a, 0) for a in MAIN)
print("disponible au 01/09 (après les dépenses du 1er):", f"{d01:,}", "(attendu 1,145,800)")
print("disponible avant le 1er:", f"{sum(initial[a] for a in MAIN):,}")

h12 = [h for h in history if h["month"] <= "2026-08"]
brut = sum(h["amount"] for h in h12)
tax = sum(h["tax"] for h in h12)
print("historique: brut", f"{brut:,}", "taxes", f"{tax:,}", "net", f"{brut - tax:,}", "(attendu 10,230,700 / 311,200 / 9,919,500)")
by = {}
for h in history:
    by[h["source"]] = by.get(h["source"], 0) + h["amount"]
print(by)

lent_open = 0
for d_ in debts:
    paid = sum(p["amount"] for p in payments if p["key"] == d_["key"])
    if d_["direction"] == "lent":
        lent_open += d_["amount"] - paid
owe = sum(d_["amount"] - sum(p["amount"] for p in payments if p["key"] == d_["key"]) for d_ in debts
          if d_["direction"] == "borrowed")
f3 = flows("2026-11-03")
off = sum(initial[a] + f3.get(a, 0) for a in initial if a not in MAIN)
dispo = sum(initial[a] + f3.get(a, 0) for a in MAIN)
print("créances", f"{lent_open:,}", "dettes", f"{owe:,}", "hors disponible", f"{off:,}",
      "AVOIRS", f"{dispo + off + lent_open - owe:,}", "(attendu 7,425,500)")

n_sept = sum(1 for t in txs if t["date"].startswith("2026-09")) + sum(1 for t in transfers if t["date"].startswith("2026-09"))
print("opérations:", len(txs), "virements:", len(transfers), "prêts/dettes:", len(debts), "remboursements:", len(payments))
for m in ("2026-09", "2026-10", "2026-11"):
    dep = sum(t["amount"] for t in txs if t["type"] == "expense" and t["date"].startswith(m) and t["account"] != BONS)
    fees = sum(t["fee"] for t in transfers if t["date"].startswith(m))
    inc = sum(t["amount"] for t in txs if t["type"] == "income" and t["date"].startswith(m))
    print(m, "dépenses", f"{dep:,}", "frais", f"{fees:,}", "entrées", f"{inc:,}")

for d_ in debts:
    d_.pop("key_unused", None)
out = dict(initial=initial, offBalance=[TONTINE, MARIAM, IBOU_PF] + [p[0] for p in placements],
           transactions=txs, transfers=transfers, debts=debts, payments=payments, history=history)
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("OK" if ok else "SOLDES NON CONCORDANTS")
