#!/usr/bin/env bash
# Fabrique l'APK sur GitHub Actions. Appelé par .github/workflows/apk.yml.
# La clé de signature fixe (android/app/myfinn-release.jks.enc, chiffrée) est déverrouillée
# avec le secret MYFINN_PASSWORD : chaque version s'installe ainsi par-dessus la précédente
# sans perdre les données.
set -euo pipefail
PW=$(printf %s "${MYFINN_PASSWORD:-}" | tr -d ' \r\n')
if [ -z "$PW" ]; then
  echo "::error::Secret MYFINN_PASSWORD manquant : ajoute-le dans Settings > Secrets > Actions."
  exit 1
fi
MYFINN_PW="$PW" openssl enc -d -aes-256-cbc -pbkdf2 -iter 300000 \
  -in android/app/myfinn-release.jks.enc -out android/app/myfinn-release.jks -pass env:MYFINN_PW
BUILD=$((GITHUB_RUN_NUMBER + 1))   # +1 : la toute première version publiée était la n°1
echo "BUILD=$BUILD" >> "$GITHUB_ENV"
flutter pub get
flutter test
flutter build apk --release --build-name="1.0.$BUILD" --build-number="$BUILD" --dart-define=BUILD_NUMBER="$BUILD"
cp build/app/outputs/flutter-apk/app-release.apk "MY-FINN-$BUILD.apk"
