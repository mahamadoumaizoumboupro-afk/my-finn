#!/usr/bin/env bash
# Fabrique l'APK sur GitHub Actions. Appelé par .github/workflows/apk.yml.
# La clé de signature fixe (android/app/myfinn-release.jks.enc, chiffrée) est déverrouillée
# avec le secret MYFINN_PASSWORD : chaque version s'installe ainsi par-dessus la précédente
# sans perdre les données.
set -euo pipefail
PW=$(printf %s "${MYFINN_PASSWORD:-}" | tr -d ' \r\n')
if [ -z "$PW" ]; then
  echo "::error::Secret MYFINN_PASSWORD manquant : ajoute-le dans Settings > Secrets > Actions."
  exit 1
fi
MYFINN_PW="$PW" openssl enc -d -aes-256-cbc -pbkdf2 -iter 300000 \
  -in android/app/myfinn-release.jks.enc -out android/app/myfinn-release.jks -pass env:MYFINN_PW
BUILD=$((GITHUB_RUN_NUMBER + 1))   # +1 : la toute première version publiée était la n°1
echo "BUILD=$BUILD" >> "$GITHUB_ENV"
flutter pub get
flutter test
flutter build apk --release --android-skip-build-dependency-validation --build-name="1.0.$BUILD" --build-number="$BUILD" --dart-define=BUILD_NUMBER="$BUILD"
cp build/app/outputs/flutter-apk/app-release.apk "MY-FINN-$BUILD.apk"

# Version web (pour l'iPhone) : publiée sur la branche gh-pages, servie par GitHub Pages
# à https://<compte>.github.io/my-finn/. Si ça échoue, l'APK est quand même publié.
publish_web() {
  local repo="${GITHUB_REPOSITORY##*/}"
  flutter build web --release --base-href "/$repo/" --no-web-resources-cdn \
    --dart-define=BUILD_NUMBER="$BUILD"
  touch build/web/.nojekyll
  local auth
  auth=$(git config --get http.https://github.com/.extraheader || true)
  (
    cd build/web
    rm -rf .git
    git init -q
    git checkout -q -b gh-pages
    git add -A
    git -c user.name="github-actions[bot]" \
      -c user.email="41898282+github-actions[bot]@users.noreply.github.com" \
      commit -qm "Version web 1.0.$BUILD"
    git -c http.https://github.com/.extraheader="$auth" \
      push -f -q "https://github.com/$GITHUB_REPOSITORY.git" gh-pages
  )
}
publish_web || echo "::warning::Version web non publiée (l'APK, lui, est prêt)."
