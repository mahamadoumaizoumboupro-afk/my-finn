"""Convertit Tresorerie_Septembre_2026.md en données de départ (src/seed/september2026.json)."""
import json, re, sys, unicodedata

src = open(sys.argv[1], encoding="utf-8").read()

def amt(s):
    s = s.replace("*", "").replace(" ", "").replace("+", "")
    return int(s.replace(".", "")) if s not in ("", "-") else 0

def norm(s):
    return unicodedata.normalize("NFD", s.lower()).encode("ascii", "ignore").decode()

ACCOUNTS = {"coris": "Compte Coris", "nita": "Nita", "visa nita": "Visa Nita", "amana": "Amana",
            "cash": "Cash", "bon d'essence": "Bons d'essence", "retrait coris": "Compte Coris"}
FINAL = {"Compte Coris": 1356750, "Nita": 72400, "Visa Nita": 1500, "Amana": 200, "Cash": 48200,
         "Bons d'essence": 48000}

CATS = [
    ("Frais bancaires", ["frais de retrait"]),
    ("Taxes & frais pro", ["arf"]),
    ("Remboursement d'emprunt", ["remboursement emprunt"]),
    ("Recharge & téléphone", ["recharge", "credit", "greffage", "puce"]),
    ("Abonnements", ["abonnement"]),
    ("Épargne & tontine", ["tontine"]),
    ("Éducation", ["makaranta", "examens"]),
    ("Transport", ["essence", "moto", "gasoil", "parking"]),
    ("Habits", ["polo", "boubou", "claquette", "couture"]),
    ("Entretien & lessive", ["lessive", "blanchisseur", "lavage", "sirage"]),
    ("Soins & produits", ["produit", "parfum", "coiffure", "coiffeur", "brosse"]),
    ("Maison & équipement", ["ventilateur", "ampoule", "soudure", "charbon"]),
    ("Alimentation", ["pain", "doukounou", "bouffe", "fritte", "frite", "brochette", "poulet", "sandwich",
                      "degue", "the", "solani", "kakandadi", "massa", "mais", "dejeuner", "lait", "cake",
                      "crepes", "kilichi", "ananas", "viande", "poisson", "amuse", "eau", "chocolat",
                      "fruits", "ravitaillement", "vivres"]),
    ("Divers", ["divers", "non identifiees"]),
]

def category(label, nature):
    if nature == "donation": return "Dons & donations"
    if nature == "cadeau": return "Cadeaux"
    n = norm(label)
    for name, keys in CATS:
        if any(re.search(r"\b" + re.escape(k), n) for k in keys):
            return name
    return "Divers"

movements = src.split("## Mouvements")[1].split("## Entrées")[0]
txs, debts, payments, transfers = [], [], [], []

for line in movements.splitlines():
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    if len(cells) != 5 or not re.match(r"\d\d/\d\d", cells[0]):
        continue
    d, label, who, montant, _ = cells
    date = f"2026-09-{d[:2]}"
    m = re.match(r"(.*) · (.+)$", label)
    acc_txt = m.group(2).strip() if m else ""
    base = m.group(1).strip() if m else label
    account = "Cash"
    for k, v in ACCOUNTS.items():
        if norm(acc_txt).startswith(norm(k)):
            account = v
    if "Nita +" in acc_txt or "Nita + " in acc_txt:  # couture : 4.000 Nita + 20.000 cash
        txs.append(dict(date=date, label=base + " (part Nita)", amount=4000, account="Nita",
                        beneficiary="moi", person=None, nature="pour", category=category(base, "pour")))
        txs.append(dict(date=date, label=base + " (part cash)", amount=20000, account="Cash",
                        beneficiary="moi", person=None, nature="pour", category=category(base, "pour")))
        continue
    if montant.startswith("+"):
        continue  # entrées reprises depuis le tableau des entrées
    if label.startswith("Transfert"):
        transfers.append(dict(date=date, frm="Compte Coris", to="Cash", amount=50000, fee=0, label="Retrait Coris vers cash"))
        continue
    value = amt(montant)
    nwho = norm(who)
    person = re.sub(r"\s+(donation|pret)$", "", who, flags=re.I).strip()
    person = re.sub(r"\s+prêt$", "", person).strip()
    if value < 0:  # remboursement reçu d'un prêt
        payments.append(dict(date=date, person=person, amount=-value, account=account))
        continue
    if norm(base).startswith("pret"):
        debts.append(dict(date=date, person=person, amount=value, account=account, label=base))
        continue
    if nwho == "moi" or who == "":
        beneficiary, person_v = "moi", None
    elif nwho == "chez moi":
        beneficiary, person_v = "maison", None
    else:
        beneficiary, person_v = "personne", person
    nl = norm(base + " " + who)
    nature = "pour"
    if beneficiary == "personne":
        if "cadeau" in nl: nature = "cadeau"
        elif re.search(r"\bdon(ation)?\b", nl) or "cotisation" in nl: nature = "donation"
    tx = dict(date=date, label=base, amount=value, account=account, beneficiary=beneficiary,
              person=person_v, nature=nature, category=category(base, nature))
    txs.append(tx)
    if "Frais de retrait Nita" in base:
        tx["label"] = "Frais de retrait Nita"
        tx["account"] = "Nita"
        transfers.append(dict(date=date, frm="Nita", to="Cash", amount=30000, fee=0, label="Retrait Nita vers cash"))

incomes = []
ent = src.split("## Entrées de septembre")[1].split("##")[0]
for line in ent.splitlines():
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    if len(cells) == 4 and re.match(r"\d\d/\d\d", cells[0]):
        n = norm(cells[1])
        cat = "Salaire" if "salaire" in n else "Prestations & gombo"
        incomes.append(dict(date=f"2026-09-{cells[0][:2]}", label=cells[1], account=ACCOUNTS[norm(cells[2])] if norm(cells[2]) in ACCOUNTS else cells[2], amount=amt(cells[3]), category=cat))

# soldes initiaux recalculés pour retomber exactement sur les soldes du 30/09
flow = {a: 0 for a in FINAL}
for t in txs: flow[t["account"]] -= t["amount"]
for i in incomes: flow[i["account"]] += i["amount"]
for t in transfers: flow[t["frm"]] -= t["amount"] + t["fee"]; flow[t["to"]] += t["amount"]
for d in debts: flow[d["account"]] -= d["amount"]
for p in payments: flow[p["account"]] += p["amount"]
initial = {a: FINAL[a] - flow[a] for a in FINAL}

# créances antérieures : 1.400.500 au 30/09 dont 120.000 de prêts de septembre encore ouverts
open_sept = sum(d["amount"] for d in debts) - sum(p["amount"] for p in payments)
extra = [
    dict(date="2026-09-01", person="Créances antérieures (à détailler)", amount=1400500 - open_sept, account=None,
         label="Solde des créances au 30/09 hors prêts de septembre"),
    dict(date="2026-09-30", person="Coris (retrait en litige)", amount=10000, account=None,
         label="Retrait Coris non encaissé, en litige"),
    dict(date="2026-09-30", person="Reliquats de mission", amount=40000, account=None,
         label="En attente de versement : deux reliquats de mission"),
]
out = dict(initial=initial, transactions=txs, incomes=incomes, transfers=transfers, debts=debts,
           payments=payments, extraDebts=extra)
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
dep = sum(t["amount"] for t in txs)
print("tx", len(txs), "dépenses", dep, "incomes", sum(i["amount"] for i in incomes), "debts", len(debts),
      "payments", len(payments), "open", open_sept, "initial", initial)
from collections import Counter
c = Counter(); [c.update({t["category"]: t["amount"]}) for t in txs]; print(c)
print([ (t["label"], t["person"], t["nature"]) for t in txs if t["beneficiary"]=="personne"])
